
export type SectionType = 
  | 'hero' | 'identity' | 'logos' | 'brandIcon' | 'colors' | 'gradients' 
  | 'patterns' | 'typography' | 'textStyles' | 'iconography' | 'socialIcons'
  | 'imagery' | 'social' | 'signatures' | 'qr' | 'ai' | 'assets'
  | 'misuse' | 'products' | 'atmosphere' | 'templates' | 'custom' | 'cinematic'
  | 'caseStudies' | 'brochures' | 'spotlights' | 'playground';

export type EntityType = 'brand' | 'product';
export type Role = 'admin' | 'public';
export type View = 'landing' | 'dashboard' | 'brand-detail' | 'brand-editor' | 'vault' | 'stability' | 'settings' | 'login';

export interface SystemHealth {
  status: 'nominal' | 'scanning' | 'warning' | 'critical';
  lastCheck: number;
  faultCount: number;
  message: string;
}

export interface DiagnosticResult {
  id: string;
  name: string;
  status: 'success' | 'warning' | 'error' | 'pending';
  log: string;
}

export interface RestorePoint {
  id: string;
  timestamp: number;
  label: string;
  brandCount: number;
  data: Brand[];
}

export type PageFormat = 'a4' | 'letter' | 'presentation_wide';

export interface BackgroundSettings {
  style: 'none' | 'mesh' | 'dots' | 'orion' | 'solid' | 'flow' | 'aurora' | 'circuit' | 'spectral' | 'ribbons';
  primaryColor?: string;
  secondaryColor?: string;
  animate?: boolean;
  opacity?: number;
  blur?: number;
}

export interface DocumentSpecimen {
  id: string;
  title: string;
  description: string;
  previewUrl: string;
  templateUrl: string;
  category: string;
}

export interface Typography {
  name: string;
  role: 'Heading' | 'Body' | 'Display' | 'Web Safe';
  fontFamily: string;
  sampleText: string;
  isVariable: boolean;
  flexAxes?: { wght?: number; wdth?: number; opsz?: number; GRAD?: number; slnt?: number; };
  weights?: string[];
  description?: string;
  downloadUrl?: string;
}

export interface BrandTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  fileType: string;
  fileSize: string;
  previewUrl?: string;
  downloadUrl: string;
  isCallout: boolean;
}

export interface BrandSection<T = any> {
  id: string;
  type: SectionType;
  title: string;
  description?: string;
  isVisible: boolean;
  data: T;
  order: number;
}

export interface Color {
  name: string;
  hex: string;
  usage: 'primary' | 'secondary' | 'accent' | 'neutral';
}

export interface Gradient {
  name: string;
  css: string;
}

export interface Icon {
  id: string;
  name: string;
  svgPath: string;
  category: string;
  tags: string[];
}

export interface IconSet {
  id: string;
  name: string;
  description: string;
  icons: Icon[];
  style: string;
  createdAt: number;
}

export interface NeuralRegistry {
  archetype: string;
  narrative: string;
  visualConstraints: string;
  culturalNuance: string;
}

export interface Asset {
  id: string;
  name: string;
  type: 'logo' | 'icon' | 'image' | 'presentation' | 'archive';
  url: string;
  format: string;
  size: string;
}

export interface TextStyle {
  id: string;
  tag: string;
  name: string;
  size: string;
  weight: string;
  lineHeight: string;
  sample: string;
}

export interface EmailSignature {
  id: string;
  type: 'main' | 'response';
  name: string;
  role: string;
  html: string;
}

export interface AdvancedGovernance {
  mfaRequired: boolean;
  metadataShield: boolean;
  neuralLevel: 'flash' | 'pro';
  storagePriority: 'local' | 'cloud' | 'high';
  showInDashboard: boolean;
}

export interface FileEntry {
  path: string;
  name: string;
  isDir: boolean;
}

export interface ProjectAnalysis {
  projectName: string;
  summary: string;
  technologies: string[];
  architectureOverview: string;
  suggestedImprovements: string[];
}

export interface BrandIcon {
  id: string;
  name: string;
  url: string;
  usageRights: string;
  settings: string;
}

export interface Brand {
  id: string;
  version: string;
  name: string;
  entityType: EntityType;
  isVisible: boolean;
  category: string;
  logoUrl: string;
  coverImage: string;
  description: string;
  industry: string;
  tagline?: string;
  archetype?: string;
  missionStatement?: string;
  updatedAt: number;
  sections: BrandSection[];
  toneOfVoice: string[];
  colors: Color[];
  assets: Asset[];
  typography: Typography[];
  logos: Record<string, string>;
  brandIcons?: BrandIcon[];
  brandIcon?: {
    url: string;
    usageRights: string;
    settings: string;
  };
  templates?: BrandTemplate[];
  caseStudies?: DocumentSpecimen[];
  brochures?: DocumentSpecimen[];
  spotlights?: DocumentSpecimen[];
  intelligenceBrain?: string;
  backgroundSettings?: BackgroundSettings;
  values: { text: string; icon: string }[];
  status?: 'active' | 'maintenance' | 'deprecated';
  signatures?: EmailSignature[];
  governance?: AdvancedGovernance;
  brainRegistry?: NeuralRegistry;
  gradients?: Gradient[];
  patterns?: { name: string; url: string }[];
  textStyles?: TextStyle[];
  icons?: Icon[];
  aiIconSets?: IconSet[];
  socials?: { platform: string; handle: string; url: string; color: string }[];
  socialBanners?: { platform: string; url: string }[];
  digitalBanners?: { size: string; url: string }[];
  emailBanners?: { id: string; url: string; name: string }[];
  cinematicAssets?: { id: string; type: 'video' | 'motion'; url: string; name: string }[];
  logoGuidelines?: { clearSpace: string; minimumSize: string; spacing: string };
  imageryGuidelines?: string;
  imagery?: { url: string; description: string; type: 'do' | 'dont' }[];
  logoUsageDonts?: { url: string; description: string }[];
  qrSettings?: { defaultUrl: string; fgColor: string; bgColor: string; useCustomColors: boolean };
}
