
/**
 * Normalizes cloud storage links to direct asset URLs.
 * Optimized for high-reliability binary streaming.
 */
export const getDirectImageUrl = (url: string | undefined | null): string => {
  if (!url) return '';
  
  const cleanUrl = url.trim();

  // Already processed data or standard link
  if (cleanUrl.startsWith('data:') || cleanUrl.startsWith('blob:')) return cleanUrl;

  // Handle Dropbox - Comprehensive Protocol
  if (cleanUrl.includes('dropbox.com') || cleanUrl.includes('dropboxusercontent.com')) {
    try {
      const urlObj = new URL(cleanUrl);
      
      // Force the direct content subdomain
      if (urlObj.hostname !== 'dl.dropboxusercontent.com') {
        urlObj.hostname = 'dl.dropboxusercontent.com';
      }

      // Remove parameters that trigger preview pages or download prompts
      urlObj.searchParams.delete('dl');
      urlObj.searchParams.delete('preview');
      
      // Force raw=1 to ensure the response is the actual image binary
      // This is the critical fix for "Continuous Loading" on Dropbox links
      urlObj.searchParams.set('raw', '1');
      
      return urlObj.toString();
    } catch (e) {
      // Fallback string manipulation if URL parsing fails
      let direct = cleanUrl
        .replace('www.dropbox.com', 'dl.dropboxusercontent.com')
        .replace('dropbox.com', 'dl.dropboxusercontent.com');
      
      if (direct.includes('?')) {
        if (!direct.includes('raw=1')) {
          direct = direct.replace(/dl=[01]/, 'raw=1');
          if (!direct.includes('raw=1')) direct += '&raw=1';
        }
      } else {
        direct = direct + '?raw=1';
      }
      return direct;
    }
  }

  // Handle Google Drive - Supporting multiple URL formats
  if (cleanUrl.includes('drive.google.com')) {
    const fileDMatch = cleanUrl.match(/\/file\/d\/([^\/?]+)/);
    if (fileDMatch && fileDMatch[1]) {
      return `https://drive.google.com/uc?export=download&id=${fileDMatch[1]}`;
    }
    
    const idMatch = cleanUrl.match(/[?&]id=([^&]+)/);
    if (idMatch && idMatch[1]) {
       return `https://drive.google.com/uc?export=download&id=${idMatch[1]}`;
    }
  }

  return cleanUrl;
};

/**
 * Heuristic Optimizer: Injects resizing parameters for known CDNs.
 */
export const getOptimizedImageUrl = (url: string | undefined | null, width: number = 800): string => {
  if (!url) return '';
  const directUrl = getDirectImageUrl(url);
  
  if (directUrl.includes('images.unsplash.com')) {
    const baseUrl = directUrl.split('?')[0];
    return `${baseUrl}?w=${width}&q=80&auto=format&fit=crop`;
  }
  
  return directUrl;
};

export const getVideoType = (url: string | undefined | null): 'direct' | 'youtube' | 'vimeo' | 'unsupported' => {
  if (!url) return 'unsupported';
  const u = url.toLowerCase();
  if (u.includes('youtube.com') || u.includes('youtu.be')) return 'youtube';
  if (u.includes('vimeo.com')) return 'vimeo';
  if (u.endsWith('.mp4') || u.endsWith('.webm') || u.endsWith('.ogg') || u.includes('?raw=1') || u.includes('dl.dropboxusercontent.com')) return 'direct';
  return 'unsupported';
};

export const getEmbedUrl = (url: string): string => {
  if (!url) return '';
  const u = url.toLowerCase();
  
  if (u.includes('youtube.com') || u.includes('youtu.be')) {
    let id = '';
    if (u.includes('v=')) id = url.split('v=')[1]?.split('&')[0];
    else if (u.includes('youtu.be/')) id = url.split('youtu.be/')[1]?.split('?')[0];
    else if (u.includes('embed/')) id = url.split('embed/')[1]?.split('?')[0];
    return `https://www.youtube.com/embed/${id}?autoplay=0&mute=1&loop=1&playlist=${id}&modestbranding=1&rel=0`;
  }
  
  if (u.includes('vimeo.com')) {
    const idMatch = url.match(/vimeo\.com\/(\d+)/);
    const id = idMatch ? idMatch[1] : url.split('/').pop();
    return `https://player.vimeo.com/video/${id}?autoplay=0&loop=1&muted=1&title=0&byline=0&portrait=0`;
  }

  if (u.includes('dl.dropboxusercontent.com')) {
    return url; 
  }

  return url;
};
