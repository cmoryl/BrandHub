
// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { 
  Save, X, Layout, Shield, Box, Palette, Type, Grid, Share2, 
  Monitor, DownloadCloud, Plus, Trash2, Sliders, Type as TypeIcon,
  Sparkles, BrainCircuit, Image as ImageIcon, QrCode, Globe, Target,
  FileText, Activity, Layers, ShieldCheck, Hexagon, Terminal, Trash,
  Flame, Mail, MapPin, Ban, Hash, Code, Navigation, Fingerprint,
  FileSearch, BookOpen, Star, FileArchive, Zap, Database, Lock, Eye, EyeOff,
  ChevronRight, Smartphone, LayoutDashboard, Film, ImagePlus, AlertCircle, Info, Link,
  CheckCircle2, Wind, MousePointer2, Briefcase, Wand2, Loader2, Waves, Blip
} from 'lucide-react';
import { Brand, Typography, Color, EmailSignature, AdvancedGovernance, DocumentSpecimen, BrandSection, BrandIcon, Icon, IconSet, BackgroundSettings } from '../types';
import { NEW_BRAND_TEMPLATE } from '../constants';
import AIIconStudio from './AIIconStudio';
import { synthesizeBrandIdentity } from '../services/geminiService';

const BrandEditor: React.FC<any> = ({ brand, onSave, onCancel, isDarkMode }) => {
  const [activeStudio, setActiveStudio] = useState<string>('basics');
  const [formData, setFormData] = useState<Partial<Brand>>({});
  const [iconSubMode, setIconSubMode] = useState<'manual' | 'ai'>('ai');
  const [isSynthesizing, setIsSynthesizing] = useState<string | null>(null);

  useEffect(() => {
    setFormData(brand ? JSON.parse(JSON.stringify(brand)) : JSON.parse(JSON.stringify(NEW_BRAND_TEMPLATE)));
  }, [brand]);

  const updateField = (field: keyof Brand, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNeuralDraft = async (field: string) => {
    if (!formData.name || !formData.industry) {
      alert("Organizational Identifier and Sector required for Neural Drafting.");
      return;
    }
    setIsSynthesizing(field);
    try {
      const result = await synthesizeBrandIdentity({
        name: formData.name,
        industry: formData.industry,
        description: formData.description || 'A new brand initiative.'
      });

      if (field === 'missionStatement') updateField('missionStatement', result.missionStatement);
      if (field === 'archetype') updateField('archetype', result.archetype);
      if (field === 'tagline') updateField('tagline', result.tagline || result.archetype);
    } catch (e) {
      console.error("Drafting Fault:", e);
    } finally {
      setIsSynthesizing(null);
    }
  };

  const updateGovernance = (field: keyof AdvancedGovernance, value: any) => {
    const gov = formData.governance || NEW_BRAND_TEMPLATE.governance;
    updateField('governance', { ...gov, [field]: value });
  };

  const updateBackground = (field: keyof BackgroundSettings, value: any) => {
    const bg = formData.backgroundSettings || { style: 'none' };
    updateField('backgroundSettings', { ...bg, [field]: value });
  };

  const updateLogoVariant = (variant: string, value: string) => {
    const nextLogos = { ...(formData.logos || {}) };
    nextLogos[variant] = value;
    updateField('logos', nextLogos);
  };

  const removeLogoVariant = (variant: string) => {
    const nextLogos = { ...(formData.logos || {}) };
    delete nextLogos[variant];
    updateField('logos', nextLogos);
  };

  const updateBrain = (field: string, value: string) => {
    const nextBrain = { ...(formData.brainRegistry || {}) };
    nextBrain[field] = value;
    updateField('brainRegistry', nextBrain);
  };

  const addToArray = (field: keyof Brand, defaultObj: any) => {
    const arr = Array.isArray(formData[field]) ? [...formData[field]] : [];
    updateField(field, [...arr, { ...defaultObj, id: Math.random().toString(36).substr(2, 9) }]);
  };

  const removeFromArray = (field: keyof Brand, index: number) => {
    const arr = [...formData[field]];
    arr.splice(index, 1);
    updateField(field, arr);
  };

  const updateArrayItem = (field: keyof Brand, index: number, itemField: string, value: any) => {
    const arr = [...formData[field]];
    arr[index] = { ...arr[index], [itemField]: value };
    updateField(field, arr);
  };

  const handleAICommit = (data: { icons?: Icon[], set?: IconSet }) => {
    if (data.set) {
      const currentSets = Array.isArray(formData.aiIconSets) ? [...formData.aiIconSets] : [];
      updateField('aiIconSets', [...currentSets, data.set]);
    } else if (data.icons) {
      const currentIcons = Array.isArray(formData.icons) ? [...formData.icons] : [];
      updateField('icons', [...currentIcons, ...data.icons]);
    }
  };

  const studioCategories = [
    {
      group: "Core Infrastructure",
      studios: [
        { id: 'basics', label: '01 Basics', icon: Target },
        { id: 'identity', label: '02 Identity Forge', icon: ShieldCheck },
        { id: 'intelligence', label: '18 Intelligence Studio', icon: BrainCircuit },
        { id: 'atmosphere', label: '05 Atmosphere Protocol', icon: Waves },
        { id: 'governance', label: 'Governance Protocol', icon: Lock }
      ]
    },
    {
      group: "Visual DNA",
      studios: [
        { id: 'logos', label: '03 Mark Repository', icon: Box },
        { id: 'symbol', label: '04 Symbol Protocol', icon: Shield },
        { id: 'colors', label: '07 Palette Lab', icon: Palette },
        { id: 'gradients', label: '08 Flux Nodes', icon: Flame },
        { id: 'patterns', label: '09 Geometric Primitives', icon: Grid },
        { id: 'misuse', label: '06 Anti-Patterns', icon: Ban }
      ]
    },
    {
      group: "Design Systems",
      studios: [
        { id: 'typography', label: '10 Typography Registry', icon: TypeIcon },
        { id: 'textStyles', label: '11 Semantic Hierarchies', icon: Code },
        { id: 'icons', label: '12 Iconography Studio', icon: Sparkles }
      ]
    },
    {
      group: "Engagement & Media",
      studios: [
        { id: 'imagery', label: '14 Imagery Guidelines', icon: ImageIcon },
        { id: 'social', label: '13 Social Tagging', icon: Smartphone },
        { id: 'banners', label: '15 Digital Footprint', icon: LayoutDashboard },
        { id: 'cinematic', label: 'Cinematic Assets', icon: Film },
        { id: 'signatures', label: '16 Signature Protocol', icon: Mail }
      ]
    },
    {
      group: "Global Distribution",
      studios: [
        { id: 'caseStudies', label: 'Case Studies', icon: FileSearch },
        { id: 'brochures', label: 'Brochure Specimen', icon: BookOpen },
        { id: 'spotlights', label: 'Solution Spotlights', icon: Star },
        { id: 'qr', label: '17 Access Ports (QR)', icon: QrCode },
        { id: 'templates', label: 'Master Templates', icon: FileArchive },
        { id: 'assets', label: '19 Global Asset Vault', icon: DownloadCloud }
      ]
    }
  ];

  const inputClass = "w-full p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-white/5 text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-blue-500 transition-all outline-none text-sm font-sans";
  const labelClass = "text-[10px] font-black text-slate-400 dark:text-slate-300 uppercase tracking-widest px-1 block mb-2 font-sans";
  const subHeadingClass = "text-xl font-black dark:text-white uppercase tracking-tight mb-8 flex items-center gap-3 font-sans";

  return (
    <div className="max-w-[1500px] w-full mx-auto bg-white dark:bg-slate-950 rounded-[3rem] shadow-2xl border border-slate-200 dark:border-white/10 overflow-hidden flex flex-col h-[92vh] text-left animate-in zoom-in duration-500 font-sans">
      
      {/* GLOBAL STUDIO HEADER */}
      <div className="bg-slate-50 dark:bg-slate-900/80 backdrop-blur-xl px-10 py-6 flex justify-between items-center border-b border-slate-200 dark:border-white/5 shrink-0 relative z-30">
        <div className="flex items-center gap-6">
          <div className="p-3 bg-blue-600 rounded-2xl text-white shadow-lg shadow-blue-500/20"><Terminal className="w-6 h-6" /></div>
          <div>
            <h2 className="text-2xl font-black dark:text-white uppercase tracking-tighter leading-none">Global Studio Hub</h2>
            <p className="text-slate-500 dark:text-slate-300 text-[9px] font-black uppercase tracking-[0.3em] mt-2 flex items-center gap-2">
               <Fingerprint className="w-3 h-3 text-blue-500" /> Active Protocol: {formData.name || 'UNNAMED_NODE'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4">
           <button onClick={onCancel} className="px-6 py-3 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white font-black text-[10px] uppercase tracking-widest transition-colors">Abort Changes</button>
           <button onClick={() => onSave(formData)} className="flex items-center gap-3 px-10 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-blue-500/20 active:scale-95 transition-all"><Save className="w-4 h-4" /> Commit Protocol</button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* STUDIO SIDEBAR NAVIGATOR */}
        <aside className="w-80 border-r border-slate-200 dark:border-white/5 bg-slate-50/50 dark:bg-slate-900/30 overflow-y-auto custom-scrollbar p-6 shrink-0">
           <div className="space-y-10">
              {studioCategories.map((group, idx) => (
                <div key={idx} className="space-y-2">
                   <h3 className="text-[9px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.4em] px-3 mb-4">{group.group}</h3>
                   <div className="space-y-1">
                      {group.studios.map(studio => (
                        <button 
                          key={studio.id}
                          onClick={() => setActiveStudio(studio.id)}
                          className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeStudio === studio.id ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20 translate-x-2' : 'text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-white/5 hover:text-blue-500'}`}
                        >
                          <studio.icon className={`w-4 h-4 ${activeStudio === studio.id ? 'text-white' : 'text-slate-400'}`} />
                          {studio.label}
                        </button>
                      ))}
                   </div>
                </div>
              ))}
           </div>
        </aside>

        {/* MAIN INDIVIDUAL STUDIO EDITOR */}
        <main className="flex-1 overflow-y-auto p-12 custom-scrollbar bg-white dark:bg-transparent relative">
           <div className="max-w-4xl mx-auto pb-24">
           
           {activeStudio === 'basics' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <h3 className={subHeadingClass}><Target className="w-8 h-8 text-blue-500" /> Basics Studio</h3>
                <div className="grid md:grid-cols-2 gap-8">
                   <div><label className={labelClass}>Brand Name</label><input type="text" value={formData.name || ''} onChange={e => updateField('name', e.target.value)} className={inputClass} /></div>
                   <div><label className={labelClass}>Industry Sector</label><input type="text" value={formData.industry || ''} onChange={e => updateField('industry', e.target.value)} className={inputClass} /></div>
                   <div><label className={labelClass}>Category</label><input type="text" value={formData.category || ''} onChange={e => updateField('category', e.target.value)} className={inputClass} /></div>
                   <div><label className={labelClass}>Entity Type</label><select value={formData.entityType || 'brand'} onChange={e => updateField('entityType', e.target.value)} className={inputClass}><option value="brand">Corporate Brand</option><option value="product">Sub-Product / Tool</option></select></div>
                </div>
                <div><label className={labelClass}>System Summary</label><textarea rows={4} value={formData.description || ''} onChange={e => updateField('description', e.target.value)} className={`${inputClass} resize-none h-40 leading-relaxed text-sm`} /></div>
             </div>
           )}

           {activeStudio === 'identity' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <h3 className={subHeadingClass}><ShieldCheck className="w-8 h-8 text-emerald-500" /> Identity Forge</h3>
                <div className="grid md:grid-cols-2 gap-8">
                   <div className="relative group">
                     <label className={labelClass}>Primary Tagline</label>
                     <div className="relative">
                        <input type="text" value={formData.tagline || ''} onChange={e => updateField('tagline', e.target.value)} className={`${inputClass} pr-14`} />
                        <button 
                          onClick={() => handleNeuralDraft('tagline')}
                          className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-xl bg-indigo-500/10 text-indigo-500 hover:bg-indigo-500 hover:text-white transition-all shadow-sm"
                          title="Neural Tagline Draft"
                        >
                          {isSynthesizing === 'tagline' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                        </button>
                     </div>
                   </div>
                   <div className="relative group">
                     <label className={labelClass}>Archetype</label>
                     <div className="relative">
                        <input type="text" value={formData.archetype || ''} onChange={e => updateField('archetype', e.target.value)} className={`${inputClass} pr-14`} />
                        <button 
                          onClick={() => handleNeuralDraft('archetype')}
                          className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-xl bg-indigo-500/10 text-indigo-500 hover:bg-indigo-500 hover:text-white transition-all shadow-sm"
                          title="Neural Archetype Analysis"
                        >
                          {isSynthesizing === 'archetype' ? <Loader2 className="w-4 h-4 animate-spin" /> : <BrainCircuit className="w-4 h-4" />}
                        </button>
                     </div>
                   </div>
                </div>
                <div className="relative group">
                  <label className={labelClass}>Mission Manifesto</label>
                  <div className="relative">
                    <textarea rows={4} value={formData.missionStatement || ''} onChange={e => updateField('missionStatement', e.target.value)} className={`${inputClass} resize-none h-40 leading-relaxed text-sm pr-14`} />
                    <button 
                      onClick={() => handleNeuralDraft('missionStatement')}
                      className="absolute right-3 top-4 p-3 rounded-xl bg-indigo-500/10 text-indigo-500 hover:bg-indigo-500 hover:text-white transition-all shadow-lg"
                      title="Synthesize Manifesto"
                    >
                      {isSynthesizing === 'missionStatement' ? <Loader2 className="w-6 h-6 animate-spin" /> : <Wand2 className="w-6 h-6" />}
                    </button>
                  </div>
                </div>
                <div>
                   <div className="flex items-center justify-between mb-4"><label className={labelClass}>Core Value Matrix</label><button onClick={() => addToArray('values', { text: 'New Value', icon: 'Zap' })} className="text-[9px] font-black text-blue-500 dark:text-blue-400 uppercase tracking-widest">+ Add Node</button></div>
                   <div className="grid md:grid-cols-2 gap-4">
                      {(formData.values || []).map((v, i) => (
                        <div key={i} className="flex gap-4 p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-white/5"><input type="text" value={v.text} onChange={e => updateArrayItem('values', i, 'text', e.target.value)} className="flex-1 bg-transparent border-none p-0 focus:ring-0 text-sm font-bold dark:text-white" /><button onClick={() => removeFromArray('values', i)} className="text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button></div>
                      ))}
                   </div>
                </div>
             </div>
           )}

           {activeStudio === 'atmosphere' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <h3 className={subHeadingClass}><Waves className="w-8 h-8 text-blue-500" /> Atmosphere Protocol</h3>
                <div className="grid md:grid-cols-2 gap-10">
                   <div className="space-y-8">
                      <div>
                        <label className={labelClass}>Environmental Engine Style</label>
                        <select 
                          value={formData.backgroundSettings?.style || 'none'} 
                          onChange={e => updateBackground('style', e.target.value)} 
                          className={inputClass}
                        >
                           <option value="none">None (Dashboard Default)</option>
                           <option value="mesh">High-Frequency Mesh</option>
                           <option value="dots">Subtle Geometry (Dots)</option>
                           <option value="orion">Orion Neural Starfield</option>
                           <option value="solid">Flat Chromatic Solid</option>
                           <option value="flow">Liquid Flow Vectors</option>
                           <option value="aurora">Atmospheric Aurora</option>
                           <option value="circuit">Logic Grid (Circuit)</option>
                           <option value="spectral">Spectral Wave Bundle</option>
                           <option value="ribbons">High-Fidelity Ribbons</option>
                        </select>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-6">
                        <div>
                           <label className={labelClass}>Primary Chromatic</label>
                           <div className="flex items-center gap-3 p-2 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-white/5">
                              <input type="color" value={formData.backgroundSettings?.primaryColor || '#0033A0'} onChange={e => updateBackground('primaryColor', e.target.value)} className="h-10 w-10 rounded-lg cursor-pointer bg-transparent border-none" />
                              <span className="text-[10px] font-mono font-bold dark:text-slate-400">{(formData.backgroundSettings?.primaryColor || '#0033A0').toUpperCase()}</span>
                           </div>
                        </div>
                        <div>
                           <label className={labelClass}>Secondary Chromatic</label>
                           <div className="flex items-center gap-3 p-2 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-white/5">
                              <input type="color" value={formData.backgroundSettings?.secondaryColor || '#0077C8'} onChange={e => updateBackground('secondaryColor', e.target.value)} className="h-10 w-10 rounded-lg cursor-pointer bg-transparent border-none" />
                              <span className="text-[10px] font-mono font-bold dark:text-slate-400">{(formData.backgroundSettings?.secondaryColor || '#0077C8').toUpperCase()}</span>
                           </div>
                        </div>
                      </div>

                      <label className="flex items-center justify-between p-6 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-white/5 cursor-pointer">
                         <div className="flex items-center gap-4">
                            <div className="p-2 bg-blue-600/10 text-blue-600 rounded-lg"><Activity className="w-5 h-5" /></div>
                            <span className="text-sm font-black uppercase tracking-widest text-slate-500">Fluid Animation Active</span>
                         </div>
                         <input type="checkbox" checked={formData.backgroundSettings?.animate} onChange={e => updateBackground('animate', e.target.checked)} className="w-6 h-6 rounded-lg bg-slate-200 dark:bg-slate-800 border-none checked:bg-blue-600" />
                      </label>
                   </div>

                   <div className="space-y-8">
                      <div>
                         <label className={labelClass}>Engine Master Opacity ({Math.round((formData.backgroundSettings?.opacity || 0.4) * 100)}%)</label>
                         <input type="range" min="0" max="1" step="0.01" value={formData.backgroundSettings?.opacity || 0.4} onChange={e => updateBackground('opacity', parseFloat(e.target.value))} className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-600" />
                      </div>
                      <div>
                         <label className={labelClass}>Gaussian Retinal Blur ({formData.backgroundSettings?.blur || 0}px)</label>
                         <input type="range" min="0" max="40" step="1" value={formData.backgroundSettings?.blur || 0} onChange={e => updateBackground('blur', parseInt(e.target.value))} className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-600" />
                      </div>
                      <div className="p-6 bg-blue-600/5 border border-blue-600/10 rounded-3xl space-y-3">
                         <h4 className="text-[10px] font-black text-blue-600 uppercase tracking-widest flex items-center gap-2"><Info className="w-4 h-4" /> Protocol Preview</h4>
                         <p className="text-[11px] text-slate-500 font-medium leading-relaxed">Changes to the environmental atmosphere are reflected immediately in the underlying canvas. Tuning opacity allows for balancing readability against visual depth.</p>
                      </div>
                   </div>
                </div>
             </div>
           )}

           {activeStudio === 'intelligence' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <h3 className={subHeadingClass}><BrainCircuit className="w-8 h-8 text-purple-500" /> Neural Brain Registry</h3>
                <div className="p-8 bg-purple-500/5 border border-purple-500/10 rounded-3xl mb-8">
                   <p className="text-xs text-purple-600 dark:text-purple-400 font-bold leading-relaxed uppercase tracking-wider flex items-center gap-3">
                      <Info className="w-5 h-5" /> These parameters define the permanent boundary constraints for all generative content synthesis.
                   </p>
                </div>
                <div className="grid md:grid-cols-2 gap-8">
                   <div><label className={labelClass}>AI Archetype Persona</label><input type="text" value={formData.brainRegistry?.archetype || ''} onChange={e => updateBrain('archetype', e.target.value)} className={inputClass} placeholder="e.g. The Visionary Architect" /></div>
                   <div><label className={labelClass}>Cultural Nuance Bias</label><input type="text" value={formData.brainRegistry?.culturalNuance || ''} onChange={e => updateBrain('culturalNuance', e.target.value)} className={inputClass} placeholder="e.g. Professional, Ethical, Precise" /></div>
                </div>
                <div><label className={labelClass}>Primary Brand Narrative DNA</label><textarea rows={4} value={formData.brainRegistry?.narrative || ''} onChange={e => updateBrain('narrative', e.target.value)} className={`${inputClass} resize-none h-40 leading-relaxed text-sm`} /></div>
                <div><label className={labelClass}>Generative Visual Constraints</label><textarea rows={4} value={formData.brainRegistry?.visualConstraints || ''} onChange={e => updateBrain('visualConstraints', e.target.value)} className={`${inputClass} resize-none h-40 leading-relaxed text-sm`} placeholder="e.g. Minimalist, Bauhaus influenced, high contrast..." /></div>
             </div>
           )}

           {activeStudio === 'logos' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex justify-between items-center mb-8">
                  <h3 className={subHeadingClass}><Box className="w-8 h-8 text-blue-500" /> Mark Repository</h3>
                  <button onClick={() => {
                    const label = prompt("Enter variant name (e.g. Stacked, Monochrome, Banner):");
                    if (label) updateLogoVariant(label, '');
                  }} className="px-6 py-3 bg-blue-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Mark Variant</button>
                </div>
                <div className="grid md:grid-cols-2 gap-10">
                   {Object.entries(formData.logos || {}).map(([variant, url]) => (
                     <div key={variant} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-6">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500">{variant} variant</span>
                          <button onClick={() => removeLogoVariant(variant)} className="text-slate-400 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                        </div>
                        <div><label className={labelClass}>Direct Asset URL</label><input type="text" value={url || ''} onChange={e => updateLogoVariant(variant, e.target.value)} className={inputClass} /></div>
                        <div className="aspect-video rounded-2xl bg-white/5 border border-white/5 flex items-center justify-center p-8 overflow-hidden">
                           {url ? <img src={url} className="max-h-full max-w-full object-contain" /> : <ImageIcon className="w-12 h-12 opacity-10" />}
                        </div>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'symbol' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex justify-between items-center mb-8">
                  <h3 className={subHeadingClass}><Shield className="w-8 h-8 text-sky-500" /> Symbol Protocol</h3>
                  <button onClick={() => addToArray('brandIcons', { name: 'App Icon', url: '', usageRights: '', settings: '' })} className="px-6 py-3 bg-sky-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Symbol Node</button>
                </div>
                <div className="space-y-10">
                   {(formData.brandIcons || []).map((icon, i) => (
                     <div key={i} className="p-10 bg-slate-50 dark:bg-slate-900 rounded-[3rem] border border-slate-200 dark:border-white/5 grid lg:grid-cols-2 gap-12 group">
                        <div className="space-y-6">
                           <div className="flex justify-between items-center mb-4">
                             <input type="text" value={icon.name} onChange={e => updateArrayItem('brandIcons', i, 'name', e.target.value)} className="bg-transparent border-none p-0 text-xl font-black dark:text-white uppercase focus:ring-0 w-full" placeholder="Node Name (e.g. Favicon)..." />
                             <button onClick={() => removeFromArray('brandIcons', i)} className="text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-5 h-5" /></button>
                           </div>
                           <div><label className={labelClass}>Asset URL</label><input type="text" value={icon.url} onChange={e => updateArrayItem('brandIcons', i, 'url', e.target.value)} className={inputClass} /></div>
                           <div><label className={labelClass}>Usage Rights Agreement</label><input type="text" value={icon.usageRights} onChange={e => updateArrayItem('brandIcons', i, 'usageRights', e.target.value)} className={inputClass} /></div>
                           <div><label className={labelClass}>Implementation Settings</label><textarea rows={3} value={icon.settings} onChange={e => updateArrayItem('brandIcons', i, 'settings', e.target.value)} className={`${inputClass} resize-none h-24`} /></div>
                        </div>
                        <div className="bg-white dark:bg-slate-950 rounded-[2.5rem] p-12 border border-slate-100 dark:border-white/5 flex items-center justify-center relative overflow-hidden shadow-inner group-hover:border-sky-500/20 transition-all">
                           <div className="absolute inset-0 bg-grid-white/[0.01] pointer-events-none" />
                           {icon.url ? (
                              <div className="relative">
                                 <div className="absolute inset-0 bg-sky-500/10 blur-3xl rounded-full scale-150 animate-pulse" />
                                 <img src={icon.url} className="w-40 h-40 object-contain relative z-10 drop-shadow-2xl" />
                              </div>
                           ) : (
                              <div className="flex flex-col items-center opacity-10">
                                 <Hexagon className="w-24 h-24 mb-4" />
                                 <span className="text-[10px] font-black uppercase tracking-[0.4em]">Asset Ref Missing</span>
                              </div>
                           )}
                        </div>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'colors' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><Palette className="w-8 h-8 text-blue-500" /> Palette Lab</h3>
                   <button onClick={() => addToArray('colors', { name: 'New Color', hex: '#3b82f6', usage: 'primary' })} className="px-6 py-3 bg-blue-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Chromatic Node</button>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                   {(formData.colors || []).map((c, i) => (
                     <div key={i} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-6">
                        <div className="flex items-center gap-4">
                           <div className="w-16 h-16 rounded-2xl shadow-xl border-4 border-white dark:border-slate-800" style={{ backgroundColor: c.hex }} />
                           <div className="flex-1">
                              <input type="text" value={c.name} onChange={e => updateArrayItem('colors', i, 'name', e.target.value)} className="w-full bg-transparent border-none p-0 text-lg font-black dark:text-white uppercase focus:ring-0" />
                              <span className="text-[10px] font-mono text-slate-500">{c.hex.toUpperCase()}</span>
                           </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                           <div><label className={labelClass}>HEX Code</label><input type="text" value={c.hex} onChange={e => updateArrayItem('colors', i, 'hex', e.target.value)} className={`${inputClass} !p-3 font-mono`} /></div>
                           <div><label className={labelClass}>Usage</label><select value={c.usage} onChange={e => updateArrayItem('colors', i, 'usage', e.target.value)} className={`${inputClass} !p-3`}><option value="primary">Primary</option><option value="secondary">Secondary</option><option value="accent">Accent</option><option value="neutral">Neutral</option></select></div>
                        </div>
                        <button onClick={() => removeFromArray('colors', i)} className="text-[9px] font-black text-red-500 uppercase tracking-widest flex items-center gap-2 hover:bg-red-500/10 px-4 py-2 rounded-xl transition-all"><Trash2 className="w-4 h-4" /> Purge</button>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'gradients' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><Flame className="w-8 h-8 text-orange-500" /> Flux Nodes</h3>
                   <button onClick={() => addToArray('gradients', { name: 'Core Flux', css: 'linear-gradient(90deg, #3b82f6 0%, #06b6d4 100%)' })} className="px-6 py-3 bg-orange-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Gradient</button>
                </div>
                <div className="grid md:grid-cols-2 gap-8">
                   {(formData.gradients || []).map((g, i) => (
                     <div key={i} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-6">
                        <input type="text" value={g.name} onChange={e => updateArrayItem('gradients', i, 'name', e.target.value)} className="w-full bg-transparent border-none p-0 text-xl font-black dark:text-white uppercase focus:ring-0" placeholder="Gradient Label..." />
                        <div><label className={labelClass}>CSS Source Code</label><textarea rows={2} value={g.css} onChange={e => updateArrayItem('gradients', i, 'css', e.target.value)} className={`${inputClass} font-mono text-xs`} /></div>
                        <div className="h-24 rounded-2xl shadow-xl" style={{ background: g.css }} />
                        <button onClick={() => removeFromArray('gradients', i)} className="text-[9px] font-black text-red-500 uppercase tracking-widest flex items-center gap-2"><Trash2 className="w-4 h-4" /> Remove</button>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'patterns' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><Grid className="w-8 h-8 text-blue-500" /> Geometric Primitives</h3>
                   <button onClick={() => addToArray('patterns', { name: 'New Pattern', url: '' })} className="px-6 py-3 bg-blue-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Texture</button>
                </div>
                <div className="grid md:grid-cols-2 gap-8">
                   {(formData.patterns || []).map((p, i) => (
                     <div key={i} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-6">
                        <input type="text" value={p.name} onChange={e => updateArrayItem('patterns', i, 'name', e.target.value)} className="w-full bg-transparent border-none p-0 text-xl font-black dark:text-white uppercase focus:ring-0" placeholder="Texture Name..." />
                        <div><label className={labelClass}>Direct Pattern URL</label><input type="text" value={p.url} onChange={e => updateArrayItem('patterns', i, 'url', e.target.value)} className={inputClass} /></div>
                        <div className="h-40 rounded-2xl shadow-inner border border-white/5" style={{ backgroundImage: `url(${p.url})`, backgroundRepeat: 'repeat' }} />
                        <button onClick={() => removeFromArray('patterns', i)} className="text-[9px] font-black text-red-500 uppercase tracking-widest flex items-center gap-2"><Trash2 className="w-4 h-4" /> Purge</button>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'misuse' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><Ban className="w-8 h-8 text-red-500" /> Anti-Pattern Registry</h3>
                   <button onClick={() => addToArray('logoUsageDonts', { description: 'Prohibited Variant', url: '' })} className="px-6 py-3 bg-red-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Warning</button>
                </div>
                <div className="grid md:grid-cols-2 gap-8">
                   {(formData.logoUsageDonts || []).map((d, i) => (
                     <div key={i} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-red-500/20 space-y-6">
                        <div><label className={labelClass}>Visual Specimen URL</label><input type="text" value={d.url} onChange={e => updateArrayItem('logoUsageDonts', i, 'url', e.target.value)} className={inputClass} /></div>
                        <div><label className={labelClass}>Violation Explanation</label><textarea rows={2} value={d.description} onChange={e => updateArrayItem('logoUsageDonts', i, 'description', e.target.value)} className={`${inputClass} h-20 resize-none`} /></div>
                        <div className="aspect-video bg-black/40 rounded-2xl flex items-center justify-center p-6 border border-white/5 relative overflow-hidden">
                           {d.url && <img src={d.url} className="max-h-full max-w-full grayscale opacity-40" />}
                           <div className="absolute inset-0 flex items-center justify-center pointer-events-none"><X className="w-24 h-24 text-red-500/30" /></div>
                        </div>
                        <button onClick={() => removeFromArray('logoUsageDonts', i)} className="text-[9px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2"><Trash2 className="w-4 h-4" /> Remove Entry</button>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'typography' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><TypeIcon className="w-8 h-8 text-blue-500" /> Typography Registry</h3>
                   <button onClick={() => addToArray('typography', { name: 'New Typeface', role: 'Body', fontFamily: 'Inter', sampleText: 'Standard Protocol', downloadUrl: '' })} className="px-6 py-3 bg-blue-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Font</button>
                </div>
                <div className="space-y-6">
                   {(formData.typography || []).map((t, i) => (
                     <div key={i} className="p-10 bg-slate-50 dark:bg-slate-900 rounded-[3rem] border border-slate-200 dark:border-white/5 grid lg:grid-cols-2 gap-10">
                        <div className="space-y-6">
                           <div className="grid grid-cols-2 gap-4">
                              <div><label className={labelClass}>Font Name</label><input type="text" value={t.name} onChange={e => updateArrayItem('typography', i, 'name', e.target.value)} className={inputClass} /></div>
                              <div><label className={labelClass}>Family Definition</label><input type="text" value={t.fontFamily} onChange={e => updateArrayItem('typography', i, 'fontFamily', e.target.value)} className={inputClass} placeholder="'Poppins', sans-serif" /></div>
                           </div>
                           <div className="grid grid-cols-2 gap-4">
                              <div><label className={labelClass}>Assigned Role</label><select value={t.role} onChange={e => updateArrayItem('typography', i, 'role', e.target.value)} className={inputClass}><option value="Heading">Heading</option><option value="Body">Body</option><option value="Display">Display</option><option value="Web Safe">Web Safe</option></select></div>
                              <div><label className={labelClass}>Download link</label><input type="text" value={t.downloadUrl} onChange={e => updateArrayItem('typography', i, 'downloadUrl', e.target.value)} className={inputClass} /></div>
                           </div>
                           <button onClick={() => removeFromArray('typography', i)} className="text-[9px] font-black text-red-500 uppercase flex items-center gap-2"><Trash2 className="w-4 h-4" /> De-register</button>
                        </div>
                        <div className="bg-white dark:bg-black/40 p-12 rounded-[2rem] flex flex-col justify-center border border-slate-100 dark:border-white/5 relative overflow-hidden">
                           <span className="text-[9px] font-black uppercase text-slate-400 absolute top-8 left-10">Live Rendering Node</span>
                           <div style={{ fontFamily: t.fontFamily }} className="text-4xl lg:text-6xl dark:text-white uppercase tracking-tight truncate">{t.sampleText || 'Executive Specimen'}</div>
                        </div>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'textStyles' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><Code className="w-8 h-8 text-emerald-500" /> Semantic Hierarchies</h3>
                   <button onClick={() => addToArray('textStyles', { tag: 'h1', name: 'Header Large', size: '48px', weight: '900', lineHeight: '1', sample: 'IMPACT' })} className="px-6 py-3 bg-emerald-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Style</button>
                </div>
                <div className="space-y-4">
                   {(formData.textStyles || []).map((s, i) => (
                     <div key={i} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 grid lg:grid-cols-4 gap-6 items-center">
                        <div><label className={labelClass}>HTML Tag</label><input type="text" value={s.tag} onChange={e => updateArrayItem('textStyles', i, 'tag', e.target.value)} className={inputClass} /></div>
                        <div><label className={labelClass}>Size / Weight</label><div className="flex gap-2"><input type="text" value={s.size} onChange={e => updateArrayItem('textStyles', i, 'size', e.target.value)} className={inputClass} /><input type="text" value={s.weight} onChange={e => updateArrayItem('textStyles', i, 'weight', e.target.value)} className={inputClass} /></div></div>
                        <div><label className={labelClass}>Sample Text</label><input type="text" value={s.sample} onChange={e => updateArrayItem('textStyles', i, 'sample', e.target.value)} className={inputClass} /></div>
                        <div className="flex items-center gap-4">
                           <div className="flex-1 px-6 py-4 bg-white dark:bg-black/40 rounded-xl border border-white/5 truncate"><span style={{ fontSize: s.size, fontWeight: s.weight, lineHeight: s.lineHeight }} className="dark:text-white uppercase">{s.sample}</span></div>
                           <button onClick={() => removeFromArray('textStyles', i)} className="p-3 text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-5 h-5" /></button>
                        </div>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'icons' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
                   <h3 className={subHeadingClass}><Sparkles className="w-8 h-8 text-indigo-500" /> Iconography Studio</h3>
                   <div className="flex p-1 bg-slate-100 dark:bg-slate-900 rounded-2xl w-fit">
                      <button 
                        onClick={() => setIconSubMode('ai')} 
                        className={`flex items-center gap-2 px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${iconSubMode === 'ai' ? 'bg-white dark:bg-slate-800 text-indigo-600 shadow-sm' : 'text-slate-500'}`}
                      >
                        <Wand2 className="w-3.5 h-3.5" /> Neural Studio
                      </button>
                      <button 
                        onClick={() => setIconSubMode('manual')} 
                        className={`flex items-center gap-2 px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${iconSubMode === 'manual' ? 'bg-white dark:bg-slate-800 text-indigo-600 shadow-sm' : 'text-slate-500'}`}
                      >
                        <Layers className="w-3.5 h-3.5" /> Manual Registry
                      </button>
                   </div>
                </div>

                {iconSubMode === 'ai' ? (
                  <div className="h-[600px]">
                    <AIIconStudio brand={formData} onCommit={handleAICommit} />
                  </div>
                ) : (
                  <div className="space-y-8">
                    <div className="flex justify-end">
                      <button onClick={() => addToArray('icons', { name: 'New Icon', svgPath: 'M12 12h.01', category: 'General' })} className="px-6 py-3 bg-indigo-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Register Vector</button>
                    </div>
                    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                       {(formData.icons || []).map((icon, i) => (
                         <div key={i} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-6">
                            <div className="flex justify-between items-center"><input type="text" value={icon.name} onChange={e => updateArrayItem('icons', i, 'name', e.target.value)} className="bg-transparent border-none p-0 text-sm font-black dark:text-white uppercase focus:ring-0" /><button onClick={() => removeFromArray('icons', i)} className="text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button></div>
                            <div className="aspect-square bg-white dark:bg-black/40 rounded-3xl p-8 flex items-center justify-center border border-white/5 shadow-inner">
                               <svg className="w-full h-full dark:text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d={icon.svgPath} strokeLinecap="round" strokeLinejoin="round" /></svg>
                            </div>
                            <div><label className={labelClass}>SVG Path Data</label><textarea value={icon.svgPath} onChange={e => updateArrayItem('icons', i, 'svgPath', e.target.value)} className={`${inputClass} font-mono text-[9px] h-20 resize-none`} /></div>
                         </div>
                       ))}
                    </div>

                    {/* AI Set Display */}
                    {(formData.aiIconSets || []).length > 0 && (
                      <div className="pt-12 border-t border-slate-200 dark:border-white/5">
                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mb-8">Registered AI Collections</h4>
                        <div className="grid gap-6">
                          {(formData.aiIconSets || []).map((set, i) => (
                            <div key={i} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 flex items-center justify-between">
                              <div className="flex items-center gap-6">
                                <div className="p-4 bg-indigo-600 rounded-2xl text-white shadow-lg"><BrainCircuit className="w-6 h-6" /></div>
                                <div>
                                  <span className="block font-black text-white uppercase tracking-tight">{set.name}</span>
                                  <span className="block text-[10px] text-slate-500 uppercase tracking-widest">{set.icons?.length || 0} Vector Nodes</span>
                                </div>
                              </div>
                              <button onClick={() => removeFromArray('aiIconSets', i)} className="p-3 text-slate-500 hover:text-red-500 transition-colors"><Trash2 className="w-5 h-5" /></button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
             </div>
           )}

           {activeStudio === 'imagery' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <h3 className={subHeadingClass}><ImageIcon className="w-8 h-8 text-blue-500" /> Imagery Guidelines</h3>
                <div><label className={labelClass}>Global Directive Manual</label><textarea rows={4} value={formData.imageryGuidelines || ''} onChange={e => updateField('imageryGuidelines', e.target.value)} className={`${inputClass} h-40 leading-relaxed`} placeholder="Define the visual aesthetic, lighting, and composition rules..." /></div>
                <div>
                   <div className="flex items-center justify-between mb-8"><label className={labelClass}>Specimen Gallery</label><button onClick={() => addToArray('imagery', { url: '', description: 'New Specimen', type: 'do' })} className="text-[10px] font-black text-blue-500 dark:text-blue-400 uppercase tracking-widest">+ Add Asset</button></div>
                   <div className="grid md:grid-cols-2 gap-8">
                      {(formData.imagery || []).map((img, i) => (
                        <div key={i} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-6">
                           <div className="grid grid-cols-2 gap-4">
                              <div><label className={labelClass}>Asset URL</label><input type="text" value={img.url} onChange={e => updateArrayItem('imagery', i, 'url', e.target.value)} className={inputClass} /></div>
                              <div><label className={labelClass}>Classification</label><select value={img.type} onChange={e => updateArrayItem('imagery', i, 'type', e.target.value)} className={inputClass}><option value="do">Approved (DO)</option><option value="dont">Prohibited (DONT)</option></select></div>
                           </div>
                           <input type="text" value={img.description} onChange={e => updateArrayItem('imagery', i, 'description', e.target.value)} className="w-full bg-transparent border-none p-0 text-sm font-bold dark:text-slate-400 focus:ring-0" placeholder="Contextual note..." />
                           <div className="aspect-video rounded-2xl overflow-hidden bg-black/20 border border-white/5">{img.url && <img src={img.url} className="w-full h-full object-cover" />}</div>
                           <button onClick={() => removeFromArray('imagery', i)} className="text-[9px] font-black text-red-500 uppercase tracking-widest flex items-center gap-2"><Trash2 className="w-4 h-4" /> Purge</button>
                        </div>
                      ))}
                   </div>
                </div>
             </div>
           )}

           {activeStudio === 'social' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><Smartphone className="w-8 h-8 text-sky-500" /> Social Tag Protocol</h3>
                   <button onClick={() => addToArray('socials', { platform: 'LinkedIn', handle: '', url: '', color: '#0077b5' })} className="px-6 py-3 bg-sky-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Channel</button>
                </div>
                <div className="grid md:grid-cols-2 gap-6">
                   {(formData.socials || []).map((s, i) => (
                     <div key={i} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-6">
                        <div className="grid grid-cols-2 gap-4">
                           <div><label className={labelClass}>Platform</label><input type="text" value={s.platform} onChange={e => updateArrayItem('socials', i, 'platform', e.target.value)} className={inputClass} /></div>
                           <div><label className={labelClass}>Brand Platform Color</label><input type="text" value={s.color} onChange={e => updateArrayItem('socials', i, 'color', e.target.value)} className={`${inputClass} font-mono`} /></div>
                        </div>
                        <div><label className={labelClass}>Handle (@...)</label><input type="text" value={s.handle} onChange={e => updateArrayItem('socials', i, 'handle', e.target.value)} className={inputClass} /></div>
                        <div><label className={labelClass}>Full Protocol URL</label><input type="text" value={s.url} onChange={e => updateArrayItem('socials', i, 'url', e.target.value)} className={inputClass} /></div>
                        <button onClick={() => removeFromArray('socials', i)} className="text-[9px] font-black text-red-500 uppercase tracking-widest flex items-center gap-2"><Trash2 className="w-4 h-4" /> De-activate</button>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'banners' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><LayoutDashboard className="w-8 h-8 text-blue-500" /> Digital Footprint</h3>
                   <button onClick={() => addToArray('digitalBanners', { size: 'LinkedIn Header', url: '' })} className="px-6 py-3 bg-blue-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Asset</button>
                </div>
                <div className="grid md:grid-cols-2 gap-8">
                   {(formData.digitalBanners || []).map((b, i) => (
                     <div key={i} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-6">
                        <div><label className={labelClass}>Format Label</label><input type="text" value={b.size} onChange={e => updateArrayItem('digitalBanners', i, 'size', e.target.value)} className={inputClass} /></div>
                        <div><label className={labelClass}>Master Asset URL</label><input type="text" value={b.url} onChange={e => updateArrayItem('digitalBanners', i, 'url', e.target.value)} className={inputClass} /></div>
                        <div className="aspect-[4/1] bg-black/40 rounded-2xl overflow-hidden border border-white/5">{b.url && <img src={b.url} className="w-full h-full object-cover" />}</div>
                        <button onClick={() => removeFromArray('digitalBanners', i)} className="text-[9px] font-black text-red-500 uppercase tracking-widest flex items-center gap-2"><Trash2 className="w-4 h-4" /> Purge</button>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'cinematic' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><Film className="w-8 h-8 text-purple-500" /> Cinematic Assets</h3>
                   <button onClick={() => addToArray('cinematicAssets', { name: 'New Loop', type: 'video', url: '' })} className="px-6 py-3 bg-purple-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Motion</button>
                </div>
                <div className="grid md:grid-cols-2 gap-8">
                   {(formData.cinematicAssets || []).map((asset, i) => (
                     <div key={i} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-6">
                        <div className="flex justify-between items-center"><input type="text" value={asset.name} onChange={e => updateArrayItem('cinematicAssets', i, 'name', e.target.value)} className="bg-transparent border-none p-0 text-lg font-black dark:text-white uppercase focus:ring-0" /><button onClick={() => removeFromArray('cinematicAssets', i)} className="text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button></div>
                        <div className="grid grid-cols-2 gap-4">
                           <div><label className={labelClass}>Type</label><select value={asset.type} onChange={e => updateArrayItem('cinematicAssets', i, 'type', e.target.value)} className={inputClass}><option value="video">Main Video</option><option value="motion">Motion Loop</option></select></div>
                           <div><label className={labelClass}>Stream URL</label><input type="text" value={asset.url} onChange={e => updateArrayItem('cinematicAssets', i, 'url', e.target.value)} className={inputClass} /></div>
                        </div>
                        <div className="aspect-video bg-black rounded-2xl overflow-hidden flex items-center justify-center border border-white/5"><Film className="w-12 h-12 text-slate-800" /></div>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'caseStudies' || activeStudio === 'brochures' || activeStudio === 'spotlights' ? (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><FileSearch className="w-8 h-8 text-blue-500" /> {activeStudio.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</h3>
                   <button onClick={() => addToArray(activeStudio, { title: 'New Node', description: 'Description...', previewUrl: '', templateUrl: '', category: 'Enterprise' })} className="px-6 py-3 bg-blue-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Registry</button>
                </div>
                <div className="grid md:grid-cols-2 gap-8">
                   {(formData[activeStudio] || []).map((doc, idx) => (
                      <div key={idx} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-6">
                         <div className="flex justify-between items-center"><input type="text" value={doc.title} onChange={e => updateArrayItem(activeStudio, idx, 'title', e.target.value)} className="bg-transparent border-none p-0 text-xl font-black dark:text-white uppercase focus:ring-0 w-full" /><button onClick={() => removeFromArray(activeStudio, idx)} className="text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-5 h-5" /></button></div>
                         <div className="grid grid-cols-2 gap-4">
                            <div><label className={labelClass}>Classification</label><input type="text" value={doc.category} onChange={e => updateArrayItem(activeStudio, idx, 'category', e.target.value)} className={inputClass} /></div>
                            <div><label className={labelClass}>Visual Key URL</label><input type="text" value={doc.previewUrl} onChange={e => updateArrayItem(activeStudio, idx, 'previewUrl', e.target.value)} className={inputClass} /></div>
                         </div>
                         <div><label className={labelClass}>Master Template Link</label><input type="text" value={doc.templateUrl} onChange={e => updateArrayItem(activeStudio, idx, 'templateUrl', e.target.value)} className={inputClass} /></div>
                         <div><label className={labelClass}>Executive Summary</label><textarea rows={2} value={doc.description} onChange={e => updateArrayItem(activeStudio, idx, 'description', e.target.value)} className={`${inputClass} h-24 resize-none`} /></div>
                      </div>
                   ))}
                </div>
             </div>
           ) : null}

           {activeStudio === 'signatures' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><Mail className="w-8 h-8 text-blue-500" /> Signature Protocol</h3>
                   <button onClick={() => addToArray('signatures', { name: 'Protocol V1', role: 'Executive', html: '' })} className="px-6 py-3 bg-blue-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Profile</button>
                </div>
                <div className="grid gap-8">
                   {(formData.signatures || []).map((sig, i) => (
                     <div key={i} className="p-10 bg-slate-50 dark:bg-slate-900 rounded-[3rem] border border-slate-200 dark:border-white/5 grid lg:grid-cols-2 gap-12">
                        <div className="space-y-6">
                           <div className="grid grid-cols-2 gap-4">
                              <div><label className={labelClass}>Label</label><input type="text" value={sig.name} onChange={e => updateArrayItem('signatures', i, 'name', e.target.value)} className={inputClass} /></div>
                              <div><label className={labelClass}>Role Mapping</label><input type="text" value={sig.role} onChange={e => updateArrayItem('signatures', i, 'role', e.target.value)} className={inputClass} /></div>
                           </div>
                           <div><label className={labelClass}>HTML Buffer</label><textarea rows={10} value={sig.html} onChange={e => updateArrayItem('signatures', i, 'html', e.target.value)} className={`${inputClass} font-mono text-[10px] h-64`} /></div>
                           <button onClick={() => removeFromArray('signatures', i)} className="text-[9px] font-black text-red-500 uppercase flex items-center gap-2"><Trash2 className="w-4 h-4" /> Purge</button>
                        </div>
                        <div className="bg-white dark:bg-black/40 rounded-[2.5rem] p-12 border border-slate-100 dark:border-white/5 flex items-start justify-center shadow-inner relative overflow-auto max-h-[500px] custom-scrollbar"><span className="text-[9px] font-black uppercase text-slate-400 absolute top-8 left-10">Live Node Preview</span><div className="w-full scale-90 origin-top mt-10" dangerouslySetInnerHTML={{ __html: sig.html }} /></div>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'qr' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <h3 className={subHeadingClass}><QrCode className="w-8 h-8 text-blue-500" /> Access Ports (QR)</h3>
                <div className="bg-slate-50 dark:bg-slate-900 rounded-[3rem] p-12 border border-slate-200 dark:border-white/5 grid lg:grid-cols-2 gap-16">
                   <div className="space-y-10">
                      <div><label className={labelClass}>Default Destination Protocol</label><input type="text" value={formData.qrSettings?.defaultUrl || ''} onChange={e => updateField('qrSettings', { ...formData.qrSettings, defaultUrl: e.target.value })} className={inputClass} /></div>
                      <div className="grid grid-cols-2 gap-8">
                         <div><label className={labelClass}>Foreground</label><input type="text" value={formData.qrSettings?.fgColor || ''} onChange={e => updateField('qrSettings', { ...formData.qrSettings, fgColor: e.target.value })} className={inputClass} /></div>
                         <div><label className={labelClass}>Background</label><input type="text" value={formData.qrSettings?.bgColor || ''} onChange={e => updateField('qrSettings', { ...formData.qrSettings, bgColor: e.target.value })} className={inputClass} /></div>
                      </div>
                      <label className="flex items-center justify-between p-6 bg-white dark:bg-black/20 rounded-2xl border border-slate-100 dark:border-white/5 cursor-pointer">
                         <div className="flex items-center gap-4"><div className="p-2 bg-blue-500/10 text-blue-500 rounded-lg"><Palette className="w-5 h-5" /></div><span className="text-sm font-black uppercase tracking-widest text-slate-500">Enable Custom Chromatics</span></div>
                         <input type="checkbox" checked={formData.qrSettings?.useCustomColors} onChange={e => updateField('qrSettings', { ...formData.qrSettings, useCustomColors: e.target.checked })} className="w-6 h-6 rounded-lg bg-slate-200 dark:bg-slate-800 border-none checked:bg-blue-600" />
                      </label>
                   </div>
                   <div className="flex flex-col items-center justify-center border-l border-slate-200 dark:border-white/5 pl-16 opacity-30"><QrCode className="w-48 h-48 mb-4" /><span className="text-[10px] font-black uppercase tracking-[0.4em]">Visual Logic Linked</span></div>
                </div>
             </div>
           )}

           {activeStudio === 'templates' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><FileArchive className="w-8 h-8 text-blue-500" /> Master Templates</h3>
                   <button onClick={() => addToArray('templates', { name: 'Core Template', description: '', category: 'DOCS', fileType: 'PPTX', fileSize: '5MB', downloadUrl: '', isCallout: false })} className="px-6 py-3 bg-blue-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Add Protocol</button>
                </div>
                <div className="grid md:grid-cols-2 gap-8">
                   {(formData.templates || []).map((t, i) => (
                     <div key={i} className="p-10 bg-slate-50 dark:bg-slate-900 rounded-[3rem] border border-slate-200 dark:border-white/5 space-y-8">
                        <div className="flex justify-between items-center"><input type="text" value={t.name} onChange={e => updateArrayItem('templates', i, 'name', e.target.value)} className="bg-transparent border-none p-0 text-xl font-black dark:text-white uppercase focus:ring-0 w-full" /><button onClick={() => removeFromArray('templates', i)} className="text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-5 h-5" /></button></div>
                        <div className="grid grid-cols-2 gap-4">
                           <div><label className={labelClass}>Format</label><input type="text" value={t.fileType} onChange={e => updateArrayItem('templates', i, 'fileType', e.target.value)} className={inputClass} /></div>
                           <div><label className={labelClass}>Size</label><input type="text" value={t.fileSize} onChange={e => updateArrayItem('templates', i, 'fileSize', e.target.value)} className={inputClass} /></div>
                        </div>
                        <div><label className={labelClass}>Direct Download Link</label><input type="text" value={t.downloadUrl} onChange={e => updateArrayItem('templates', i, 'downloadUrl', e.target.value)} className={inputClass} /></div>
                        <div><label className={labelClass}>Description</label><textarea rows={3} value={t.description} onChange={e => updateArrayItem('templates', i, 'description', e.target.value)} className={`${inputClass} resize-none h-24`} /></div>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'assets' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <div className="flex items-center justify-between mb-8">
                   <h3 className={subHeadingClass}><DownloadCloud className="w-8 h-8 text-blue-500" /> Global Asset Vault</h3>
                   <button onClick={() => addToArray('assets', { name: 'Asset Node', type: 'archive', format: 'ZIP', size: '10MB', url: '' })} className="px-6 py-3 bg-blue-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg">+ Register Node</button>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                   {(formData.assets || []).map((ast, i) => (
                     <div key={i} className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-6">
                        <div className="flex justify-between items-center"><input type="text" value={ast.name} onChange={e => updateArrayItem('assets', i, 'name', e.target.value)} className="bg-transparent border-none p-0 text-sm font-black dark:text-white uppercase focus:ring-0 w-full" /><button onClick={() => removeFromArray('assets', i)} className="text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button></div>
                        <div className="grid grid-cols-2 gap-4">
                           <div><label className={labelClass}>Format</label><input type="text" value={ast.format} onChange={e => updateArrayItem('assets', i, 'format', e.target.value)} className={inputClass} /></div>
                           <div><label className={labelClass}>Size</label><input type="text" value={ast.size} onChange={e => updateArrayItem('assets', i, 'size', e.target.value)} className={inputClass} /></div>
                        </div>
                        <div><label className={labelClass}>Direct Asset URL</label><input type="text" value={ast.url} onChange={e => updateArrayItem('assets', i, 'url', e.target.value)} className={inputClass} /></div>
                     </div>
                   ))}
                </div>
             </div>
           )}

           {activeStudio === 'governance' && (
             <div className="space-y-12 animate-in fade-in duration-500">
                <h3 className={subHeadingClass}><Lock className="w-8 h-8 text-red-500" /> Governance Protocol</h3>
                <div className="grid md:grid-cols-2 gap-8">
                   <div className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-8">
                      <h4 className="text-xs font-black text-slate-400 dark:text-slate-300 uppercase tracking-[0.2em] border-b border-white/5 pb-4">Security & Persistence</h4>
                      <div className="space-y-4">
                         <label className="flex items-center justify-between group cursor-pointer p-4 bg-white dark:bg-black/20 rounded-2xl border border-slate-100 dark:border-white/5"><div className="flex items-center gap-3"><div className="p-2 bg-blue-600/10 text-blue-600 rounded-lg"><Eye className="w-4 h-4" /></div><span className="text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-300">Show in Dashboard</span></div><input type="checkbox" checked={formData.governance?.showInDashboard} onChange={e => updateGovernance('showInDashboard', e.target.checked)} className="w-6 h-6 rounded-lg bg-slate-200 dark:bg-slate-800 border-none checked:bg-blue-600" /></label>
                         <label className="flex items-center justify-between group cursor-pointer p-4 bg-white dark:bg-black/20 rounded-2xl border border-slate-100 dark:border-white/5"><div className="flex items-center gap-3"><div className="p-2 bg-indigo-500/10 text-indigo-500 rounded-lg"><ShieldCheck className="w-4 h-4" /></div><span className="text-xs font-black uppercase tracking-widest text-slate-500 dark:text-slate-300">Metadata Shield Active</span></div><input type="checkbox" checked={formData.governance?.metadataShield} onChange={e => updateGovernance('metadataShield', e.target.checked)} className="w-6 h-6 rounded-lg bg-slate-200 dark:bg-slate-800 border-none checked:bg-blue-600" /></label>
                      </div>
                   </div>
                   <div className="p-8 bg-slate-50 dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-white/5 space-y-8">
                      <h4 className="text-xs font-black text-slate-400 dark:text-slate-300 uppercase tracking-[0.2em] border-b border-white/5 pb-4">Infrastructure</h4>
                      <div className="space-y-6">
                         <div><label className={labelClass}>Synthesis Engine Level</label><div className="flex p-1 bg-slate-200 dark:bg-slate-800 rounded-xl"><button onClick={() => updateGovernance('neuralLevel', 'flash')} className={`flex-1 py-3 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${formData.governance?.neuralLevel === 'flash' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-sm' : 'text-slate-500'}`}>Flash Core</button><button onClick={() => updateGovernance('neuralLevel', 'pro')} className={`flex-1 py-3 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${formData.governance?.neuralLevel === 'pro' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-sm' : 'text-slate-500'}`}>Pro Node</button></div></div>
                         <div><label className={labelClass}>Storage Allocation Priority</label><select value={formData.governance?.storagePriority} onChange={e => updateGovernance('storagePriority', e.target.value)} className={inputClass}><option value="local">Local Persistence Only</option><option value="cloud">Cloud Synchronized</option><option value="high">High Availability Cluster</option></select></div>
                      </div>
                   </div>
                </div>
             </div>
           )}

           </div>
        </main>
      </div>

      {/* STUDIO INFO FOOTER */}
      <div className="px-10 py-5 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-white/5 flex items-center justify-between shrink-0 relative z-30">
         <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-[9px] font-black uppercase text-slate-400 dark:text-slate-300 tracking-widest"><ShieldCheck className="w-3.5 h-3.5 text-emerald-500" /> Metadata Protection: ON</div>
            <div className="w-px h-3 bg-slate-200 dark:bg-white/10" />
            <div className="flex items-center gap-2 text-[9px] font-black uppercase text-slate-400 dark:text-slate-300 tracking-widest"><Zap className="w-3.5 h-3.5 text-blue-500" /> Auto-Mirror: ACTIVE</div>
         </div>
         <span className="text-[8px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-[0.4em]">BrandHub Master Studio Protocol v2.6.0-FINAL</span>
      </div>
    </div>
  );
};

export default BrandEditor;
