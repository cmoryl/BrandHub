
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import Sidebar from './Sidebar';
import BrandCard from './BrandCard';
import BrandDetail from './BrandDetail';
import BrandEditor from './BrandEditor';
import DataVault from './DataVault';
import StabilityMonitor from './StabilityMonitor';
import Settings from './Settings';
import OrionBackground from './OrionBackground';
import BrandBackground from './BrandBackground';
import Logo from './Logo';
import AdminLogin from './AdminLogin';
import RunthroughWizard from './RunthroughWizard';
import LiveWorkshop from './LiveWorkshop';
import { backend } from '../services/backendService';
import { useBrandStore } from '../store/brandStore';
import { useAutoSave } from '../hooks/useAutoSave';
import { Brand, View, Role } from '../types';
import { getDirectImageUrl } from '../utils/linkUtils';
import { 
  Plus, Search, ArrowRight, Command, 
  Bell, CircleCheckBig as CheckCircle2, AlertCircle, X, Moon, Sun, 
  Loader2, History, Lock, Radio, Clock, Building2, Box, Rocket, Zap, ShieldCheck, Sparkles
} from 'lucide-react';

const FAVORITES_KEY = 'brand_favorites';

type SortMode = 'recent' | 'companies' | 'products';

const App: React.FC = () => {
  const { 
    brands, setBrands, updateBrand, removeBrand, addBrand,
    isSyncing, lastSync, systemHealth, updateSystemHealth
  } = useBrandStore();
  
  const [isBooting, setIsBooting] = useState(true);
  const [currentView, setCurrentView] = useState<View>('landing');
  const [showWizard, setShowWizard] = useState(false);
  const [showWorkshop, setShowWorkshop] = useState(false);
  
  // Collapse State for Left Navigation - CRITICAL FIX
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  
  const [currentRole, setCurrentRole] = useState<Role>(() => {
    return localStorage.getItem('admin_session_active') === 'true' ? 'admin' : 'public';
  });

  const [selectedBrand, setSelectedBrand] = useState<Brand | null>(null);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortMode, setSortMode] = useState<SortMode>('recent');
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem(FAVORITES_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  useAutoSave();

  useEffect(() => {
    const init = async () => {
      try {
        const data = await backend.fetchBrands();
        setBrands(data);
      } finally { setIsBooting(false); }
    };
    init();
  }, [setBrands]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (currentView === 'landing' && e.shiftKey && e.key === 'A') {
        setCurrentView('login');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentView]);

  useEffect(() => {
    if (isDarkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [isDarkMode]);

  const handleAdminSuccess = () => {
    setCurrentRole('admin');
    setCurrentView('dashboard');
  };

  const handleUpdateBrand = async (updatedBrand: Brand, source: 'top-level' | 'sections' = 'top-level') => {
    const repaired = backend.migrateAndRepair(updatedBrand, source);
    repaired.updatedAt = Date.now();
    updateBrand(repaired);
    setSelectedBrand(repaired);
  };

  const handleDeleteBrand = async (brandId: string) => {
    try {
      await backend.deleteBrand(brandId);
      removeBrand(brandId);
      setSelectedBrand(null);
      setCurrentView('dashboard');
    } catch (err) {
      console.error("Purge Error:", err);
    }
  };

  const handleWizardComplete = (newBrand: Brand) => {
    addBrand(newBrand);
    setSelectedBrand(newBrand);
    setShowWizard(false);
    setCurrentView('brand-detail');
  };

  const filteredBrands = useMemo(() => {
    let list = (currentRole === 'public' ? brands.filter(b => b.isVisible) : brands)
      .filter(b => 
        b.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        b.industry?.toLowerCase().includes(searchQuery.toLowerCase())
      );

    if (sortMode === 'recent') {
      return [...list].sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    } else if (sortMode === 'companies') {
      return list.filter(b => b.entityType === 'brand');
    } else if (sortMode === 'products') {
      return list.filter(b => b.entityType === 'product');
    }
    return list;
  }, [brands, currentRole, searchQuery, sortMode]);

  const groupedBrands = useMemo(() => {
    if (sortMode !== 'recent') {
      return filteredBrands.reduce((acc, brand) => {
        const category = brand.category || 'Other';
        if (!acc[category]) acc[category] = [];
        acc[category].push(brand);
        return acc;
      }, {} as Record<string, Brand[]>);
    }
    return { 'Recent Protocols': filteredBrands };
  }, [filteredBrands, sortMode]);

  const activeBrandSettings = useMemo(() => {
    if ((currentView === 'brand-detail' || currentView === 'brand-editor') && selectedBrand?.backgroundSettings) {
      return selectedBrand.backgroundSettings;
    }
    return null;
  }, [currentView, selectedBrand]);

  const isNominal = systemHealth.status === 'nominal';

  if (isBooting) return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center text-white uppercase font-black tracking-widest gap-8">
      <Loader2 className="w-12 h-12 animate-spin text-blue-500" />
      <span className="animate-pulse">Initializing Protocol Hub...</span>
    </div>
  );

  if (currentView === 'landing') return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-center">
      <OrionBackground isDarkMode={true} />
      <div className="relative z-10">
        <Logo size="xl" variant="default" textClassName="text-white" />
        <h1 className="text-4xl lg:text-6xl font-black text-white mt-12 mb-6 uppercase tracking-tighter text-balance">Global Identity<br/><span className="text-blue-500">Orchestration</span></h1>
        <button onClick={() => setCurrentView('dashboard')} className="mt-8 px-12 py-6 bg-white text-black rounded-full font-black uppercase text-sm tracking-widest hover:scale-105 transition-all flex items-center gap-4 mx-auto">Enter Hub <ArrowRight className="w-5 h-5" /></button>
        <button onClick={() => setCurrentView('login')} className="mt-6 text-slate-500 hover:text-white text-[10px] font-black uppercase tracking-widest flex items-center gap-2 mx-auto"><Lock className="w-3 h-3" /> Admin Auth</button>
      </div>
    </div>
  );

  if (currentView === 'login') return (
    <AdminLogin 
      onSuccess={handleAdminSuccess} 
      onCancel={() => setCurrentView('landing')} 
    />
  );

  return (
    <div className={`flex min-h-screen font-sans transition-all duration-500 ${isDarkMode ? 'bg-[#02030a]' : 'bg-slate-50'}`}>
      <OrionBackground isDarkMode={isDarkMode} />
      {activeBrandSettings && <BrandBackground settings={activeBrandSettings} isDarkMode={isDarkMode} />}

      <Sidebar 
        activeView={currentView} 
        role={currentRole} 
        isSyncing={isSyncing} 
        lastSync={lastSync}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        onNavigate={() => { setCurrentView('dashboard'); setSelectedBrand(null); }} 
        onSwitchRole={() => { localStorage.removeItem('admin_session_active'); setCurrentRole('public'); setCurrentView('landing'); }}
        onBrandClick={(b) => { setSelectedBrand(b); setCurrentView('brand-detail'); }}
        onVaultClick={() => setCurrentView('vault')}
        onStabilityClick={() => setCurrentView('stability')}
        onSettingsClick={() => setCurrentView('settings')}
        selectedBrand={selectedBrand}
        onActiveBrandClick={() => selectedBrand && setCurrentView('brand-detail')}
      />
      
      {/* REFINED MAIN FRAME TRANSITIONS */}
      <main 
        className={`flex-1 transition-[margin-left] duration-500 ease-in-out relative z-10 flex flex-col ${
            isSidebarCollapsed ? 'ml-20' : 'ml-20 lg:ml-64'
        }`}
      >
        {currentView === 'dashboard' && (
          <div className="flex flex-col flex-1">
              <div className={`w-full backdrop-blur-md border-b border-slate-200 dark:border-white/5 py-3 px-6 lg:px-12 flex items-center justify-between sticky top-0 z-20 bg-white/95 dark:bg-[#02030a]/90 shadow-sm`}>
                <div className="flex items-center gap-4 text-left">
                  <div className="flex items-center gap-2">
                    <Radio className={`w-3 h-3 animate-pulse text-blue-600`} />
                    <span className={`text-[9px] font-black uppercase tracking-widest text-blue-600`}>System Pulse</span>
                  </div>
                  <div className={`h-3 w-px bg-slate-200 dark:bg-white/10`} />
                  <div className="flex items-center gap-6 overflow-hidden">
                    <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest whitespace-nowrap">
                       Protocol Health Verified:
                    </span>
                    <div className="flex items-center gap-4 animate-in slide-in-from-left-4 duration-1000">
                       <span className="text-[9px] font-bold text-emerald-500 uppercase flex items-center gap-1.5"><ShieldCheck className="w-3.5 h-3.5" /> All Nodes Grounded</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                   <div className="flex items-center gap-1.5">
                      <div className={`w-1 h-1 rounded-full ${isNominal ? 'bg-emerald-500' : 'bg-amber-500 animate-ping'}`} />
                      <span className={`text-[8px] font-black uppercase tracking-widest ${isNominal ? 'text-slate-500' : 'text-amber-500'}`}>
                         {isNominal ? 'Network Stable' : 'Action Required'}
                      </span>
                   </div>
                </div>
             </div>

             <div className="max-w-7xl mx-auto p-6 lg:p-12 animate-in fade-in duration-700 w-full text-left">
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-16 gap-8">
                    <div>
                      <h1 className={`text-5xl lg:text-7xl font-black tracking-tighter uppercase ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Brand Index</h1>
                      <div className="flex items-center gap-2 text-slate-500">
                        <Command className="w-4 h-4" />
                        <span className="text-sm font-medium uppercase tracking-widest">Protocol Governance Hub</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                       <div className="relative group">
                          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
                          <input 
                            type="text" placeholder="Filter Protocols..." value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className={`pl-12 pr-6 py-4 rounded-2xl border backdrop-blur-xl focus:ring-2 focus:ring-blue-500 transition-all text-sm font-bold min-w-[300px] ${isDarkMode ? 'bg-white/5 border-white/10 text-white' : 'bg-white border-slate-200 text-slate-900 shadow-sm'}`}
                          />
                       </div>
                       {currentRole === 'admin' && (
                        <button onClick={() => setShowWizard(true)} className="flex items-center gap-2 px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-blue-500/20 transition-all active:scale-95">
                          <Rocket className="w-4 h-4" /> Synthetic Deploy
                        </button>
                       )}
                    </div>
                </div>

                <div className={`flex p-1 rounded-2xl w-fit mb-12 border backdrop-blur-md ${isDarkMode ? 'bg-slate-900/30 border-white/5' : 'bg-slate-200 border-slate-300'}`}>
                   <button onClick={() => setSortMode('recent')} className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${sortMode === 'recent' ? (isDarkMode ? 'bg-slate-800/60 text-blue-400 shadow-xl' : 'bg-white text-blue-600 shadow-md') : 'text-slate-500'}`}>Most Recent</button>
                   <button onClick={() => setSortMode('companies')} className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${sortMode === 'companies' ? (isDarkMode ? 'bg-slate-800/60 text-blue-400 shadow-xl' : 'bg-white text-blue-600 shadow-md') : 'text-slate-500'}`}>Brands Only</button>
                   <button onClick={() => setSortMode('products')} className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${sortMode === 'products' ? (isDarkMode ? 'bg-slate-800/60 text-blue-400 shadow-xl' : 'bg-white text-blue-600 shadow-md') : 'text-slate-500'}`}>Products Only</button>
                </div>

                {(Object.entries(groupedBrands) as [string, Brand[]][]).map(([category, catBrands]) => (
                  <div key={category} className="mb-20">
                    <div className="flex items-center gap-6 mb-10">
                       <h2 className="text-xs font-black text-slate-400 uppercase tracking-[0.4em] whitespace-nowrap">{category}</h2>
                       <div className={`h-px w-full ${isDarkMode ? 'bg-white/5' : 'bg-slate-200'}`} />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                      {catBrands.map(b => (
                        <BrandCard 
                          key={b.id} 
                          brand={b} 
                          onClick={(brand) => { setSelectedBrand(brand); setCurrentView('brand-detail'); }} 
                          isFavorite={favorites.includes(b.id)}
                          toggleFavorite={() => {
                            const next = favorites.includes(b.id) ? favorites.filter(id => id !== b.id) : [...favorites, b.id];
                            setFavorites(next);
                            localStorage.setItem(FAVORITES_KEY, JSON.stringify(next));
                          }}
                        />
                      ))}
                    </div>
                  </div>
                ))}
             </div>
          </div>
        )}

        {currentView === 'brand-detail' && selectedBrand && (
          <BrandDetail 
            brand={selectedBrand} 
            brands={brands}
            isReadOnly={currentRole === 'public'} 
            onBack={() => setCurrentView('dashboard')} 
            isDarkMode={isDarkMode} 
            onToggleTheme={() => setIsDarkMode(!isDarkMode)} 
            onUpdateBrand={(b) => handleUpdateBrand(b, 'sections')} 
            onEdit={() => setCurrentView('brand-editor')} 
            onDelete={handleDeleteBrand}
            onWorkshopToggle={() => setShowWorkshop(true)}
            onBrandClick={(b) => { setSelectedBrand(b); setCurrentView('brand-detail'); }}
          />
        )}

        {currentView === 'brand-editor' && (
          <BrandEditor 
            brand={selectedBrand} 
            onSave={(b) => { handleUpdateBrand(b, 'top-level'); setCurrentView('brand-detail'); }} 
            onCancel={() => setCurrentView('dashboard')} 
          />
        )}
        
        {currentView === 'vault' && <DataVault brands={brands} onImport={(b) => setBrands(b)} onReset={() => backend.factoryReset().then(setBrands)} />}
        {currentView === 'stability' && <StabilityMonitor brands={brands} />}
        {currentView === 'settings' && <Settings />}
      </main>

      {showWorkshop && selectedBrand && <LiveWorkshop brand={selectedBrand} onClose={() => setShowWorkshop(false)} />}
      {showWizard && <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-xl p-6"><RunthroughWizard onComplete={handleWizardComplete} onCancel={() => setShowWizard(false)} /></div>}
    </div>
  );
};

export default App;
