
// @ts-nocheck
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  ArrowLeft, Edit, Moon, Sun, Layout, ArrowRight, FileDown, Loader2, Info, ChevronDown, 
  Check, Monitor, FileText, Sparkles, BrainCircuit, ImagePlus, Trash2, Maximize2, Zap, ShieldCheck,
  CircleCheckBig as CheckCircle2, FileArchive, X, Fingerprint, Activity, Terminal, Lock
} from 'lucide-react';
import { Brand, BrandSection, PageFormat } from '../types';
import { SectionRenderer } from './SectionRenderer';
import { getDirectImageUrl } from '../utils/linkUtils';
import { pdfExport } from '../services/pdfExportService';
import { useBrandStore } from '../store/brandStore';
import { backend } from '../services/backendService';
import { auditBrandBrain } from '../services/geminiService';
import BrandBackground from './BrandBackground';

const DEFAULT_PLACEHOLDER = 'https://images.unsplash.com/photo-1614850523296-d8c1af93d400?w=256&h=256&fit=crop';

interface BrandDetailProps {
  brand: Brand;
  brands: Brand[];
  isReadOnly: boolean;
  onBack: () => void;
  onEdit?: (brand: Brand) => void;
  onDelete?: (brandId: string) => void;
  onBrandClick: (brand: Brand) => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  onUpdateBrand?: (brand: Brand) => void;
}

const AuditOverlay = ({ audit, onClose }: { audit: any, onClose: () => void }) => (
  <div className="fixed inset-y-0 right-0 w-[500px] bg-slate-950/95 backdrop-blur-3xl border-l border-white/10 z-[300] shadow-2xl animate-in slide-in-from-right duration-500 font-sans flex flex-col">
    <div className="p-8 border-b border-white/10 flex items-center justify-between shrink-0">
       <div className="flex items-center gap-4">
          <div className="p-2.5 bg-indigo-600 rounded-xl text-white">
             <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
             <h3 className="text-xl font-black text-white uppercase tracking-tight">Neural Integrity Audit</h3>
             <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">Protocol Analysis Level 5</p>
          </div>
       </div>
       <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-lg text-slate-400 transition-colors">
          <X className="w-6 h-6" />
       </button>
    </div>
    
    <div className="flex-1 overflow-y-auto p-10 space-y-12 custom-scrollbar">
       <div className="text-left space-y-6">
          <div className="flex items-center justify-between">
             <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">Governance Maturity</span>
             <span className="text-3xl font-black text-indigo-400">{audit.maturityScore}%</span>
          </div>
          <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
             <div className="h-full bg-indigo-600 shadow-[0_0_15px_rgba(79,70,229,0.5)]" style={{ width: `${audit.maturityScore}%` }} />
          </div>
       </div>

       <div className="space-y-6 text-left">
          <h4 className="flex items-center gap-3 text-[10px] font-black text-slate-400 uppercase tracking-widest">
             <Terminal className="w-4 h-4 text-indigo-500" /> Strategic Analysis
          </h4>
          <p className="text-sm text-slate-300 leading-relaxed font-medium bg-white/5 p-6 rounded-2xl border border-white/5">
             {audit.analysis}
          </p>
       </div>

       <div className="space-y-6 text-left">
          <h4 className="flex items-center gap-3 text-[10px] font-black text-slate-400 uppercase tracking-widest">
             <Lock className="w-4 h-4 text-emerald-500" /> Structural Gaps
          </h4>
          <div className="grid gap-3">
             {audit.gaps.map((gap: string, i: number) => (
               <div key={i} className="flex items-start gap-3 p-4 bg-red-500/5 border border-red-500/10 rounded-xl">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0" />
                  <span className="text-xs font-bold text-red-400/80 leading-relaxed uppercase">{gap}</span>
               </div>
             ))}
          </div>
       </div>

       <div className="space-y-6 text-left">
          <h4 className="flex items-center gap-3 text-[10px] font-black text-slate-400 uppercase tracking-widest">
             <Sparkles className="w-4 h-4 text-blue-500" /> DNA Splice Recommendations
          </h4>
          <div className="space-y-4">
             {audit.suggestions.map((s: any, i: number) => (
               <div key={i} className="p-6 bg-blue-600/5 border border-blue-500/10 rounded-[2rem] space-y-3">
                  <div className="flex items-center justify-between">
                     <span className="px-3 py-1 bg-blue-600 text-white rounded-lg text-[8px] font-black uppercase tracking-widest">{s.field}</span>
                     <span className="text-[10px] font-black text-blue-400 uppercase">{s.label}</span>
                  </div>
                  <p className="text-xs text-white font-bold italic">"{s.improvement}"</p>
                  <p className="text-[10px] text-slate-500 leading-relaxed">{s.reasoning}</p>
               </div>
             ))}
          </div>
       </div>
    </div>

    <div className="p-8 bg-slate-900/50 border-t border-white/5 flex items-center justify-center shrink-0">
       <button onClick={onClose} className="px-12 py-4 bg-white text-black rounded-2xl font-black uppercase text-[10px] tracking-[0.2em] shadow-xl hover:scale-105 transition-all">Protocol Acknowledged</button>
    </div>
  </div>
);

const ExportOverlay = ({ status }: { status: string }) => (
  <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/90 backdrop-blur-3xl animate-in fade-in duration-700 font-sans">
    <div className="max-w-md w-full p-16 bg-white dark:bg-slate-900 rounded-[4rem] border border-white/10 shadow-2xl text-center space-y-12">
      <div className="relative mx-auto w-32 h-32">
        <div className="absolute inset-0 bg-blue-500 blur-[80px] opacity-30 animate-pulse" />
        <div className="relative z-10 w-full h-full bg-slate-950 rounded-[2rem] flex items-center justify-center border border-white/10 shadow-2xl rotate-6 animate-pulse">
          <BrainCircuit className="w-16 h-16 text-blue-500" />
        </div>
        <div className="absolute -top-4 -right-4 p-4 bg-blue-600 rounded-3xl animate-bounce shadow-2xl">
          <Sparkles className="w-6 h-6 text-white" />
        </div>
      </div>
      
      <div className="space-y-4">
        <h3 className="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Export Protocol</h3>
        <div className="flex items-center justify-center gap-3">
           <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
           <p className="text-[12px] text-slate-500 dark:text-slate-300 font-black uppercase tracking-[0.3em]">{status}</p>
        </div>
      </div>

      <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
        <div className="h-full bg-blue-600 animate-shimmer" style={{ width: '100%', backgroundSize: '200% 100%' }} />
      </div>
      
      <p className="text-[11px] text-slate-400 dark:text-slate-500 font-bold leading-relaxed uppercase tracking-[0.2em] max-w-xs mx-auto">
        Optimizing vector density and synthesizing hierarchical layout nodes.
      </p>
    </div>
  </div>
);

const BrandDetail: React.FC<BrandDetailProps> = ({ 
  brand, 
  brands,
  onBack, 
  onEdit, 
  onDelete,
  onBrandClick,
  isDarkMode, 
  onToggleTheme,
  isReadOnly,
  onUpdateBrand
}) => {
  const [activeSection, setActiveSection] = useState('overview');
  const [isExporting, setIsExporting] = useState(false);
  const [exportStatus, setExportStatus] = useState('');
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditResult, setAuditResult] = useState<any>(null);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
    setActiveSection('overview');
  }, [brand.id]);

  const orderedSections = useMemo(() => {
    return [...(brand.sections || [])].sort((a, b) => (a.order || 0) - (b.order || 0));
  }, [brand.sections]);

  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  useEffect(() => {
    const observerOptions = {
      root: null,
      rootMargin: '-20% 0px -70% 0px',
      threshold: 0
    };

    const handleIntersect = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    };

    const observer = new IntersectionObserver(handleIntersect, observerOptions);
    
    const targets = ['overview', ...orderedSections.map(s => s.id)];
    targets.forEach(id => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [orderedSections]);

  const sidebarSections = orderedSections.filter(s => isReadOnly ? s.isVisible : true);

  const handleExport = useCallback(async (format: PageFormat) => {
    if (isExporting) return;
    setIsExporting(true);
    setShowExportMenu(false);
    setExportStatus('Activating Neural Designer...');
    
    try {
      await pdfExport.export(format, 'brand-detail-content-area', brand, isDarkMode, (status) => {
        setExportStatus(status);
      });
    } catch (e) {
      console.error("Export Protocol Failure:", e);
    } finally {
      setIsExporting(false);
      setExportStatus('');
    }
  }, [isExporting, brand, isDarkMode]);

  const handleAudit = async () => {
    if (isAuditing) return;
    setIsAuditing(true);
    try {
      const res = await auditBrandBrain(brand, brand.brainRegistry || { archetype: '', narrative: '', visualConstraints: '', culturalNuance: '' });
      setAuditResult(res);
    } catch (e) {
      console.error("Audit Fault:", e);
    } finally {
      setIsAuditing(false);
    }
  };

  const handleDeleteBrand = async () => {
    if (onDelete && window.confirm(`PROTOCOL WARNING: Irreversibly purge all governance data for "${brand.name}"?`)) {
      onDelete(brand.id);
    }
  };

  const handleSectionUpdate = (sectionId: string, updates: Partial<BrandSection>) => {
    if (!onUpdateBrand) return;
    const updatedSections = (brand.sections || []).map(s => 
      s.id === sectionId ? { ...s, ...updates } : s
    );
    onUpdateBrand({ ...brand, sections: updatedSections });
  };

  const isValid = (url?: string) => {
    if (!url) return false;
    const clean = url.trim();
    if (clean === '' || clean === '#') return false;
    if (clean.includes(DEFAULT_PLACEHOLDER)) return false;
    return true;
  };

  const heroSettings = brand.logoHero || { variant: 'color', alignment: 'left', scaling: 1, background: 'glass', showInDetail: true, padding: 8 };
  
  const heroLogoUrl = useMemo(() => {
    const lightLogo = brand.logos?.['white'] || brand.logos?.['light'];
    const darkLogo = brand.logos?.['black'] || brand.logos?.['dark'] || brand.logos?.['color'] || brand.logoUrl;
    if (isDarkMode) return isValid(lightLogo) ? lightLogo : (isValid(brand.logoUrl) ? brand.logoUrl : null);
    else return isValid(darkLogo) ? darkLogo : (isValid(brand.logoUrl) ? brand.logoUrl : null);
  }, [brand.logos, brand.logoUrl, isDarkMode]);

  const stickyHeaderLogo = useMemo(() => {
    const darkLogo = brand.logos?.['black'] || brand.logos?.['dark'] || brand.logos?.['color'] || brand.logoUrl;
    if (isValid(darkLogo)) return darkLogo;
    return isValid(brand.logoUrl) ? brand.logoUrl : '';
  }, [brand.logos, brand.logoUrl]);

  return (
    <div className="min-h-screen pb-32 text-left print:bg-white print:text-black relative view-transition font-sans">
      <BrandBackground settings={brand.backgroundSettings} isDarkMode={isDarkMode} />
      
      {isExporting && <ExportOverlay status={exportStatus} />}
      {auditResult && <AuditOverlay audit={auditResult} onClose={() => setAuditResult(null)} />}
      
      <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-950/95 backdrop-blur-xl border-b border-slate-200 dark:border-white/5 -mx-6 lg:-mx-12 px-6 lg:px-12 py-5 mb-16 flex items-center justify-between print:hidden transition-all duration-500">
        <div className="flex items-center gap-6">
          <button onClick={onBack} className="p-3 rounded-2xl hover:bg-slate-100 dark:hover:bg-white/5 text-slate-500 transition-colors group">
            <ArrowLeft className="w-6 h-6 group-hover:-translate-x-1 transition-transform" />
          </button>
          <div className="flex items-center gap-5">
             <div className="w-12 h-12 rounded-[1rem] bg-white backdrop-blur-md p-2 shadow-2xl border border-slate-100 flex items-center justify-center overflow-hidden">
                <img src={getDirectImageUrl(stickyHeaderLogo)} alt={brand.name} className="max-h-full max-w-full object-contain" />
             </div>
             <div>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tighter leading-none">{brand.name}</h2>
                <div className="flex items-center gap-2 mt-1">
                   <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                   <span className="text-[9px] font-black text-slate-400 dark:text-slate-300 uppercase tracking-widest">Protocol Index Node</span>
                </div>
             </div>
          </div>
        </div>
        <div className="flex items-center gap-4">
           <button 
             onClick={handleAudit}
             disabled={isAuditing}
             className="flex items-center gap-3 px-6 py-3 bg-white/5 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all hover:bg-slate-100 dark:hover:bg-white/10 disabled:opacity-50"
           >
              {isAuditing ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4 text-indigo-500" />}
              {isAuditing ? 'Auditing...' : 'Neural Audit'}
           </button>

           <div className="relative">
              <button 
                onClick={() => { setShowExportMenu(!showExportMenu); }}
                disabled={isExporting}
                className={`flex items-center gap-3 px-8 py-3 bg-blue-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-2xl transition-all ${isExporting ? 'opacity-80 cursor-wait' : 'hover:bg-blue-700 hover:scale-[1.02] active:scale-95'}`}
              >
                {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                {isExporting ? 'Neural Stream...' : 'Export Manual'}
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showExportMenu ? 'rotate-180' : ''}`} />
              </button>

              {showExportMenu && (
                <div className="absolute right-0 mt-3 w-72 bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/10 rounded-[2rem] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.3)] overflow-hidden animate-in fade-in slide-in-from-top-4 z-50">
                  <div className="p-6 border-b border-slate-100 dark:border-white/5 bg-slate-50/50 dark:bg-slate-950/50">
                    <span className="text-[10px] font-black text-slate-400 dark:text-slate-300 uppercase tracking-widest">Select Output Protocol</span>
                  </div>
                  <div className="p-3 space-y-2">
                    {[
                      { id: 'a4', label: 'A4 Manifest', desc: 'Global Corporate Standard', icon: FileText },
                      { id: 'letter', label: 'US Letter', desc: 'Regional Print Optimised', icon: FileArchive },
                      { id: 'presentation_wide', label: 'Impact Deck', desc: '16:9 Screen Optimised', icon: Monitor }
                    ].map(opt => (
                      <button 
                        key={opt.id}
                        onClick={() => handleExport(opt.id as PageFormat)}
                        className="w-full flex items-center justify-between p-4 rounded-2xl hover:bg-slate-50 dark:hover:bg-white/5 transition-all group text-left"
                      >
                        <div className="flex items-center gap-4">
                          <div className="p-2.5 bg-slate-100 dark:bg-slate-800 rounded-xl group-hover:bg-blue-600 group-hover:text-white transition-colors">
                            <opt.icon className="w-5 h-5" />
                          </div>
                          <div>
                            <span className="block text-sm font-black text-slate-900 dark:text-white uppercase tracking-tight">{opt.label}</span>
                            <span className="block text-[8px] text-slate-500 dark:text-slate-400 uppercase font-bold tracking-widest">{opt.desc}</span>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-300 group-hover:translate-x-1 transition-transform" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
           </div>

           {!isReadOnly && onEdit && (
             <div className="flex items-center gap-3">
               <button onClick={() => onEdit(brand)} className="flex items-center gap-3 px-8 py-3 bg-slate-900 dark:bg-white dark:text-slate-950 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all hover:scale-[1.02] active:scale-95 shadow-xl">
                 <Edit className="w-4 h-4" /> Edit DNA
               </button>
               <button onClick={handleDeleteBrand} className="p-3 bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white rounded-2xl transition-all active:scale-95 border border-red-500/20 shadow-lg" title="Purge Protocol">
                 <Trash2 className="w-5 h-5" />
               </button>
             </div>
           )}
           <div className="w-px h-8 bg-slate-200 dark:bg-white/10 mx-2" />
           <button onClick={onToggleTheme} className="p-3 rounded-2xl text-slate-400 hover:text-blue-500 hover:bg-slate-100 dark:hover:bg-white/10 transition-all">
             {isDarkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
           </button>
        </div>
      </header>

      <div className="grid grid-cols-12 gap-16 print:block relative z-10">
        {/* Navigation Sidebar */}
        <aside className="hidden lg:block col-span-3 print:hidden text-left relative">
          <div className="sticky top-40 flex flex-col h-[calc(100vh-10rem)] bg-white/5 dark:bg-white/[0.02] backdrop-blur-sm rounded-[3rem] border border-slate-200/50 dark:border-white/5 overflow-hidden">
             <div className="p-6 pb-2 shrink-0">
                <p className="text-[10px] font-black text-slate-400 dark:text-slate-200 uppercase tracking-[0.4em] mb-3">Governance Mapping</p>
                <div className="h-1 w-12 bg-blue-600 rounded-full" />
             </div>
             
             <div className="flex-1 overflow-y-auto custom-scrollbar px-3 py-4 space-y-1">
                <button 
                    onClick={() => scrollToSection('overview')} 
                    className={`w-full flex items-center gap-4 px-5 py-4 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest transition-all ${activeSection === 'overview' ? 'bg-blue-600 text-white shadow-2xl shadow-blue-500/20' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5'}`}
                >
                    <Layout className="w-4 h-4 shrink-0" />
                    Index Overview
                </button>

                {sidebarSections.map(section => {
                  const isPopulated = Object.keys(section.data || {}).length > 0 || Array.isArray(section.data) && section.data.length > 0;
                  
                  return (
                    <button 
                      key={section.id} 
                      onClick={() => scrollToSection(section.id)} 
                      className={`w-full flex items-center justify-between gap-4 px-5 py-4 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest transition-all group ${activeSection === section.id ? 'bg-blue-600 text-white shadow-2xl shadow-blue-500/20' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5'}`}
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-1.5 h-1.5 rounded-full transition-all duration-500 shrink-0 ${activeSection === section.id ? 'bg-white scale-125' : 'bg-slate-300 dark:bg-slate-700 group-hover:bg-blue-500'}`} />
                        <span className="truncate">{section.title}</span>
                      </div>
                      {isPopulated && <CheckCircle2 className={`w-3 h-3 ${activeSection === section.id ? 'text-white' : 'text-emerald-500/60'}`} />}
                    </button>
                  );
                })}
             </div>
             
             <div className="p-4 border-t border-slate-100 dark:border-white/5 bg-slate-50/50 dark:bg-slate-950/5 flex items-center justify-center shrink-0">
                <span className="text-[7px] font-black text-slate-400 dark:text-slate-400 uppercase tracking-widest">Protocol Nodes: {sidebarSections.length + 1}</span>
             </div>
          </div>
        </aside>

        <div id="brand-detail-content-area" className="col-span-12 lg:col-span-9 space-y-32 print:col-span-12 print:w-full print:m-0">
           <section id="overview" className="scroll-mt-48 print:mb-12 flex flex-col items-start text-left animate-in fade-in slide-in-from-bottom-8 duration-1000">
              {heroSettings.showInDetail && (
                <div className="mb-20 flex justify-start w-full">
                  <div 
                    style={{ 
                      padding: `${heroSettings.padding * 4}px`,
                      transform: `scale(${heroSettings.scaling})`,
                      transformOrigin: 'left'
                    }}
                    className={`inline-block rounded-[4rem] transition-all duration-700 ${
                      heroSettings.background === 'glass' ? 'bg-white/60 dark:bg-slate-900/40 backdrop-blur-3xl border border-white/40 dark:border-white/5 shadow-[0_30px_100px_-20px_rgba(0,0,0,0.15)]' :
                      heroSettings.background === 'solid' ? 'bg-white dark:bg-slate-900 border border-slate-100 dark:border-white/5 shadow-2xl' :
                      'bg-transparent'
                    }`}
                  >
                    {heroLogoUrl ? (
                      <img 
                        src={getDirectImageUrl(heroLogoUrl)} 
                        alt={`${brand.name} Master Identity`} 
                        className="max-h-32 md:max-h-52 w-auto object-contain drop-shadow-2xl transition-all duration-700" 
                      />
                    ) : (
                      <div className="p-16 text-slate-300 dark:text-slate-600 opacity-20 flex flex-col items-center gap-4">
                        <ImagePlus className="w-20 h-20" />
                        <span className="text-xs font-black uppercase tracking-[0.4em]">Asset Ref Missing</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="max-w-4xl space-y-12">
                 <div className="space-y-6">
                    <h1 className="text-6xl lg:text-9xl font-black text-slate-900 dark:text-white tracking-tighter leading-[0.85] uppercase print:text-5xl">
                      {brand.name}
                    </h1>
                    {brand.tagline && (
                      <div className="flex items-center gap-6">
                         <div className="h-0.5 w-12 bg-blue-600 rounded-full" />
                         <p className="text-2xl lg:text-3xl font-bold text-blue-600 dark:text-blue-400 italic print:text-xl text-balance">"{brand.tagline}"</p>
                      </div>
                    )}
                 </div>
                 
                 <p className="text-xl lg:text-2xl text-slate-600 dark:text-slate-300 leading-relaxed font-light print:text-lg text-left text-balance">
                   {brand.description}
                 </p>
                 
                 <div className="flex flex-wrap gap-6 pt-10 print:mt-8">
                    <div className="px-8 py-5 bg-white dark:bg-slate-900/50 border border-slate-200 dark:border-white/10 rounded-[2rem] shadow-xl hover:shadow-2xl transition-all group cursor-default">
                       <span className="block text-[10px] font-black text-slate-400 dark:text-slate-300 group-hover:text-blue-500 transition-colors uppercase tracking-[0.3em] mb-2">Primary Sector</span>
                       <span className="text-lg font-black dark:text-white uppercase tracking-tight">{brand.industry}</span>
                    </div>
                    <div className="px-8 py-5 bg-white dark:bg-slate-900/50 border border-slate-200 dark:border-white/10 rounded-[2rem] shadow-xl hover:shadow-2xl transition-all group cursor-default">
                       <span className="block text-[10px] font-black text-slate-400 dark:text-slate-300 group-hover:text-blue-500 transition-colors uppercase tracking-[0.3em] mb-2">Build Protocol</span>
                       <span className="text-lg font-black text-blue-600 dark:text-blue-400 uppercase tracking-tight">v{brand.version} Final</span>
                    </div>
                    <div className="px-8 py-5 bg-white dark:bg-slate-900/50 border border-slate-200 dark:border-white/10 rounded-[2rem] shadow-xl hover:shadow-2xl transition-all group cursor-default">
                       <span className="block text-[10px] font-black text-slate-400 dark:text-slate-300 group-hover:text-blue-500 transition-colors uppercase tracking-[0.3em] mb-2">Governance State</span>
                       <span className="text-lg font-black text-emerald-500 dark:text-emerald-400 uppercase tracking-tight flex items-center gap-3">
                          <CheckCircle2 className="w-5 h-5" /> Grounded
                       </span>
                    </div>
                 </div>
              </div>
           </section>

           {orderedSections.map(section => (
             <div key={section.id} id={section.id} className="print:page-break-before-always section-container animate-in fade-in slide-in-from-bottom-12 duration-1000" data-section-id={section.id}>
               <SectionRenderer 
                  brand={brand} 
                  brands={brands}
                  section={section} 
                  mode={isReadOnly ? 'view' : 'edit'} 
                  onUpdate={(updates) => handleSectionUpdate(section.id, updates)} 
                  onBrandClick={onBrandClick}
                  isDarkMode={isDarkMode}
               />
             </div>
           ))}

           <footer className="pt-20 border-t border-slate-100 dark:border-white/5 opacity-40 text-left">
              <div className="flex flex-col md:flex-row justify-between items-center gap-8">
                 <div className="flex items-center gap-4">
                    <ShieldCheck className="w-8 h-8 text-slate-300 dark:text-slate-500" />
                    <span className="text-[10px] font-black text-slate-400 dark:text-slate-300 uppercase tracking-[0.4em]">BrandHub Master Governance v2.6.0</span>
                 </div>
                 <div className="text-[9px] font-mono text-slate-500 dark:text-slate-400 uppercase">
                    Protocol Hash: {Math.random().toString(36).substr(2, 10).toUpperCase()}
                 </div>
              </div>
           </footer>
        </div>
      </div>
    </div>
  );
};

export default BrandDetail;
