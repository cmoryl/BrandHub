import React, { useState, useMemo, useRef } from 'react';
import { 
  Copy, Check, Info, FlaskConical, Plus, Trash2, Sparkles, Loader2, 
  CheckCircle2, ChevronRight, ArrowLeftRight, Wand2, Camera, Upload, 
  X, Shield, Layers, Layout, Type, Tag, BadgeCheck
} from 'lucide-react';
import { Color, Brand } from '../types';
import { hexToRgb, rgbToCmyk, rgbToHsv, hexToPantone, getContrastRatio, getWCAGRating, getContrastColor } from '../utils/colorUtils';
import { generateAIPalette, generatePaletteFromImage } from '../services/geminiService';

interface ColorPaletteProps {
  colors: Color[];
  brand?: Brand;
  mode?: 'view' | 'edit';
  onChange?: (colors: Color[]) => void;
}

const ColorABTest = ({ colors, brand }: { colors: Color[], brand?: Brand }) => {
  const [bgIndex, setBgIndex] = useState(0);
  const [fgIndex, setFgIndex] = useState(Math.min(1, colors.length - 1));
  const [testMode, setTestMode] = useState<'ui' | 'marketing'>('ui');

  const handleSwap = () => {
    const temp = bgIndex;
    setBgIndex(fgIndex);
    setFgIndex(temp);
  };

  const colorA = colors[bgIndex] || { hex: '#000000', name: 'Black' };
  const colorB = colors[fgIndex] || { hex: '#ffffff', name: 'White' };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/10 rounded-[3rem] p-10 space-y-12 text-left mb-16 shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 right-0 p-12 opacity-[0.03] pointer-events-none rotate-12">
        <Layout className="w-64 h-64 text-blue-500" />
      </div>
      
      <div className="flex flex-col md:flex-row items-center justify-between gap-10 relative z-10">
        <div className="space-y-2">
           <h3 className="text-3xl font-black dark:text-white uppercase tracking-tighter">Surface Harmony Audit</h3>
           <p className="text-slate-500 font-medium text-sm">Stress-test chromatic pairings against real-world governance content.</p>
        </div>
        <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
           <button onClick={() => setTestMode('ui')} className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${testMode === 'ui' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-lg' : 'text-slate-500'}`}>UI Protocol</button>
           <button onClick={() => setTestMode('marketing')} className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${testMode === 'marketing' ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-lg' : 'text-slate-500'}`}>Marketing Flex</button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row items-center gap-8 relative z-10">
        <div className="flex-1 w-full space-y-4">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">Background Surface</label>
          <div className="flex items-center gap-4 bg-slate-50 dark:bg-slate-950 p-4 rounded-[2rem] border border-slate-200 dark:border-white/5 transition-all focus-within:ring-2 focus-within:ring-blue-500/20">
            <div className="w-14 h-14 rounded-2xl shadow-xl shrink-0 border-2 border-white dark:border-white/10" style={{ backgroundColor: colorA.hex }} />
            <select 
              value={bgIndex} 
              onChange={(e) => setBgIndex(parseInt(e.target.value))}
              className="bg-transparent border-none text-slate-900 dark:text-white text-lg font-black w-full focus:ring-0 cursor-pointer uppercase tracking-tight"
            >
              {colors.map((c, i) => (
                <option key={i} value={i} className="bg-slate-900 text-white">{c.name}</option>
              ))}
            </select>
          </div>
        </div>

        <button 
          onClick={handleSwap}
          className="p-5 bg-white dark:bg-slate-800 text-blue-500 hover:text-blue-600 dark:hover:text-blue-400 rounded-full transition-all hover:scale-110 active:rotate-180 duration-500 shadow-xl border border-slate-100 dark:border-white/10"
        >
          <ArrowLeftRight className="w-6 h-6" />
        </button>

        <div className="flex-1 w-full space-y-4">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">Character Tint</label>
          <div className="flex items-center gap-4 bg-slate-50 dark:bg-slate-950 p-4 rounded-[2rem] border border-slate-200 dark:border-white/5 transition-all focus-within:ring-2 focus-within:ring-blue-500/20">
            <div className="w-14 h-14 rounded-2xl shadow-xl shrink-0 border-2 border-white dark:border-white/10" style={{ backgroundColor: colorB.hex }} />
            <select 
              value={fgIndex} 
              onChange={(e) => setFgIndex(parseInt(e.target.value))}
              className="bg-transparent border-none text-slate-900 dark:text-white text-lg font-black w-full focus:ring-0 cursor-pointer uppercase tracking-tight"
            >
              {colors.map((c, i) => (
                <option key={i} value={i} className="bg-slate-900 text-white">{c.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 overflow-hidden rounded-[3rem] border border-slate-100 dark:border-white/5 shadow-inner bg-slate-50 dark:bg-black/20">
        <div 
          className="flex flex-col items-start justify-center p-16 text-left transition-all duration-700 min-h-[450px] relative group"
          style={{ backgroundColor: colorA.hex, color: colorB.hex }}
        >
          <div className="absolute top-8 left-10 text-[9px] font-black uppercase tracking-[0.4em] opacity-40">Primary Protocol</div>
          {testMode === 'ui' ? (
             <div className="space-y-10 w-full">
                <div className="flex items-center gap-4">
                   <div className="w-12 h-12 rounded-xl bg-current opacity-10" />
                   <div className="h-4 w-32 bg-current opacity-20 rounded-full" />
                </div>
                <h4 className="text-5xl font-black tracking-tighter leading-tight uppercase">System<br/>Interface</h4>
                <p className="text-xl font-medium opacity-80 leading-relaxed max-w-sm">This demonstrates core readability and atmospheric depth for digital surfaces.</p>
                <div className="flex gap-4">
                   <div className="px-8 py-3 bg-current text-white mix-blend-difference rounded-full font-black text-[10px] uppercase tracking-widest">Primary Action</div>
                   <div className="px-8 py-3 border border-current rounded-full font-black text-[10px] uppercase tracking-widest">Ghost State</div>
                </div>
             </div>
          ) : (
             <div className="space-y-8 w-full">
                <h4 className="text-2xl font-black uppercase tracking-widest opacity-60">Brand Tagline</h4>
                <h3 className="text-6xl font-black tracking-tighter leading-[0.95] uppercase italic">{brand?.name || 'Global'} Solutions</h3>
                <div className="h-1.5 w-40 bg-current opacity-40 rounded-full" />
                <p className="text-lg font-medium opacity-90 italic">"{brand?.missionStatement || 'Excellence through innovation.'}"</p>
             </div>
          )}
        </div>
        
        <div 
          className="flex flex-col items-start justify-center p-16 text-left transition-all duration-700 min-h-[450px] relative border-l border-black/5 dark:border-white/5"
          style={{ backgroundColor: colorB.hex, color: colorA.hex }}
        >
          <div className="absolute top-8 left-10 text-[9px] font-black uppercase tracking-[0.4em] opacity-40">Inverse Protocol</div>
          {testMode === 'ui' ? (
             <div className="space-y-10 w-full">
                <div className="flex items-center gap-4">
                   <div className="w-12 h-12 rounded-xl bg-current opacity-10" />
                   <div className="h-4 w-32 bg-current opacity-20 rounded-full" />
                </div>
                <h4 className="text-5xl font-black tracking-tighter leading-tight uppercase">Dashboard<br/>Dark Mode</h4>
                <p className="text-xl font-medium opacity-80 leading-relaxed max-w-sm">Testing how the brand identity pivots when the hierarchy is inverted.</p>
                <div className="flex gap-4">
                   <div className="px-8 py-3 bg-current text-white mix-blend-difference rounded-full font-black text-[10px] uppercase tracking-widest">Execute</div>
                </div>
             </div>
          ) : (
             <div className="space-y-8 w-full">
                <h4 className="text-2xl font-black uppercase tracking-widest opacity-60">Campaign DNA</h4>
                <h3 className="text-6xl font-black tracking-tighter leading-[0.95] uppercase italic">Orchestrating<br/>Reality</h3>
                <div className="h-1.5 w-40 bg-current opacity-40 rounded-full" />
                <p className="text-lg font-medium opacity-90 italic">Verified for high-impact communication channels.</p>
             </div>
          )}
        </div>
      </div>
      
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 px-4">
        <div className="flex items-center gap-10">
           <div className="space-y-1">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Luminance Contrast</span>
              <span className="text-3xl font-black dark:text-white tabular-nums">{getContrastRatio(colorA.hex, colorB.hex).toFixed(2)}:1</span>
           </div>
           <div className={`flex flex-col items-center justify-center w-24 h-24 rounded-3xl border shadow-xl ${getWCAGRating(getContrastRatio(colorA.hex, colorB.hex)).pass ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-500' : 'bg-red-500/10 border-red-500/30 text-red-500'}`}>
              <span className="text-2xl font-black tracking-tighter leading-none">{getWCAGRating(getContrastRatio(colorA.hex, colorB.hex)).label}</span>
              <span className="text-[9px] font-black uppercase tracking-widest mt-1">Verified</span>
           </div>
        </div>
        <div className="flex items-center gap-3 text-slate-400">
           {/* Fix: Added missing BadgeCheck import from lucide-react */}
           <BadgeCheck className="w-5 h-5 text-blue-500" />
           <p className="text-[10px] font-black uppercase tracking-widest max-w-[250px] leading-relaxed">
             * This audit simulates human visual perception for inclusive communication protocols.
           </p>
        </div>
      </div>
    </div>
  );
};

// Update AccessibilityMatrix for better dark mode visibility
const AccessibilityMatrix = ({ colors }: { colors: Color[] }) => {
  const testTextColors = useMemo(() => {
    const brandCols = colors.slice(0, 2).map(c => ({ name: `${c.name}`, hex: c.hex }));
    return [
      { name: 'White', hex: '#ffffff' },
      { name: 'Black', hex: '#000000' },
      ...brandCols
    ];
  }, [colors]);

  return (
    <div className="space-y-8 text-left">
      <div className="flex items-center gap-4">
        <div className="p-3 bg-blue-600 rounded-2xl text-white shadow-lg"><Type className="w-6 h-6" /></div>
        <h3 className="text-3xl font-black uppercase tracking-tight dark:text-white">Accessibility Manifest (The Matrix)</h3>
      </div>

      <div className="overflow-x-auto rounded-[3rem] border border-slate-200 dark:border-white/5 shadow-2xl bg-white dark:bg-slate-950">
        <table className="w-full border-collapse min-w-[1000px]">
          <thead>
            <tr className="bg-slate-900 dark:bg-slate-900/50 text-white">
              <th className="px-10 py-6 text-left text-[11px] font-black uppercase tracking-[0.2em] text-blue-400 border-r border-white/5">Surface Level</th>
              {testTextColors.map((col, i) => (
                <th key={i} className="px-10 py-6 text-left text-[11px] font-black uppercase tracking-[0.2em] border-r border-white/5 last:border-r-0">
                  {col.name}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {colors.map((bgColor, rowIdx) => (
              <tr key={rowIdx} className="border-b border-slate-100 dark:border-white/5 last:border-b-0" style={{ backgroundColor: bgColor.hex }}>
                <td className="px-10 py-10 border-r border-black/5 dark:border-white/5 font-black text-sm" style={{ color: getContrastColor(bgColor.hex) }}>
                   <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full bg-current opacity-40" />
                      {bgColor.name}
                   </div>
                </td>
                {testTextColors.map((textColor, colIdx) => {
                  const ratio = getContrastRatio(bgColor.hex, textColor.hex);
                  const rating = getWCAGRating(ratio);
                  const isSame = bgColor.hex.toLowerCase() === textColor.hex.toLowerCase();
                  const contentColor = getContrastColor(bgColor.hex);

                  return (
                    <td key={colIdx} className="px-10 py-10 border-r border-black/5 dark:border-white/5 last:border-r-0">
                      {isSame ? (
                        <div className="flex flex-col items-center opacity-30 italic" style={{ color: contentColor }}>
                           <X className="w-4 h-4 mb-1" />
                           <span className="text-[9px] font-black uppercase tracking-widest">N/A</span>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <p className="font-black text-base transition-transform hover:scale-110 cursor-default" style={{ color: textColor.hex }}>
                            {rating.pass ? 'Read Ready' : 'Low Clarity'}
                          </p>
                          <div className="flex items-center justify-between gap-3">
                             <span className="text-[10px] font-mono font-bold opacity-60" style={{ color: contentColor }}>{ratio.toFixed(1)}:1</span>
                             <div className={`px-3 py-1 rounded-xl text-[9px] font-black tracking-widest shadow-sm ${rating.pass ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white'}`}>
                                {rating.label}
                             </div>
                          </div>
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const ColorPalette: React.FC<ColorPaletteProps> = ({ colors, brand, mode = 'view', onChange }) => {
  const [copiedHex, setCopiedHex] = useState<string | null>(null);
  const safeColors = useMemo(() => Array.isArray(colors) ? colors : [], [colors]);
  const [selectedColor, setSelectedColor] = useState<Color | null>(safeColors[0] || null);
  const [activeTab, setActiveTab] = useState<'palette' | 'lab'>('palette');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Lab State
  const [labPrompt, setLabPrompt] = useState('');
  const [proposedPalette, setProposedPalette] = useState<Color[] | null>(null);
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  const handleCopy = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 2000);
  };

  const handleUpdate = (index: number, field: keyof Color, value: string) => {
    if (!onChange) return;
    const next = [...safeColors];
    next[index] = { ...next[index], [field]: value };
    onChange(next);
  };

  const addColor = () => {
    if (!onChange) return;
    onChange([...safeColors, { name: 'New Color', hex: '#000000', usage: 'primary' }]);
  };

  const removeColor = (index: number) => {
    if (!onChange) return;
    onChange(safeColors.filter((_, i) => i !== index));
  };

  const runLabSynthesis = async () => {
    if (!brand || !labPrompt.trim()) return;
    setIsSynthesizing(true);
    try {
      const result = await generateAIPalette(brand, labPrompt);
      setProposedPalette(result);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSynthesizing(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setUploadedImage(base64);
      if (brand) {
        setIsSynthesizing(true);
        try {
          const result = await generatePaletteFromImage(brand, base64);
          setProposedPalette(result);
        } catch (err) {
          console.error(err);
        } finally {
          setIsSynthesizing(false);
        }
      }
    };
    reader.readAsDataURL(file);
  };

  const commitAsMaster = () => {
    if (proposedPalette && onChange) {
      onChange(proposedPalette);
      setProposedPalette(null);
      setUploadedImage(null);
      setActiveTab('palette');
    }
  };

  const commitAsSub = () => {
    if (proposedPalette && onChange) {
      onChange([...safeColors, ...proposedPalette.map(c => ({...c, name: `[SUB] ${c.name}`}))]);
      setProposedPalette(null);
      setUploadedImage(null);
      setActiveTab('palette');
    }
  };

  return (
    <div className="space-y-12">
      <div className="flex items-center justify-between gap-4 border-b border-slate-200 dark:border-white/5 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md rounded-t-[2.5rem] px-8">
        <div className="flex gap-10">
          <button onClick={() => setActiveTab('palette')} className={`py-6 text-[10px] font-black uppercase tracking-[0.3em] transition-all border-b-2 ${activeTab === 'palette' ? 'text-blue-600 border-blue-600' : 'text-slate-400 border-transparent hover:text-slate-600'}`}>Full Registry</button>
          <button onClick={() => setActiveTab('lab')} className={`py-6 text-[10px] font-black uppercase tracking-[0.3em] transition-all border-b-2 ${activeTab === 'lab' ? 'text-blue-600 border-blue-600' : 'text-slate-400 border-transparent hover:text-slate-600'}`}>Chromatic Lab</button>
        </div>
        {mode === 'edit' && activeTab === 'palette' && (
          <button onClick={addColor} className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-blue-500/20 active:scale-95 transition-all">
            <Plus className="w-4 h-4" /> Add Prismatic Node
          </button>
        )}
      </div>

      {activeTab === 'palette' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-8 grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6 text-left animate-in fade-in duration-700">
            {safeColors.map((color, idx) => (
              <div key={idx} className={`group relative bg-white dark:bg-slate-900/60 border rounded-[2rem] overflow-hidden shadow-sm hover:shadow-2xl transition-all hover:-translate-y-1 ${selectedColor?.hex === color.hex ? 'border-blue-500 ring-4 ring-blue-500/10' : 'border-slate-100 dark:border-white/10'}`}>
                <div 
                  className="h-32 w-full cursor-pointer relative" 
                  style={{ backgroundColor: color.hex }}
                  onClick={() => setSelectedColor(color)}
                >
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <div className="p-3 bg-white/20 backdrop-blur-md rounded-full text-white border border-white/30"><Info className="w-6 h-6" /></div>
                  </div>
                </div>
                <div className="p-5">
                  {mode === 'edit' ? (
                    <div className="space-y-4">
                       <input type="text" value={color.name} onChange={e => handleUpdate(idx, 'name', e.target.value)} className="w-full text-xs font-black uppercase bg-transparent border-none p-0 focus:ring-0 dark:text-white" />
                       <div className="flex items-center justify-between">
                          <input type="text" value={color.hex} onChange={e => handleUpdate(idx, 'hex', e.target.value)} className="text-[10px] font-mono font-bold uppercase bg-transparent border-none p-0 focus:ring-0 text-slate-500" />
                          <button onClick={() => removeColor(idx)} className="p-2 text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                       </div>
                    </div>
                  ) : (
                    <>
                      <p className="font-black text-slate-900 dark:text-white text-[11px] uppercase tracking-tight truncate text-left">{color.name}</p>
                      <div className="flex items-center justify-between mt-2">
                        <p className="text-slate-400 text-[10px] font-mono font-bold uppercase">{color.hex}</p>
                        <button onClick={() => handleCopy(color.hex)} className="p-1.5 hover:bg-slate-50 dark:hover:bg-white/5 rounded-lg transition-colors">
                          {copiedHex === color.hex ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5 text-slate-300" />}
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="lg:col-span-4">
             {selectedColor && (
               <div className="bg-white dark:bg-slate-900/60 rounded-[2.5rem] border border-slate-200 dark:border-white/5 p-10 sticky top-32 space-y-8 shadow-2xl animate-in slide-in-from-right-4">
                 <div className="flex items-center gap-6">
                    <div className="w-20 h-20 rounded-3xl shadow-2xl border-4 border-white dark:border-slate-800" style={{ backgroundColor: selectedColor.hex }}></div>
                    <div className="text-left space-y-1">
                       <h3 className="text-2xl font-black dark:text-white uppercase tracking-tighter leading-none">{selectedColor.name}</h3>
                       <div className="inline-block px-3 py-1 bg-blue-600/10 text-blue-600 rounded-lg text-[9px] font-black uppercase tracking-widest">{selectedColor.usage}</div>
                    </div>
                 </div>

                 <div className="grid gap-4">
                    <div className="group p-5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-white/5 text-left transition-colors hover:border-blue-500/30">
                       <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-2">HEX Protocol</span>
                       <div className="flex items-center justify-between">
                          <span className="font-mono text-base font-bold dark:text-slate-300 uppercase">{selectedColor.hex}</span>
                          <button onClick={() => handleCopy(selectedColor.hex)} className="text-slate-400 hover:text-blue-500 transition-colors"><Copy className="w-4 h-4" /></button>
                       </div>
                    </div>
                    <div className="p-5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-white/5 text-left">
                       <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-2">RGB Definition</span>
                       {(() => {
                          const rgb = hexToRgb(selectedColor.hex);
                          return <span className="font-mono text-base font-bold dark:text-slate-300">R:{rgb.r} G:{rgb.g} B:{rgb.b}</span>
                       })()}
                    </div>
                    <div className="p-5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-white/5 text-left">
                       <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-2">CMYK Primitives</span>
                       {(() => {
                          const rgb = hexToRgb(selectedColor.hex);
                          const cmyk = rgbToCmyk(rgb.r, rgb.g, rgb.b);
                          return <span className="font-mono text-base font-bold dark:text-slate-300">C:{cmyk.c}% M:{cmyk.m}% Y:{cmyk.y}% K:{cmyk.k}%</span>
                       })()}
                    </div>
                    <div className="p-5 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-white/5 text-left">
                       <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-2">Pantone Approximation</span>
                       <span className="font-mono text-base font-bold dark:text-slate-300">{hexToPantone(selectedColor.hex)}</span>
                    </div>
                 </div>

                 <div className="pt-6 border-t border-slate-100 dark:border-white/5">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-6 text-left">Inclusive Visibility Protocol (WCAG)</span>
                    <div className="grid grid-cols-2 gap-6">
                       <div className="space-y-3">
                          <div className="flex items-center justify-between text-[11px] font-bold dark:text-slate-400">
                             <span>Vs. White</span>
                             <span className="tabular-nums">{getContrastRatio(selectedColor.hex, '#ffffff').toFixed(2)}:1</span>
                          </div>
                          <div className={`px-4 py-2 rounded-xl text-center text-[10px] font-black border shadow-sm ${getWCAGRating(getContrastRatio(selectedColor.hex, '#ffffff')).pass ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30' : 'bg-red-500/10 text-red-500 border-red-500/30'}`}>
                             {getWCAGRating(getContrastRatio(selectedColor.hex, '#ffffff')).label}
                          </div>
                       </div>
                       <div className="space-y-3">
                          <div className="flex items-center justify-between text-[11px] font-bold dark:text-slate-400">
                             <span>Vs. Black</span>
                             <span className="tabular-nums">{getContrastRatio(selectedColor.hex, '#000000').toFixed(2)}:1</span>
                          </div>
                          <div className={`px-4 py-2 rounded-xl text-center text-[10px] font-black border shadow-sm ${getWCAGRating(getContrastRatio(selectedColor.hex, '#000000')).pass ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30' : 'bg-red-500/10 text-red-500 border-red-500/30'}`}>
                             {getWCAGRating(getContrastRatio(selectedColor.hex, '#000000')).label}
                          </div>
                       </div>
                    </div>
                 </div>
               </div>
             )}
          </div>
        </div>
      )}

      {activeTab === 'lab' && (
        <div className="space-y-20 animate-in fade-in duration-700 text-left">
           <ColorABTest colors={safeColors} brand={brand} />

           <div className="grid lg:grid-cols-2 gap-16 pt-16 border-t border-slate-200 dark:border-white/5">
              <div className="space-y-10 text-left">
                 <div className="flex items-center gap-4">
                    <div className="p-3 bg-blue-600 rounded-2xl text-white shadow-lg"><Camera className="w-6 h-6" /></div>
                    <h3 className="text-3xl font-black uppercase tracking-tight dark:text-white">Visual DNA Extraction</h3>
                 </div>
                 
                 <div className="relative group aspect-video rounded-[3.5rem] bg-slate-50 dark:bg-slate-900 border-2 border-dashed border-slate-200 dark:border-white/10 flex flex-col items-center justify-center overflow-hidden transition-all hover:border-blue-500/50 hover:bg-white dark:hover:bg-slate-800/40">
                    {uploadedImage ? (
                       <>
                          <img src={uploadedImage} alt="Upload" className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                             <button 
                                onClick={() => { setUploadedImage(null); setProposedPalette(null); }}
                                className="p-4 bg-red-600 text-white rounded-full shadow-2xl hover:scale-110 transition-transform"
                             >
                                <X className="w-8 h-8" />
                             </button>
                          </div>
                       </>
                    ) : (
                       <div className="text-center p-12 space-y-6">
                          <div className="w-24 h-24 bg-white dark:bg-slate-800 text-blue-500 rounded-[2.5rem] flex items-center justify-center mx-auto shadow-2xl border border-slate-100 dark:border-white/5 group-hover:scale-110 transition-transform">
                             <Upload className="w-10 h-10" />
                          </div>
                          <div className="space-y-2">
                             <h4 className="text-lg font-black uppercase tracking-widest dark:text-white">Upload Specimen</h4>
                             <p className="text-sm text-slate-500 max-w-[280px] mx-auto leading-relaxed">Synthesize a harmonic palette directly from image DNA.</p>
                          </div>
                          <input 
                             type="file" 
                             ref={fileInputRef} 
                             onChange={handleImageUpload} 
                             className="hidden" 
                             accept="image/*" 
                          />
                          <button 
                             onClick={() => fileInputRef.current?.click()}
                             className="px-10 py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-[1.5rem] font-black uppercase text-[10px] tracking-widest transition-all shadow-2xl active:scale-95"
                          >
                             Choose Protocol
                          </button>
                       </div>
                    )}
                 </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-white/5 rounded-[3.5rem] p-12 flex flex-col justify-center items-center text-center relative overflow-hidden">
                 <div className="absolute top-0 left-0 p-12 opacity-5 pointer-events-none"><Sparkles className="w-64 h-64 text-indigo-500" /></div>
                 
                 <div className="p-5 bg-indigo-600 rounded-[2rem] text-white shadow-2xl mb-8 relative z-10">
                    <FlaskConical className="w-10 h-10" />
                 </div>
                 <h3 className="text-3xl font-black uppercase tracking-tight dark:text-white mb-4 relative z-10">Neural Refinement</h3>
                 <p className="text-sm text-slate-500 max-w-sm mb-12 leading-relaxed relative z-10">Direct the Intelligence Studio to evolve your current palette for specific campaign themes or product identities.</p>
                 
                 <div className="w-full max-w-md space-y-6 relative z-10">
                    <div className="relative group">
                       <textarea 
                        value={labPrompt}
                        onChange={e => setLabPrompt(e.target.value)}
                        placeholder="e.g., Generate a high-energy variant for a sub-brand launch..."
                        className="w-full p-6 rounded-[2rem] border border-slate-200 dark:border-white/5 bg-white dark:bg-slate-950 text-slate-900 dark:text-white font-medium text-sm focus:ring-2 focus:ring-indigo-500 transition-all resize-none shadow-inner"
                        rows={4}
                       />
                       <div className="absolute right-4 bottom-4 p-2 bg-slate-100 dark:bg-slate-800 rounded-xl"><Tag className="w-4 h-4 text-slate-400" /></div>
                    </div>
                    <button 
                       onClick={runLabSynthesis}
                       disabled={isSynthesizing || !labPrompt.trim()}
                       className="w-full flex items-center justify-center gap-4 py-5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-[2rem] font-black text-xs uppercase tracking-[0.2em] transition-all shadow-2xl disabled:opacity-50 active:scale-95 group"
                    >
                       {isSynthesizing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5 group-hover:rotate-12 transition-transform" />}
                       Initiate Synthesis
                    </button>
                 </div>
              </div>
           </div>

           {proposedPalette && (
              <div className="pt-20 border-t border-slate-200 dark:border-white/5 animate-in slide-in-from-bottom-8 duration-1000 text-left">
                 <div className="flex flex-col md:flex-row md:items-center justify-between gap-10 mb-12">
                    <div className="flex items-center gap-6">
                       <div className="p-4 bg-emerald-500 rounded-[1.5rem] text-white shadow-xl shadow-emerald-500/20">
                          <CheckCircle2 className="w-8 h-8" />
                       </div>
                       <div className="space-y-1">
                          <h4 className="text-3xl font-black uppercase tracking-tighter dark:text-white">Proposed Protocol</h4>
                          <p className="text-sm text-slate-500 font-medium">Verification successful. Select commitment path.</p>
                       </div>
                    </div>
                    <div className="flex gap-4">
                       <button 
                          onClick={commitAsSub}
                          className="flex items-center gap-3 px-8 py-5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white rounded-[2rem] font-black text-[10px] uppercase tracking-widest transition-all hover:border-blue-500 shadow-xl group"
                       >
                          <Layers className="w-5 h-5 text-slate-400 group-hover:text-blue-500" />
                          Append to Registry
                       </button>
                       <button 
                          onClick={commitAsMaster}
                          className="flex items-center gap-3 px-12 py-5 bg-blue-600 hover:bg-blue-700 text-white rounded-[2rem] font-black text-[10px] uppercase tracking-widest transition-all shadow-2xl shadow-blue-600/30 active:scale-95"
                       >
                          <Shield className="w-5 h-5" />
                          Set as Primary
                       </button>
                    </div>
                 </div>
                 <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
                    {proposedPalette.map((c, i) => (
                       <div key={i} className="group relative rounded-[2.5rem] border border-slate-100 dark:border-white/5 overflow-hidden shadow-2xl transition-all hover:scale-105 bg-white dark:bg-slate-900">
                          <div className="h-40 w-full" style={{ backgroundColor: c.hex }} />
                          <div className="p-6 space-y-2">
                             <p className="text-[11px] font-black uppercase dark:text-white truncate">{c.name}</p>
                             <div className="flex items-center justify-between">
                                <p className="text-[10px] font-mono font-bold text-slate-400">{c.hex.toUpperCase()}</p>
                                <span className="px-2 py-0.5 bg-slate-100 dark:bg-white/5 rounded-md text-[8px] font-black text-slate-500 uppercase tracking-widest">{c.usage}</span>
                             </div>
                          </div>
                       </div>
                    ))}
                 </div>
              </div>
           )}

           <div className="pt-20 border-t border-slate-200 dark:border-white/5">
              <AccessibilityMatrix colors={safeColors} />
           </div>
        </div>
      )}
    </div>
  );
};

export default ColorPalette;