
import React from 'react';
import { 
  LayoutGrid, Layers, Settings, ArrowLeftCircle, Database, 
  Cloud, RefreshCw, History, Activity, Lock, WifiOff,
  PanelLeftClose, PanelLeftOpen
} from 'lucide-react';
import { Role, View, Brand } from '../types';
import Logo from './Logo';
import { getDirectImageUrl } from '../utils/linkUtils';
import { useBrandStore } from '../store/brandStore';
import { useNetworkStatus } from '../hooks/useNetworkStatus';

interface SidebarProps {
  activeView: View;
  role: Role;
  onNavigate: () => void;
  onSwitchRole: () => void;
  onLoginRedirect?: () => void;
  favoriteBrands?: Brand[];
  onBrandClick?: (brand: Brand) => void;
  onVaultClick?: () => void;
  onStabilityClick?: () => void;
  onSettingsClick?: () => void;
  selectedBrand?: Brand | null;
  onActiveBrandClick?: () => void;
  isSyncing?: boolean;
  lastSync?: number;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  activeView, 
  role, 
  onNavigate, 
  onSwitchRole,
  onVaultClick,
  onStabilityClick,
  onSettingsClick,
  selectedBrand,
  onActiveBrandClick,
  isSyncing = false,
  lastSync = Date.now(),
  isCollapsed,
  onToggleCollapse
}) => {
  const systemHealth = useBrandStore(state => state.systemHealth);
  const isOnline = useNetworkStatus();
  const isBrandView = activeView === 'brand-detail' || activeView === 'brand-editor';
  
  const displayIcon = isBrandView && selectedBrand?.brandIcon?.url 
    ? getDirectImageUrl(selectedBrand.brandIcon.url) 
    : null;

  const hasFaults = systemHealth.status !== 'nominal';

  return (
    <div className={`h-screen bg-white dark:bg-black text-slate-900 dark:text-white flex flex-col fixed left-0 top-0 border-r border-slate-200 dark:border-white/10 z-[60] transition-all duration-500 shadow-2xl overflow-hidden ${isCollapsed ? 'w-20' : 'w-20 lg:w-64'}`}>
      <div className="h-full flex flex-col">
        {/* Sidebar Header */}
        <div className="h-20 flex items-center justify-between px-6 border-b border-slate-200 dark:border-white/10 shrink-0">
          <div className="cursor-pointer overflow-hidden flex-1" onClick={onNavigate}>
            {displayIcon ? (
              <div className="flex items-center gap-3 animate-in fade-in zoom-in duration-500">
                <div className="w-10 h-10 rounded-xl bg-white/40 backdrop-blur-md p-1.5 shadow-md border border-white/20 flex items-center justify-center shrink-0">
                   <img src={displayIcon} className="w-full h-full object-contain" alt="Brand Symbol" />
                </div>
                {!isCollapsed && (
                  <div className="hidden lg:flex flex-col text-left">
                    <span className="text-xs font-black uppercase tracking-tighter truncate max-w-[120px] text-slate-900 dark:text-white">{selectedBrand?.name}</span>
                    <span className="text-[7px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-widest">Active Protocol</span>
                  </div>
                )}
              </div>
            ) : (
              <div className={`transform origin-left transition-transform duration-500 ${isCollapsed ? 'scale-75' : 'scale-75 lg:scale-90'}`}>
                <Logo variant={role} size="md" textClassName={isCollapsed ? 'hidden' : 'hidden lg:block ml-1 text-slate-900 dark:text-white'} />
              </div>
            )}
          </div>
          
          {/* Collapse Toggle - CRITICAL FIX: Ensure high z-index and pointer-events */}
          <button 
            onClick={(e) => { e.stopPropagation(); onToggleCollapse(); }}
            className="p-2.5 hover:bg-slate-100 dark:hover:bg-white/10 rounded-lg text-slate-400 hover:text-blue-600 transition-all hidden lg:block relative z-50 active:scale-90"
            title={isCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          >
            {isCollapsed ? <PanelLeftOpen className="w-5 h-5" /> : <PanelLeftClose className="w-5 h-5" />}
          </button>
        </div>
        
        {/* Status Indicators (Hidden when collapsed) */}
        {!isCollapsed && (
          <div className="px-6 py-4 flex flex-col gap-1 shrink-0 hidden lg:flex animate-in fade-in duration-500">
             <div className="flex items-center justify-between">
               <div className={`text-[9px] uppercase tracking-widest font-black ${role === 'admin' ? 'text-blue-600 dark:text-blue-400' : 'text-sky-600 dark:text-sky-400'}`}>
                  {role === 'admin' ? 'Admin Portal' : 'Public Viewer'}
               </div>
               <div className="flex items-center gap-1.5">
                  {!isOnline ? (
                    <WifiOff className="w-3 h-3 text-red-500 animate-pulse" />
                  ) : isSyncing ? (
                    <RefreshCw className="w-3 h-3 text-blue-500 animate-spin" />
                  ) : (
                    <div className={`w-1.5 h-1.5 rounded-full ${hasFaults ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`} />
                  )}
                  <Cloud className={`w-3 h-3 ${isSyncing ? 'text-blue-500' : 'text-white/20'}`} />
               </div>
             </div>
             <div className="flex items-center gap-1.5 text-slate-400 dark:text-slate-500">
                <History className="w-2.5 h-2.5" />
                <span className="text-[8px] font-bold uppercase tracking-widest">
                  Synced: {new Date(lastSync).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
             </div>
          </div>
        )}

        {/* Navigation Items */}
        <nav className="flex-1 py-4 flex flex-col gap-2 px-3 overflow-y-auto custom-scrollbar">
          <button
            onClick={onNavigate}
            title={isCollapsed ? "Brands Index" : ""}
            className={`flex items-center p-3 rounded-xl transition-all ${activeView === 'dashboard' ? 'bg-blue-600 text-white shadow-xl shadow-blue-500/40' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10 hover:text-blue-600 dark:hover:text-white'}`}
          >
            <LayoutGrid className="w-5 h-5 shrink-0" />
            {!isCollapsed && <span className="ml-3 font-bold text-sm hidden lg:block uppercase tracking-wide">Brands</span>}
          </button>

          <button
            onClick={onActiveBrandClick}
            disabled={!selectedBrand}
            title={isCollapsed ? "Active Protocol" : ""}
            className={`flex items-center p-3 rounded-xl transition-all ${activeView === 'brand-detail' || activeView === 'brand-editor' ? 'bg-blue-600/60 text-white shadow-xl' : selectedBrand ? 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10 hover:text-blue-600 dark:hover:text-white' : 'text-white/5 cursor-not-allowed opacity-30'}`}
          >
            <Layers className="w-5 h-5 shrink-0" />
            {!isCollapsed && <span className="ml-3 font-bold text-sm hidden lg:block uppercase tracking-wide">Active Brand</span>}
          </button>

          {role === 'admin' && (
            <>
              <button
                onClick={onVaultClick}
                title={isCollapsed ? "System Vault" : ""}
                className={`flex items-center p-3 rounded-xl transition-all ${activeView === 'vault' ? 'bg-blue-600 text-white shadow-xl' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10 hover:text-blue-600 dark:hover:text-white'}`}
              >
                <Database className="w-5 h-5 shrink-0" />
                {!isCollapsed && <span className="ml-3 font-bold text-sm hidden lg:block uppercase tracking-wide">System Vault</span>}
              </button>
              <button
                onClick={onStabilityClick}
                title={isCollapsed ? "Stability Hub" : ""}
                className={`group flex items-center p-3 rounded-xl transition-all relative ${activeView === 'stability' ? 'bg-blue-600 text-white shadow-xl' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10 hover:text-blue-600 dark:hover:text-white'}`}
              >
                <Activity className="w-5 h-5 shrink-0" />
                {!isCollapsed && <span className="ml-3 font-bold text-sm hidden lg:block uppercase tracking-wide">Stability Hub</span>}
                {hasFaults && <span className={`absolute top-3 rounded-full bg-amber-500 animate-ping ${isCollapsed ? 'right-3 w-1.5 h-1.5' : 'right-4 w-2 h-2'}`} />}
              </button>
            </>
          )}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-white/10 space-y-2 shrink-0">
          {!isCollapsed && (
            <div className="px-3 py-2 flex items-center justify-between text-[8px] font-black uppercase tracking-widest text-slate-400 hidden lg:flex">
               <span>Network State</span>
               <span className={isOnline ? 'text-emerald-500' : 'text-red-500 animate-pulse'}>{isOnline ? 'Active' : 'Offline'}</span>
            </div>
          )}
          <button 
            onClick={onSettingsClick}
            title={isCollapsed ? "Documentation" : ""}
            className={`flex items-center p-3 rounded-xl transition-all w-full ${activeView === 'settings' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10'}`}
          >
            <Settings className="w-5 h-5 shrink-0" />
            {!isCollapsed && <span className="ml-3 font-bold text-sm hidden lg:block uppercase tracking-wide">Documentation</span>}
          </button>
          <button 
            onClick={onSwitchRole}
            title={isCollapsed ? "Log Out" : ""}
            className="flex items-center p-3 rounded-xl text-slate-400 hover:bg-red-500/20 hover:text-red-600 w-full transition-all"
          >
            <ArrowLeftCircle className="w-5 h-5 shrink-0" />
            {!isCollapsed && <span className="ml-3 font-bold text-sm hidden lg:block uppercase tracking-wide">Log Out</span>}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
