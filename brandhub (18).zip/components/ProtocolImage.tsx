
import React, { useState, useEffect, useRef } from 'react';
import { AlertCircle, Loader2 } from 'lucide-react';
import { getDirectImageUrl } from '../utils/linkUtils';

interface ProtocolImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string | undefined | null;
  fallbackClassName?: string;
}

const ProtocolImage: React.FC<ProtocolImageProps> = ({ src, className, fallbackClassName, ...props }) => {
  const [status, setStatus] = useState<'loading' | 'loaded' | 'error'>('loading');
  const [processedUrl, setProcessedUrl] = useState<string>('');
  const imgRef = useRef<HTMLImageElement>(null);
  const timeoutRef = useRef<number | null>(null);

  // Sync effect: Process URL changes and reset watchdog
  useEffect(() => {
    if (timeoutRef.current) window.clearTimeout(timeoutRef.current);

    if (!src) {
      setStatus('error');
      setProcessedUrl('');
      return;
    }
    
    const directUrl = getDirectImageUrl(src);
    
    // Only update if the resolved URL actually changed to prevent loops
    if (directUrl !== processedUrl) {
      setProcessedUrl(directUrl);
      setStatus('loading');

      // Set a 10s watchdog to prevent infinite spinners
      timeoutRef.current = window.setTimeout(() => {
        // Use functional state update to avoid stale closures
        setStatus(current => {
          if (current === 'loading') {
            console.warn(`ProtocolImage: Sync timeout for ${directUrl}`);
            return 'error';
          }
          return current;
        });
      }, 10000);
    }

    return () => {
      if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
    };
  }, [src]); // Do not depend on processedUrl here to avoid circularity

  // Immediate check for cached images
  useEffect(() => {
    if (imgRef.current?.complete && status === 'loading' && processedUrl) {
      setStatus('loaded');
      if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
    }
  }, [processedUrl, status]);

  if (!processedUrl && status !== 'loading') {
    return (
      <div className={`flex flex-col items-center justify-center gap-2 text-slate-300 dark:text-slate-700 bg-slate-100 dark:bg-slate-800/50 ${className} ${fallbackClassName}`}>
        <AlertCircle className="w-5 h-5 opacity-20" />
        <span className="text-[8px] font-black uppercase tracking-widest opacity-40">Invalid Node</span>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden flex items-center justify-center ${className} ${status === 'loading' ? 'bg-slate-100 dark:bg-slate-800/50' : ''}`}>
      {status === 'loading' && (
        <div className="absolute inset-0 flex items-center justify-center z-10">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full animate-[shimmer_2s_infinite]" />
          <Loader2 className="w-5 h-5 text-blue-500/40 animate-spin" />
        </div>
      )}
      
      {status === 'error' ? (
        <div className={`flex flex-col items-center justify-center gap-2 text-slate-300 dark:text-slate-700 w-full h-full ${fallbackClassName}`}>
          <AlertCircle className="w-5 h-5 opacity-20" />
          <span className="text-[8px] font-black uppercase tracking-widest opacity-40">Sync Fault</span>
        </div>
      ) : (
        <img
          {...props}
          ref={imgRef}
          src={processedUrl}
          loading="lazy"
          className={`${className} transition-opacity duration-700 ${status === 'loaded' ? 'opacity-100' : 'opacity-0'}`}
          onLoad={() => {
            setStatus('loaded');
            if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
          }}
          onError={() => {
            setStatus('error');
            if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
          }}
        />
      )}
    </div>
  );
};

export default ProtocolImage;
