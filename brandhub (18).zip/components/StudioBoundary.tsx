
// @ts-nocheck
import React, { Component, ErrorInfo, ReactNode } from 'react';
import { ShieldAlert, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
  title: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

/**
 * StudioBoundary Protocol
 * High-fidelity error isolation for brand studios.
 */
// Fix: Explicitly extend Component from 'react' to ensure members like props and setState are correctly inherited
class StudioBoundary extends Component<Props, State> {
  // Fix: Explicitly define and initialize state as a class member
  public state: State = {
    hasError: false,
    error: null
  };

  constructor(props: Props) {
    super(props);
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  // Fix: Use named ErrorInfo import to ensure correct type recognition
  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Fix: Access props from the inherited Component class member
    console.error(`Studio Protocol Fault [${this.props.title}]:`, error, errorInfo);
  }

  handleReset = () => {
    // Fix: Use the inherited this.setState from Component to update the isolation state
    this.setState({ hasError: false, error: null });
  };

  render() {
    // Fix: Correctly destructure state and props from the class instance members
    const { hasError } = this.state;
    const { title, children } = this.props;

    if (hasError) {
      return (
        <div className="p-12 bg-red-500/5 border border-red-500/20 rounded-[2.5rem] text-center space-y-6 animate-in fade-in zoom-in duration-500">
          <div className="w-16 h-16 bg-red-500 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-red-500/20">
            <ShieldAlert className="w-8 h-8 text-white" />
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-black text-red-600 dark:text-red-400 uppercase tracking-tight">Studio Node Fragmented</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto leading-relaxed uppercase font-bold tracking-widest">
              A structural fault occurred in the {title} protocol. Node isolated to prevent system-wide contamination.
            </p>
          </div>
          <button 
            onClick={this.handleReset}
            className="flex items-center gap-2 px-6 py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl font-black text-[10px] uppercase tracking-widest hover:scale-105 transition-all mx-auto"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Re-Initialize Node
          </button>
        </div>
      );
    }

    return children;
  }
}

export default StudioBoundary;
