
import React, { useState } from 'react';
// Added ShieldCheck to imports from lucide-react
import { Shield, Key, User, ArrowRight, Loader2, AlertCircle, ArrowLeft, Bookmark, Sparkles, ShieldCheck } from 'lucide-react';
import Logo from './Logo';

interface AdminLoginProps {
  onSuccess: () => void;
  onCancel: () => void;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onSuccess, onCancel }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    // Simulated Handshake
    await new Promise(r => setTimeout(r, 1200));

    if (username === 'admin' && password === 'protocol2025') {
      if (rememberMe) {
        localStorage.setItem('admin_session_active', 'true');
      }
      onSuccess();
    } else {
      setError('Neural handshake rejected: Credentials invalid.');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-6 relative overflow-hidden bg-[#02030a] font-sans">
      
      {/* GOOGLE-STYLE ATMOSPHERIC BACKGROUND */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Living Blobs */}
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-600/20 rounded-full blur-[120px] animate-blob" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-indigo-600/20 rounded-full blur-[120px] animate-blob [animation-delay:2s]" />
        <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] bg-sky-500/10 rounded-full blur-[100px] animate-blob [animation-delay:4s]" />
        
        {/* Fine Grain / Noise Texture */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
             style={{ backgroundImage: `url("https://www.transparenttextures.com/patterns/stardust.png")` }} />
        
        {/* Horizon Glow */}
        <div className="absolute bottom-0 left-0 right-0 h-[30%] bg-gradient-to-t from-blue-900/10 to-transparent" />
      </div>

      <div className="max-w-md w-full relative z-10 animate-in fade-in zoom-in duration-1000">
        <div className="bg-slate-900/40 backdrop-blur-3xl border border-white/10 rounded-[3.5rem] p-10 lg:p-12 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] relative overflow-hidden text-left">
          
          {/* Inner Card Detail */}
          <div className="absolute top-0 right-0 p-8 opacity-[0.02] pointer-events-none">
            <Shield className="w-32 h-32 text-white" />
          </div>
          
          <div className="relative z-10 flex flex-col items-center text-center">
            <div className="mb-12 transform hover:scale-105 transition-transform duration-500">
              <Logo size="lg" variant="admin" textClassName="text-white" />
            </div>

            <div className="mb-10 space-y-3">
              <div className="flex items-center justify-center gap-2 mb-1">
                 <Sparkles className="w-4 h-4 text-blue-400 animate-pulse" />
                 <span className="text-[10px] font-black text-blue-500 uppercase tracking-[0.4em]">Secure Portal</span>
              </div>
              <h2 className="text-3xl font-black text-white uppercase tracking-tight">Admin Gateway</h2>
              <p className="text-sm text-slate-400 font-medium max-w-[280px] mx-auto leading-relaxed">Verify identity node to unlock master orchestration protocols.</p>
            </div>

            <form onSubmit={handleSubmit} className="w-full space-y-6">
              <div className="space-y-4">
                <div className="relative group">
                  <User className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-blue-500 transition-colors" />
                  <input
                    required
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Registry ID"
                    className="w-full pl-14 pr-6 py-5 rounded-[1.5rem] bg-white/5 border border-white/10 backdrop-blur-md focus:ring-2 focus:ring-blue-500/50 transition-all text-sm font-bold text-white outline-none placeholder:text-slate-600"
                  />
                </div>

                <div className="relative group">
                  <Key className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-blue-500 transition-colors" />
                  <input
                    required
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Authorization Key"
                    className="w-full pl-14 pr-6 py-5 rounded-[1.5rem] bg-white/5 border border-white/10 backdrop-blur-md focus:ring-2 focus:ring-blue-500/50 transition-all text-sm font-bold text-white outline-none placeholder:text-slate-600"
                  />
                </div>
              </div>

              {/* Memory Option */}
              <div className="flex items-center gap-3 px-2">
                <div className="relative flex items-center">
                  <input
                    type="checkbox"
                    id="remember"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="peer appearance-none w-5 h-5 rounded-lg border-2 border-white/10 bg-white/5 checked:bg-blue-600 checked:border-blue-600 transition-all cursor-pointer"
                  />
                  <Shield className="absolute pointer-events-none w-3 h-3 text-white opacity-0 peer-checked:opacity-100 left-1 transition-opacity" />
                </div>
                <label htmlFor="remember" className="text-[10px] font-black text-slate-500 uppercase tracking-widest cursor-pointer hover:text-slate-300 transition-colors">
                   Maintain active session protocol
                </label>
              </div>

              {error && (
                <div className="p-5 bg-red-900/20 border border-red-500/30 rounded-2xl flex items-center gap-4 animate-in slide-in-from-top-2">
                  <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
                  <p className="text-[10px] text-red-400 font-black uppercase tracking-widest text-left leading-relaxed">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="group relative overflow-hidden rounded-[1.5rem] p-[2px] transition-all duration-700 hover:scale-[1.02] active:scale-95 shadow-2xl w-full"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-indigo-600 to-sky-500 animate-shimmer" style={{ backgroundSize: '200% 100%' }} />
                <div className="relative bg-slate-900 dark:bg-[#05070e] rounded-[1.4rem] px-8 py-5 flex items-center justify-center gap-3">
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 text-white animate-spin" />
                  ) : (
                    <>
                      <span className="text-sm font-black text-white tracking-[0.2em] uppercase">Initialize Node</span>
                      <ArrowRight className="w-4 h-4 text-blue-400 group-hover:translate-x-2 transition-transform" />
                    </>
                  )}
                </div>
              </button>
            </form>

            <button 
              onClick={onCancel}
              className="mt-10 text-slate-500 hover:text-white text-[9px] font-black uppercase tracking-[0.5em] flex items-center gap-3 transition-all group"
            >
              <ArrowLeft className="w-3 h-3 group-hover:-translate-x-1 transition-transform" /> Abort Authorization
            </button>
          </div>
        </div>
        
        {/* Footer Meta */}
        <div className="mt-8 flex items-center justify-center gap-6 opacity-30">
           <div className="flex items-center gap-2">
              <ShieldCheck className="w-3 h-3 text-blue-500" />
              <span className="text-[8px] font-black text-white uppercase tracking-widest">End-to-End Encryption</span>
           </div>
           <div className="w-1 h-1 rounded-full bg-slate-700" />
           <span className="text-[8px] font-black text-white uppercase tracking-widest">Build 2.6.0 Stable</span>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
