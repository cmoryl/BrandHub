
import React from 'react';
import { ArrowRight, EyeOff, Box, Star, ShieldCheck, RefreshCw, Cpu, CheckCircle2 } from 'lucide-react';
import { Brand } from '../types';
import ProtocolImage from './ProtocolImage';
import { getOptimizedImageUrl } from '../utils/linkUtils';

interface BrandCardProps {
  brand: Brand;
  onClick: (brand: Brand) => void;
  isFavorite?: boolean;
  toggleFavorite?: () => void;
}

const BrandCard: React.FC<BrandCardProps> = ({ brand, onClick, isFavorite, toggleFavorite }) => {
  const isProduct = brand.entityType === 'product';
  const optimizedCover = getOptimizedImageUrl(brand.coverImage, 600);
  
  // Simulated integrity score based on sections populated
  const integrityScore = Math.round(((brand.sections?.filter(s => s.isVisible).length || 0) / 19) * 100);
  const hasIntelligence = !!brand.intelligenceBrain || !!brand.brainRegistry?.archetype;

  return (
    <div 
      onClick={() => onClick(brand)}
      className="group relative rounded-[2.5rem] transition-all duration-500 cursor-pointer h-full min-h-[450px] overflow-hidden flex flex-col bg-white dark:bg-slate-900/40 backdrop-blur-xl border border-slate-200 dark:border-white/5 shadow-sm hover:shadow-2xl hover:shadow-blue-500/10 hover:-translate-y-2 hover-lift"
    >
      <div className="relative h-52 overflow-hidden shrink-0">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-white/90 dark:to-slate-900/90 z-10 transition-colors duration-500" />
        <ProtocolImage 
          src={optimizedCover} 
          alt={`${brand.name} cover`} 
          className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-110"
          loading="lazy"
        />
        
        <div className="absolute top-6 left-6 z-20 transition-transform duration-300 group-hover:scale-105">
          <div className="w-16 h-16 rounded-2xl bg-white/90 dark:bg-white backdrop-blur-md p-2.5 shadow-2xl border border-white/30 flex items-center justify-center overflow-hidden">
             <ProtocolImage src={brand.logoUrl} alt="logo" className="max-h-full max-w-full object-contain" />
          </div>
        </div>
        
        <div className="absolute top-6 right-6 flex items-center gap-2 z-20">
           {toggleFavorite && (
             <button 
              onClick={(e) => { e.stopPropagation(); toggleFavorite(); }}
              className={`p-3 rounded-2xl backdrop-blur-md border shadow-lg transition-all duration-300 hover:scale-110 ${isFavorite ? 'bg-yellow-400 border-yellow-300 text-white' : 'bg-slate-900/40 dark:bg-black/60 border-white/10 text-white hover:bg-slate-900/80'}`}
             >
               <Star className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
             </button>
           )}

           {isProduct && (
              <div className="bg-blue-600 backdrop-blur-md px-3 py-1.5 rounded-xl text-white text-[9px] font-black shadow-lg border border-blue-400/20 flex items-center gap-1.5 tracking-widest uppercase">
                  <Box className="w-3 h-3" /> PRODUCT
              </div>
           )}
           
           {!brand.isVisible && (
              <div className="bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl text-white text-[9px] font-black flex items-center gap-1.5 shadow-sm border border-white/10 tracking-widest uppercase">
                  <EyeOff className="w-3 h-3" /> HIDDEN
              </div>
           )}
        </div>

        <div className="absolute bottom-6 left-6 z-20 flex items-center gap-2">
           <div className="px-3 py-1.5 bg-white/30 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-xl text-[8px] font-black text-slate-900 dark:text-white uppercase tracking-[0.2em] flex items-center gap-2">
              <RefreshCw className="w-2.5 h-2.5 animate-spin-slow" /> v{brand.version}
           </div>
           {hasIntelligence && (
             <div className="px-3 py-1.5 bg-indigo-500/20 dark:bg-indigo-500/20 backdrop-blur-md border border-indigo-500/30 rounded-xl text-[8px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-[0.2em] flex items-center gap-2">
                <Cpu className="w-2.5 h-2.5 animate-pulse" /> Brain Linked
             </div>
           )}
        </div>
      </div>
      
      <div className="p-10 flex-1 flex flex-col text-left relative z-20">
        <div className="mb-4">
          <div className="flex items-center gap-3 mb-2">
             <p className="text-[10px] text-blue-600 dark:text-blue-400 font-black uppercase tracking-[0.2em]">{brand.industry}</p>
             <div className="w-1.5 h-1.5 rounded-full bg-slate-200 dark:bg-white/10" />
             <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em]">{brand.category}</p>
          </div>
          <h3 className="text-2xl font-black text-slate-900 dark:text-white transition-colors tracking-tight uppercase leading-tight">{brand.name}</h3>
        </div>
        
        <p className="text-slate-600 dark:text-slate-400 text-sm line-clamp-2 mb-8 flex-1 leading-relaxed font-medium">
          {brand.description}
        </p>

        <div className="flex items-center justify-between pt-8 border-t border-slate-100 dark:border-white/5">
          <div className="flex flex-col gap-2">
             <div className="flex -space-x-2">
                {brand.sections?.slice(0, 4).map((s, i) => (
                  <div key={i} className="w-8 h-8 rounded-full bg-slate-100 dark:bg-white/5 backdrop-blur-md border-2 border-white dark:border-slate-800 flex items-center justify-center text-[8px] font-black text-slate-400 dark:text-slate-500 shadow-sm" title={s.title}>
                      {s.title.charAt(0)}
                  </div>
                ))}
             </div>
             <div className="flex items-center gap-2">
                <span className="text-[9px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">Integrity: {integrityScore}%</span>
                <div className="w-12 h-1 bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
                   <div className="h-full bg-emerald-500" style={{ width: `${integrityScore}%` }} />
                </div>
             </div>
          </div>
          <span className="w-12 h-12 rounded-2xl bg-blue-600/10 dark:bg-blue-400/10 backdrop-blur-md flex items-center justify-center text-blue-600 dark:text-blue-400 transition-all duration-500 group-hover:bg-blue-600 group-hover:text-white shadow-xl group-hover:shadow-blue-500/40 active:scale-90 border border-transparent dark:border-white/5">
            <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
          </span>
        </div>
      </div>
    </div>
  );
};

export default BrandCard;
