
// @ts-nocheck
import React, { useState, useMemo } from 'react';
import { 
  BrandSection, Brand, Asset, Color, BrandTemplate, Typography, Gradient, EmailSignature, DocumentSpecimen
} from '../types';
import ColorPalette from './ColorPalette';
import ProtocolImage from './ProtocolImage';
import StudioBoundary from './StudioBoundary';
import QRCodeGenerator from './QRCodeGenerator';
import QRCodeRequest from './QRCodeRequest';
import VisualPlayground from './VisualPlayground';
import { getEmbedUrl, getVideoType, getDirectImageUrl } from '../utils/linkUtils';
import { 
  ShieldCheck, Box, Palette, MapPin, DownloadCloud, FileArchive, QrCode,
  CheckCircle2, Download, Navigation, RefreshCw, PenTool, ArrowRight, Zap, 
  Type, Sliders, Activity, Image as ImageIcon, AlertTriangle, FileText,
  Target, Fingerprint, Layers, Mail, ExternalLink, Globe, Copy, Ban, File, Hash,
  FileSearch, Lightbulb, BookOpen, Star, Film, Play, MonitorPlay, Hexagon, Shield, Layout,
  Link as LinkIcon, Info, Code, Eye, ChevronRight, Briefcase, Cpu
} from 'lucide-react';

const ProductPortfolioRenderer = ({ brand, brands, onBrandClick }: { brand: Brand, brands: Brand[], onBrandClick: (b: Brand) => void }) => {
  const linkedBrands = useMemo(() => {
    // If master brand, show its products
    if (brand.entityType === 'brand') {
      return brands.filter(b => b.entityType === 'product' && (b.industry === brand.industry || b.category === 'SaaS'));
    }
    // If product, show the master brand
    return brands.filter(b => b.entityType === 'brand' && b.industry === brand.industry);
  }, [brand, brands]);

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 font-sans">
       {linkedBrands.map(lb => (
         <div 
           key={lb.id} 
           onClick={() => onBrandClick(lb)}
           className="group cursor-pointer bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/5 rounded-[2.5rem] p-8 shadow-xl transition-all hover:shadow-2xl hover:-translate-y-1 text-left relative overflow-hidden"
         >
            <div className="absolute top-0 right-0 p-6 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
               {lb.entityType === 'brand' ? <ShieldCheck className="w-24 h-24" /> : <Box className="w-24 h-24" />}
            </div>
            <div className="flex items-center gap-5 mb-6">
               <div className="w-16 h-16 rounded-2xl bg-slate-50 dark:bg-black/20 p-3 border border-slate-100 dark:border-white/10 flex items-center justify-center shrink-0 shadow-inner group-hover:bg-white dark:group-hover:bg-black/40 transition-colors">
                  <ProtocolImage src={lb.logoUrl} className="max-h-full max-w-full object-contain drop-shadow-lg" />
               </div>
               <div>
                  <h4 className="text-xl font-black dark:text-white uppercase tracking-tight leading-none">{lb.name}</h4>
                  <span className="text-[9px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-widest mt-1 block">{lb.entityType} Node</span>
               </div>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium leading-relaxed mb-6 line-clamp-2">
               {lb.description}
            </p>
            <div className="pt-6 border-t border-slate-100 dark:border-white/5 flex items-center justify-between">
               <div className="flex items-center gap-2">
                  <Cpu className="w-3.5 h-3.5 text-slate-400" />
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Protocol Linked</span>
               </div>
               <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-blue-500 transition-colors" />
            </div>
         </div>
       ))}
       {linkedBrands.length === 0 && (
         <div className="col-span-full py-20 bg-slate-50 dark:bg-white/5 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-white/5 flex flex-col items-center justify-center opacity-40">
            <Layers className="w-12 h-12 mb-4" />
            <span className="text-xs font-black uppercase tracking-[0.4em]">No Linked Portfolio Nodes</span>
         </div>
       )}
    </div>
  );
};

const LogoProtocolInspector = ({ name, rawUrl }: { name: string, rawUrl: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  const resolvedUrl = getDirectImageUrl(rawUrl);
  const isCloudLink = rawUrl.includes('dropbox.com') || rawUrl.includes('drive.google.com') || rawUrl.includes('1drv.ms');

  return (
    <div className="w-full mt-6 space-y-3">
       <button 
          onClick={() => setIsOpen(!isOpen)}
          className={`w-full flex items-center justify-between px-5 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all border ${isOpen ? 'bg-slate-900 text-white border-blue-500/50' : 'bg-slate-50 dark:bg-white/5 text-slate-400 border-slate-100 dark:border-white/5 hover:border-blue-500/30'}`}
       >
          <div className="flex items-center gap-2">
             <Code className="w-3 h-3" />
             <span>Protocol Inspector</span>
          </div>
          <ChevronRight className={`w-3 h-3 transition-transform ${isOpen ? 'rotate-90 text-blue-400' : ''}`} />
       </button>

       {isOpen && (
         <div className="p-6 bg-slate-950 rounded-2xl border border-white/10 space-y-5 animate-in slide-in-from-top-2 duration-300">
            <div className="space-y-2">
               <div className="flex items-center justify-between">
                  <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Registry Input</span>
                  {isCloudLink && <span className="px-2 py-0.5 bg-blue-500/10 text-blue-500 rounded text-[7px] font-black">Cloud Link Detected</span>}
               </div>
               <div className="p-3 bg-black/40 rounded-lg border border-white/5 group relative">
                  <p className="text-[10px] font-mono text-slate-400 break-all leading-relaxed pr-8">{rawUrl}</p>
                  <button onClick={() => { navigator.clipboard.writeText(rawUrl); alert('Raw URL Copied'); }} className="absolute right-2 top-2 p-1.5 hover:bg-white/10 rounded-md text-slate-500"><Copy className="w-3 h-3" /></button>
               </div>
            </div>

            <div className="space-y-2">
               <div className="flex items-center justify-between">
                  <span className="text-[8px] font-black text-blue-400 uppercase tracking-widest">Resolved Protocol</span>
                  <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-500 rounded text-[7px] font-black">Stream Ready</span>
               </div>
               <div className="p-3 bg-black/40 rounded-lg border border-white/5 group relative">
                  <p className="text-[10px] font-mono text-blue-300 break-all leading-relaxed pr-8">{resolvedUrl}</p>
                  <button onClick={() => { navigator.clipboard.writeText(resolvedUrl); alert('Resolved URL Copied'); }} className="absolute right-2 top-2 p-1.5 hover:bg-white/10 rounded-md text-blue-400"><Copy className="w-3 h-3" /></button>
               </div>
            </div>
            
            <div className="pt-2 flex items-center gap-2">
               <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
               <span className="text-[8px] font-black text-slate-600 uppercase tracking-[0.2em]">Node Reachability Verified</span>
            </div>
         </div>
       )}
    </div>
  );
};

const DocumentGalleryRenderer = ({ items, icon: Icon }: { items: DocumentSpecimen[], icon: any }) => (
  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10 font-sans">
    {(items || []).map((item, i) => (
      <div key={i} className="group flex flex-col bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/5 rounded-[3rem] overflow-hidden shadow-xl transition-all hover:shadow-2xl hover:-translate-y-2">
         <div className="relative aspect-[3/4] overflow-hidden bg-slate-100 dark:bg-black/20">
            <ProtocolImage src={item.previewUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-8">
               <a href={item.templateUrl} target="_blank" className="flex items-center justify-center gap-3 py-4 bg-white text-black rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] shadow-2xl hover:scale-105 active:scale-95 transition-all">
                  <Zap className="w-4 h-4" /> Initialize Template
               </a>
            </div>
            <div className="absolute top-6 left-6 px-4 py-2 bg-black/40 backdrop-blur-md rounded-xl border border-white/20">
               <span className="text-[9px] font-black text-white uppercase tracking-widest">{item.category}</span>
            </div>
         </div>
         <div className="p-8 text-left space-y-4">
            <div className="space-y-1">
               <h4 className="text-xl font-black dark:text-white uppercase tracking-tight leading-none">{item.title}</h4>
               <p className="text-xs text-slate-500 dark:text-slate-400 font-medium leading-relaxed">{item.description}</p>
            </div>
            <div className="pt-4 border-t border-slate-100 dark:border-white/5 flex items-center justify-between">
               <div className="flex items-center gap-2">
                  <Icon className="w-3.5 h-3.5 text-blue-500 dark:text-blue-400" />
                  <span className="text-[9px] font-black text-slate-400 dark:text-slate-300 uppercase tracking-widest">Document Specimen</span>
               </div>
               <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-blue-500 transition-colors" />
            </div>
         </div>
      </div>
    ))}
  </div>
);

const CinematicRenderer = ({ assets }: { assets: any[] }) => (
  <div className="grid md:grid-cols-2 gap-12 font-sans">
    {(assets || []).map((asset, i) => {
      const type = getVideoType(asset.url);
      const embedUrl = getEmbedUrl(asset.url);
      
      return (
        <div key={i} className="group bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/5 rounded-[3.5rem] overflow-hidden shadow-2xl transition-all hover:border-purple-500/30">
          <div className="aspect-video bg-black relative overflow-hidden">
             {type === 'direct' ? (
               <video 
                 src={asset.url} 
                 className="w-full h-full object-cover" 
                 controls 
                 muted={asset.type === 'motion'} 
                 autoPlay={asset.type === 'motion'} 
                 loop={asset.type === 'motion'} 
                 playsInline 
               />
             ) : type !== 'unsupported' ? (
               <iframe 
                 src={embedUrl} 
                 className="w-full h-full border-none" 
                 allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                 allowFullScreen 
               />
             ) : (
               <div className="w-full h-full flex flex-col items-center justify-center text-slate-700 gap-4">
                  <MonitorPlay className="w-16 h-16 opacity-20" />
                  <span className="text-[10px] font-black uppercase tracking-widest opacity-40">Stream Link Fault</span>
               </div>
             )}
             
             <div className="absolute top-6 left-6 flex gap-3 pointer-events-none">
                <div className="px-4 py-2 bg-black/60 backdrop-blur-md rounded-xl border border-white/10 flex items-center gap-2">
                   <Film className="w-3.5 h-3.5 text-purple-400" />
                   <span className="text-[9px] font-black text-white uppercase tracking-widest">{asset.type || 'PROTOCOL'}</span>
                </div>
             </div>
          </div>
          <div className="p-10 text-left flex items-center justify-between">
             <div>
                <h4 className="text-xl font-black dark:text-white uppercase tracking-tight">{asset.name || 'Motion Node'}</h4>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Asset Hash: {asset.id?.slice(-8) || 'AUTO-GEN'}</p>
             </div>
             <a href={asset.url} target="_blank" className="p-4 bg-slate-50 dark:bg-white/5 hover:bg-purple-600 hover:text-white rounded-2xl transition-all text-slate-400 shadow-sm">
                <ExternalLink className="w-5 h-5" />
             </a>
          </div>
        </div>
      );
    })}
    {(!assets || assets.length === 0) && (
      <div className="col-span-full py-24 bg-slate-50 dark:bg-slate-900/40 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-white/5 flex flex-col items-center justify-center opacity-40">
         <Film className="w-16 h-16 mb-4" />
         <span className="text-xs font-black uppercase tracking-[0.4em]">No Cinematic Assets Registered</span>
      </div>
    )}
  </div>
);

const SignatureRenderer = ({ signatures }: { signatures: EmailSignature[] }) => (
  <div className="grid md:grid-cols-2 gap-10 font-sans">
    {(signatures || []).map((sig, i) => (
      <div key={i} className="group p-10 bg-white dark:bg-slate-900 border border-slate-200 dark:border-white/5 rounded-[3rem] shadow-xl transition-all hover:border-blue-500/30">
        <div className="flex items-center justify-between mb-8">
           <div className="flex items-center gap-4 text-left">
              <div className="p-3 bg-blue-600 rounded-xl text-white"><Mail className="w-5 h-5" /></div>
              <div>
                <span className="block text-sm font-black dark:text-white uppercase tracking-tight">{sig.name}</span>
                <span className="block text-[10px] text-slate-400 dark:text-slate-300 uppercase font-bold tracking-widest">{sig.role}</span>
              </div>
           </div>
           <button onClick={() => { navigator.clipboard.writeText(sig.html); alert('HTML Protocol Copied'); }} className="p-3 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-blue-500 rounded-xl transition-all"><Copy className="w-4 h-4" /></button>
        </div>
        <div className="bg-slate-50 dark:bg-black/20 rounded-2xl p-8 border border-slate-100 dark:border-white/5 overflow-hidden text-left">
           <div dangerouslySetInnerHTML={{ __html: sig.html }} />
        </div>
      </div>
    ))}
  </div>
);

const TemplateRenderer = ({ templates }: { templates: BrandTemplate[] }) => (
  <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 font-sans">
    {(templates || []).map((t, i) => (
      <div key={i} className={`p-8 rounded-[2.5rem] border flex flex-col text-left transition-all hover:scale-[1.02] ${t.isCallout ? 'bg-blue-600 border-blue-400 text-white shadow-2xl' : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-white/5 shadow-lg'}`}>
         <div className={`p-4 rounded-2xl w-fit mb-6 ${t.isCallout ? 'bg-white/20' : 'bg-slate-50 dark:bg-slate-800'}`}>
            <FileArchive className={`w-8 h-8 ${t.isCallout ? 'text-white' : 'text-blue-500'}`} />
         </div>
         <h4 className="text-lg font-black uppercase mb-2">{t.name}</h4>
         <p className={`text-xs mb-8 flex-1 leading-relaxed ${t.isCallout ? 'text-white/80' : 'text-slate-500 dark:text-slate-300'}`}>{t.description}</p>
         <div className="flex items-center justify-between border-t border-current/10 pt-6">
            <span className="text-[9px] font-black uppercase tracking-widest opacity-60">{t.fileType} • {t.fileSize}</span>
            <a href={t.downloadUrl} className={`p-3 rounded-xl transition-all ${t.isCallout ? 'bg-white text-blue-600' : 'bg-blue-600 text-white'}`}><Download className="w-4 h-4" /></a>
         </div>
      </div>
    ))}
  </div>
);

const SectionHeading = ({ title, icon: Icon, description, isEditMode, onUpdateDescription }: any) => {
  const [isEditing, setIsEditing] = useState(false);
  const [val, setVal] = useState(description || '');
  return (
    <div className="mb-16 text-left font-sans">
      <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-slate-200 dark:border-white/10 pb-10 mb-8 gap-6">
        <div className="flex items-center gap-6">
          <div className="p-4 rounded-[1.5rem] bg-blue-600 text-white shadow-[0_15px_35px_-10px_rgba(37,99,235,0.4)] transition-transform hover:rotate-3">
             <Icon className="w-8 h-8" />
          </div>
          <div className="space-y-1">
             <span className="text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-[0.4em] block">Studio Protocol</span>
             <h2 className="text-4xl lg:text-5xl font-black text-slate-900 dark:text-white uppercase tracking-tighter leading-none">{title}</h2>
          </div>
        </div>
        {isEditMode && (
           <button onClick={() => setIsEditing(!isEditing)} className="flex items-center gap-2 px-6 py-2.5 bg-slate-100 dark:bg-white/5 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600 text-[10px] font-black uppercase text-slate-500 dark:text-slate-300 rounded-xl transition-all shadow-sm">
              <PenTool className="w-3.5 h-3.5" /> Edit Guidance
           </button>
        )}
      </div>
      {isEditing ? (
        <div className="bg-slate-50 dark:bg-slate-900/60 backdrop-blur-xl p-8 rounded-[2.5rem] border border-slate-200 dark:border-white/10 shadow-2xl animate-in zoom-in duration-500">
          <textarea 
            value={val} 
            onChange={e => setVal(e.target.value)} 
            className="w-full h-40 bg-white dark:bg-black/40 p-6 text-slate-900 dark:text-white rounded-2xl border border-slate-200 dark:border-white/5 outline-none focus:ring-2 focus:ring-blue-500 font-medium text-lg leading-relaxed shadow-inner" 
            placeholder="Define official governance guidelines for this studio..."
          />
          <div className="flex justify-end gap-3 mt-6">
             <button onClick={() => setIsEditing(false)} className="px-6 py-3 text-slate-500 font-black uppercase text-[10px] tracking-widest">Cancel</button>
             <button onClick={() => { onUpdateDescription(val); setIsEditing(false); }} className="bg-blue-600 hover:bg-blue-700 px-8 py-3 rounded-xl text-white text-[10px] font-black uppercase tracking-[0.2em] shadow-xl shadow-blue-600/20 active:scale-95 transition-all">Commit Changes</button>
          </div>
        </div>
      ) : (
        <p className="text-xl lg:text-2xl text-slate-500 dark:text-slate-300 font-light leading-relaxed max-w-4xl text-balance">
           {description || `Official standards and governance protocols for ${title}.`}
        </p>
      )}
    </div>
  );
};

const STUDIO_MAP = {
  identity: { icon: ShieldCheck, comp: (brand) => (
    <div className="p-16 bg-white dark:bg-slate-900/60 backdrop-blur-2xl rounded-[4rem] border border-slate-200 dark:border-white/10 text-left shadow-2xl relative overflow-hidden group font-sans">
      <div className="absolute top-0 right-0 p-20 opacity-[0.03] pointer-events-none group-hover:opacity-[0.07] transition-opacity">
         <ShieldCheck className="w-64 h-64 text-emerald-500" />
      </div>
      <div className="relative z-10 space-y-12">
         <div className="space-y-4">
            <span className="text-[11px] font-black uppercase text-blue-600 dark:text-blue-400 tracking-[0.5em] block">Mission Architecture</span>
            <p className="text-4xl lg:text-5xl font-light italic text-slate-900 dark:text-white leading-[1.1] max-w-4xl tracking-tight">"{brand.missionStatement}"</p>
         </div>
         <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {(brand.values || []).map((v, i) => (
               <div key={i} className="p-8 bg-slate-50 dark:bg-white/5 rounded-[2.5rem] border border-slate-100 dark:border-white/5 shadow-sm transition-all hover:scale-105">
                  <Zap className="w-8 h-8 text-blue-500 mb-4" />
                  <span className="text-xs font-black dark:text-white uppercase tracking-widest block">{v.text}</span>
                  <span className="text-[9px] font-bold text-slate-400 dark:text-slate-300 uppercase tracking-tighter mt-1 block">CORE VALUE</span>
               </div>
            ))}
         </div>
      </div>
    </div>
  )},
  colors: { icon: Palette, comp: (brand) => <ColorPalette colors={brand.colors} brand={brand} mode="view" /> },
  playground: { icon: Layout, comp: (brand) => <VisualPlayground brand={brand} /> },
  products: { icon: Briefcase, comp: (brand, data, { brands, onBrandClick }) => <ProductPortfolioRenderer brand={brand} brands={brands} onBrandClick={onBrandClick} /> },
  caseStudies: { icon: FileSearch, msg: "Case Study Specimen", icon: FileSearch, comp: (brand) => <DocumentGalleryRenderer items={brand.caseStudies || []} icon={FileSearch} /> },
  brochures: { icon: BookOpen, comp: (brand) => <DocumentGalleryRenderer items={brand.brochures || []} icon={BookOpen} /> },
  spotlights: { icon: Star, comp: (brand) => <DocumentGalleryRenderer items={brand.spotlights || []} icon={Star} /> },
  cinematic: { icon: Film, comp: (brand) => <CinematicRenderer assets={brand.cinematicAssets || []} /> },
  signatures: { icon: Mail, comp: (brand) => <SignatureRenderer signatures={brand.signatures || []} /> },
  templates: { icon: FileText, comp: (brand) => <TemplateRenderer templates={brand.templates || []} /> },
  qr: { icon: QrCode, comp: (brand) => (
    <div className="grid lg:grid-cols-2 gap-12 font-sans">
       <div className="bg-white dark:bg-slate-900 p-12 rounded-[4rem] border border-slate-200 dark:border-white/5 shadow-2xl"><QRCodeGenerator brand={brand} /></div>
       <QRCodeRequest brand={brand} />
    </div>
  )},
  brandIcon: { icon: Shield, comp: (brand) => (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10 font-sans">
      {(brand.brandIcons || []).map((icon, i) => (
        <div key={i} className="group p-12 bg-white dark:bg-slate-900/60 backdrop-blur-xl border border-slate-200 dark:border-white/10 rounded-[3rem] flex flex-col items-center shadow-lg hover:shadow-2xl transition-all hover:-translate-y-2 text-center">
          <div className="p-10 bg-slate-50 dark:bg-black/20 rounded-[2rem] border border-slate-100 dark:border-white/5 w-full flex items-center justify-center aspect-square shadow-inner group-hover:bg-white dark:group-hover:bg-black/40 transition-colors">
            <ProtocolImage src={icon.url} className="w-32 h-32 object-contain drop-shadow-2xl" />
          </div>
          <div className="mt-8 space-y-2">
             <span className="block text-[11px] font-black uppercase text-slate-900 dark:text-white tracking-[0.2em]">{icon.name} Node</span>
             <p className="text-[9px] text-slate-400 dark:text-slate-300 font-medium leading-relaxed max-w-[200px]">{icon.settings}</p>
          </div>
        </div>
      ))}
      {(!brand.brandIcons || brand.brandIcons.length === 0) && (
        <div className="col-span-full py-24 border-2 border-dashed border-slate-200 dark:border-white/5 rounded-[3rem] flex flex-col items-center justify-center opacity-30">
          <Hexagon className="w-16 h-16 mb-4" />
          <span className="text-xs font-black uppercase tracking-[0.4em]">No Symbols Registered</span>
        </div>
      )}
    </div>
  )},
  logos: { icon: Box, comp: (brand) => (
    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 font-sans">
      {Object.entries(brand.logos || {})
        .filter(([k, v]) => typeof v === 'string' && v.trim() !== '' && !['guidelines', 'id', 'headerLogoVariant'].includes(k))
        .map(([k, v]) => (
        <div key={k} className="group p-10 bg-white dark:bg-slate-900/60 backdrop-blur-xl border border-slate-200 dark:border-white/10 rounded-[3rem] flex flex-col items-center shadow-lg hover:shadow-2xl transition-all hover:-translate-y-2 text-center relative overflow-hidden">
          <div className="p-8 bg-slate-50 dark:bg-black/20 rounded-[2rem] border border-slate-100 dark:border-white/5 w-full flex items-center justify-center aspect-video shadow-inner group-hover:bg-white dark:group-hover:bg-black/40 transition-colors mb-6">
            <ProtocolImage src={v} className="max-h-full max-w-full object-contain drop-shadow-2xl" />
          </div>
          <div className="space-y-1">
             <span className="block text-[11px] font-black uppercase text-slate-900 dark:text-white tracking-[0.2em]">{k} Variant</span>
             <span className="block text-[9px] font-bold text-slate-400 dark:text-slate-300 uppercase tracking-widest">Protocol Node Verified</span>
          </div>
          
          <div className="mt-6 flex flex-col gap-2 w-full pt-6 border-t border-slate-100 dark:border-white/5">
             <div className="flex gap-2">
                <button 
                  onClick={() => { navigator.clipboard.writeText(v); alert('Registry Link Copied'); }}
                  className="flex-1 flex items-center justify-center gap-2 py-3 bg-slate-50 dark:bg-white/5 hover:bg-blue-600 hover:text-white rounded-xl text-[8px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-300 transition-all"
                >
                   <Copy className="w-3 h-3" /> Copy Registry Link
                </button>
                <a 
                   href={v} 
                   target="_blank" 
                   className="p-3 bg-slate-50 dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 rounded-xl text-slate-400"
                >
                   <ExternalLink className="w-3 h-3" />
                </a>
             </div>
             
             {/* DEBUG PROTOCOL INSPECTOR */}
             <LogoProtocolInspector name={k} rawUrl={v} />
          </div>
        </div>
      ))}
    </div>
  )}
};

export const SectionRenderer: React.FC<any> = ({ brand, brands, section, mode, onUpdate, onBrandClick }) => {
  const studio = STUDIO_MAP[section.type] || { icon: Box, comp: () => <div className="p-20 border-2 border-dashed border-slate-200 dark:border-white/5 rounded-[3rem] text-slate-400 uppercase font-black text-sm tracking-[0.3em] backdrop-blur-sm text-center">Studio Node: {section.type} // SYNTHESIS PENDING</div> };
  return (
    <StudioBoundary title={section.title}>
      <div className="animate-in fade-in duration-1000 mb-32">
        <SectionHeading 
          title={section.title} 
          icon={studio.icon} 
          description={section.description} 
          isEditMode={mode === 'edit'} 
          onUpdateDescription={(d) => onUpdate({ description: d })} 
        />
        <div className="section-content">
          {studio.comp(brand, section.data, { brands, onBrandClick })}
        </div>
      </div>
    </StudioBoundary>
  );
};
