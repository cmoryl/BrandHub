
import { z } from 'zod';

export const ColorSchema = z.object({
  name: z.string().default('Unnamed Color'),
  hex: z.string().regex(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/).default('#000000'),
  usage: z.enum(['primary', 'secondary', 'accent', 'neutral']).default('primary'),
});

export const DocumentSpecimenSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  previewUrl: z.string(),
  templateUrl: z.string(),
  category: z.string(),
});

export const SectionTypeSchema = z.enum([
  'hero', 'identity', 'logos', 'brandIcon', 'colors', 'gradients', 
  'patterns', 'typography', 'textStyles', 'iconography', 'socialIcons',
  'imagery', 'social', 'signatures', 'qr', 'ai', 'assets', 'misuse', 
  'products', 'atmosphere', 'templates', 'custom', 'cinematic',
  'caseStudies', 'brochures', 'spotlights', 'playground'
]);

export const BrandSectionSchema = z.object({
  id: z.string(),
  type: SectionTypeSchema,
  title: z.string(),
  description: z.string().optional(),
  isVisible: z.boolean().default(true),
  data: z.any().default({}),
  order: z.number().default(0),
});

export const BrandSchema = z.object({
  id: z.string().uuid().or(z.string()),
  version: z.string().default('2.6.0'),
  name: z.string().min(1).default('New Protocol'),
  entityType: z.enum(['brand', 'product']).default('brand'),
  isVisible: z.boolean().default(true),
  category: z.string().default('Other'),
  logoUrl: z.string().default(''),
  coverImage: z.string().default(''),
  description: z.string().default(''),
  industry: z.string().default('Technology'),
  tagline: z.string().optional(),
  archetype: z.string().optional(),
  updatedAt: z.number().default(Date.now()),
  status: z.enum(['active', 'maintenance', 'deprecated']).default('active'),
  sections: z.array(BrandSectionSchema).default([]),
  toneOfVoice: z.array(z.string()).default([]),
  colors: z.array(ColorSchema).default([]),
  typography: z.array(z.any()).default([]),
  assets: z.array(z.any()).default([]),
  caseStudies: z.array(DocumentSpecimenSchema).default([]),
  brochures: z.array(DocumentSpecimenSchema).default([]),
  spotlights: z.array(DocumentSpecimenSchema).default([]),
  values: z.array(z.any()).default([]),
  missionStatement: z.string().optional(),
  logos: z.record(z.string()).default({}),
  brandIcon: z.object({
    url: z.string().default(''),
    usageRights: z.string().default(''),
    settings: z.string().default(''),
  }).default({}),
  templates: z.array(z.any()).default([]),
});
