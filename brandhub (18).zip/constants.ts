
import { Color, Brand, TextStyle, BrandSection, Typography, EmailSignature, BrandTemplate, Gradient, Asset, DocumentSpecimen } from './types';

export const STORAGE_KEY = 'brand_data_vault_v4';

const MAIN_SIG_HTML = `
<div style="font-family: 'Poppins', Helvetica, Arial, sans-serif; color: #0f172a; max-width: 500px; padding: 20px; border-left: 4px solid #0033A0; background: #f8fafc; border-radius: 0 16px 16px 0;">
  <p style="margin: 0; font-size: 18px; font-weight: 900; text-transform: uppercase; letter-spacing: -0.02em;">[Employee Name]</p>
  <p style="margin: 2px 0 15px 0; font-size: 13px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em;">Global Orchestrator | Enterprise Solutions</p>
  <div style="margin: 20px 0;">
    <img src="https://www.transperfect.com/themes/custom/transperfect/logo.svg" height="28" alt="Logo" style="display: block;" />
  </div>
  <p style="margin: 0; font-size: 11px; line-height: 1.6; color: #94a3b8; font-weight: 500;">
    <span style="color: #0033A0; font-weight: 800;">T:</span> +1 212.689.5555 <br/>
    <span style="color: #0033A0; font-weight: 800;">W:</span> transperfect.com <br/>
    <span style="color: #64748b;">3 Park Avenue, South Tower, New York, NY 10016</span>
  </p>
</div>
`;

const RESPONSE_SIG_HTML = `
<div style="font-family: 'Poppins', Arial, sans-serif; color: #0f172a; font-size: 13px; border-top: 1px solid #e2e8f0; padding-top: 15px;">
  <p style="margin: 0;"><strong>[Employee Name]</strong></p>
  <p style="margin: 0; color: #0033A0; font-size: 11px; font-weight: bold; text-transform: uppercase;">Identity Verification Protocol Active</p>
</div>
`;

export const DEFAULT_TYPOGRAPHY: Typography[] = [
  { 
    name: 'Poppins Black', 
    role: 'Display' as const, 
    fontFamily: '"Poppins", sans-serif', 
    sampleText: 'Infinite Scalability', 
    isVariable: false,
    description: 'The primary typeface for high-impact display headers and executive summaries.',
    downloadUrl: 'https://fonts.google.com/specimen/Poppins'
  },
  {
    name: 'Poppins Regular',
    role: 'Body' as const,
    fontFamily: '"Poppins", sans-serif',
    sampleText: 'The quick brown fox jumps over the lazy dog.',
    isVariable: false,
    description: 'Highly legible geometric sans-serif for all UI and body copy.',
    downloadUrl: 'https://fonts.google.com/specimen/Poppins'
  }
];

export const DEFAULT_COLORS: Color[] = [
  { name: 'Core Navy', hex: '#0033A0', usage: 'primary' as const },
  { name: 'Electric Blue', hex: '#0077C8', usage: 'primary' as const },
  { name: 'Slate 500', hex: '#64748b', usage: 'secondary' as const },
  { name: 'Ghost White', hex: '#f8fafc', usage: 'neutral' as const },
  { name: 'Cyber Cyan', hex: '#38bdf8', usage: 'accent' as const },
];

export const DEFAULT_BRAND_SECTIONS: BrandSection[] = [
  { id: 'sec-identity', type: 'identity', title: '02 Identity Forge', isVisible: true, order: 0, description: 'Core foundations and mission manifesto.', data: {} },
  { id: 'sec-logos', type: 'logos', title: '03 Mark Repository', isVisible: true, order: 1, description: 'Logo variants and usage guidelines.', data: {} },
  { id: 'sec-symbol', type: 'brandIcon', title: '04 Symbol Protocol', isVisible: true, order: 2, description: 'Shorthand icons and surface stress testing.', data: {} },
  { id: 'sec-products', type: 'products', title: '05 Portfolio Studio', isVisible: true, order: 3, description: 'Ecosystem links and sub-product orchestration.', data: {} },
  { id: 'sec-colors', type: 'colors', title: '07 Palette Lab', isVisible: true, order: 4, description: 'Chromatics and accessibility auditing.', data: {} },
  { id: 'sec-gradients', type: 'gradients', title: '08 Flux Nodes', isVisible: true, order: 5, description: 'Linear and radial depth patterns.', data: {} },
  { id: 'sec-patterns', type: 'patterns', title: '09 Geometric Primitives', isVisible: true, order: 6, description: 'Tiled background textures.', data: {} },
  { id: 'sec-typography', type: 'typography', title: '10 Typography Registry', isVisible: true, order: 7, description: 'Official typeface standards.', data: {} },
  { id: 'sec-textstyles', type: 'textStyles', title: '11 Semantic Hierarchies', isVisible: true, order: 8, description: 'CSS type standards and hierarchies.', data: {} },
  { id: 'sec-iconography', type: 'iconography', title: '12 Iconography Studio', isVisible: true, order: 9, description: 'Neural and manual vector assets.', data: {} },
  { id: 'sec-imagery', type: 'imagery', title: '14 Imagery Guidelines', isVisible: true, order: 10, description: 'Visual direction and photography.', data: {} },
  { id: 'sec-playground', type: 'playground', title: 'Visual Playground', isVisible: true, order: 11, description: 'Interactive brand stress testing across UI primitives.', data: {} },
  { id: 'sec-caseStudies', type: 'caseStudies', title: 'Case Study Specimen', isVisible: true, order: 12, description: 'Success stories and proof points.', data: {} },
  { id: 'sec-brochures', type: 'brochures', title: 'Brochure Specimen', isVisible: true, order: 13, description: 'Marketing collateral and print.', data: {} },
  { id: 'sec-spotlights', type: 'spotlights', title: 'Solution Spotlights', isVisible: true, order: 14, description: 'High-impact product deep-dives.', data: {} },
  { id: 'sec-signatures', type: 'signatures', title: '16 Signature Protocol', isVisible: true, order: 15, description: 'Standardized communication buffers.', data: {} },
  { id: 'sec-social', type: 'social', title: '13 Social Tagging', isVisible: true, order: 16, description: 'Digital handles and marketing banners.', data: {} },
  { id: 'sec-cinematic', type: 'cinematic', title: 'Cinematic Assets', isVisible: true, order: 17, description: 'Motion graphics and video packages.', data: {} },
  { id: 'sec-qr', type: 'qr', title: '17 Access Ports', isVisible: true, order: 18, description: 'QR synthesis and requests.', data: {} },
  { id: 'sec-templates', type: 'templates', title: 'Master Templates', isVisible: true, order: 19, description: 'Operational document templates.', data: {} },
  { id: 'sec-assets', type: 'assets', title: '19 Global Asset Vault', isVisible: true, order: 20, description: 'Primary high-res file repository.', data: {} },
  { id: 'sec-misuse', type: 'misuse', title: '06 Anti-Patterns', isVisible: true, order: 21, description: 'Prohibited usage and dilution prevention.', data: {} },
  { id: 'sec-ai', type: 'ai', title: '18 Intelligence Studio', isVisible: true, order: 22, description: 'Neural brain registry and constraints.', data: {} }
];

export const NEW_BRAND_TEMPLATE: Brand = {
  id: 'template-' + Math.random().toString(36).substr(2, 9),
  version: '2.6.0',
  entityType: 'brand',
  isVisible: true,
  name: 'Standard Protocol Hub',
  category: 'Infrastructure',
  industry: 'Technology & Innovation',
  description: 'A comprehensive visual governance system designed for global orchestration of digital and physical identity nodes.',
  tagline: 'Orchestrating Excellence through Neural Design.',
  logoUrl: 'https://www.transperfect.com/themes/custom/transperfect/logo.svg',
  coverImage: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1200&q=80',
  updatedAt: Date.now(),
  toneOfVoice: ['Authoritative', 'Innovative', 'Precise', 'Visionary'],
  colors: DEFAULT_COLORS,
  typography: DEFAULT_TYPOGRAPHY,
  signatures: [
    { id: 'sig-main', type: 'main', name: 'Global Standard v1', role: 'External Communications', html: MAIN_SIG_HTML },
    { id: 'sig-resp', type: 'response', name: 'Quick Response Protocol', role: 'Internal / Informal', html: RESPONSE_SIG_HTML }
  ],
  assets: [
    { id: 'ast-01', name: 'Identity Source Pack', type: 'archive', url: '#', format: 'ZIP', size: '25MB' },
    { id: 'ast-02', name: 'Brand Guidelines (PDF)', type: 'archive', url: '#', format: 'PDF', size: '4.2MB' }
  ],
  logos: { 
    color: 'https://www.transperfect.com/themes/custom/transperfect/logo.svg', 
    white: 'https://www.transperfect.com/themes/custom/transperfect/logo.svg', 
    black: 'https://www.transperfect.com/themes/custom/transperfect/logo.svg' 
  },
  brandIcons: [
    { id: 'sym-01', name: 'Master Symbol', url: 'https://www.transperfect.com/favicon.ico', usageRights: 'Full Global Commercial Rights', settings: 'The symbol should always maintain a 25% clear space buffer and never be displayed below 16px.' }
  ],
  sections: DEFAULT_BRAND_SECTIONS,
  values: [
    { text: 'Uncompromising Quality', icon: 'ShieldCheck' },
    { text: 'Radical Innovation', icon: 'Zap' },
    { text: 'Global Connectivity', icon: 'Globe' }
  ],
  missionStatement: 'To provide the world\'s leading organizations with a seamless, brand-aware infrastructure for global content orchestration and cultural resonance.',
  governance: { 
    mfaRequired: false, 
    metadataShield: true, 
    neuralLevel: 'pro', 
    storagePriority: 'local', 
    showInDashboard: true 
  },
  gradients: [
    { name: 'Core Nebula', css: 'linear-gradient(135deg, #0033A0 0%, #001A54 100%)' },
    { name: 'Cyber Stream', css: 'linear-gradient(90deg, #0077C8 0%, #00B5E2 100%)' }
  ],
  patterns: [
    { name: 'Grid Alpha', url: 'https://www.transparenttextures.com/patterns/carbon-fibre.png' },
    { name: 'Noise Protocol', url: 'https://www.transparenttextures.com/patterns/stardust.png' }
  ],
  textStyles: [
    { id: 'ts-01', tag: 'h1', name: 'Hero Header', size: '72px', weight: '900', lineHeight: '0.95', sample: 'GLOBAL IMPACT' },
    { id: 'ts-02', tag: 'p', name: 'Primary Body', size: '18px', weight: '400', lineHeight: '1.6', sample: 'Synthesizing reality through code.' }
  ],
  imagery: [
    { url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&q=80', description: 'Clean, architectural lines with high contrast.', type: 'do' },
    { url: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800&q=80', description: 'Natural collaboration in a tech-forward environment.', type: 'do' }
  ],
  imageryGuidelines: 'Focus on high-contrast, architectural perspectives with a cool blue/slate color bias. Avoid cluttered environments or warm, yellow lighting.',
  socials: [
    { platform: 'LinkedIn', handle: 'transperfect', url: 'https://linkedin.com/company/transperfect', color: '#0077b5' },
    { platform: 'Twitter / X', handle: 'transperfect', url: 'https://twitter.com/transperfect', color: '#000000' }
  ],
  digitalBanners: [
    { size: 'LinkedIn Header (1584x396)', url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1200&q=80' }
  ],
  cinematicAssets: [
    { id: 'cin-01', type: 'video', url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', name: 'Identity Intro Loop' }
  ],
  templates: [
    { id: 'tmp-01', name: 'Corporate Keynote v4', description: 'The official presentation template for high-stakes meetings.', category: 'Presentations', fileType: 'PPTX', fileSize: '12MB', downloadUrl: '#', isCallout: true },
    { id: 'tmp-02', name: 'Executive Whitepaper', description: 'Standard layout for whitepapers and technical briefs.', category: 'Documents', fileType: 'INDD', fileSize: '8MB', downloadUrl: '#', isCallout: false }
  ],
  logoUsageDonts: [
    { url: 'https://www.transperfect.com/themes/custom/transperfect/logo.svg', description: 'Never distort or stretch the logo aspect ratio.' },
    { url: 'https://www.transperfect.com/themes/custom/transperfect/logo.svg', description: 'Never apply unauthorized gradients or shadow effects.' }
  ],
  qrSettings: { 
    defaultUrl: 'https://www.transperfect.com', 
    fgColor: '#0033A0', 
    bgColor: '#ffffff', 
    useCustomColors: true 
  },
  brainRegistry: {
    archetype: 'The Visionary Architect',
    narrative: 'We are the infrastructure of global resonance, bridging linguistic and technical divides through precision.',
    visualConstraints: 'Cinematic depth, cool chromatics, high-contrast geometry, minimalist UI elements.',
    culturalNuance: 'Professional, ethical, globally-minded, yet technically superior.'
  },
  caseStudies: [
    { id: 'cs-01', title: 'Digital Transformation 2025', description: 'Orchestrating global identity for Fortune 500 nodes.', category: 'Enterprise', previewUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80', templateUrl: '#' }
  ],
  brochures: [
    { id: 'br-01', title: 'Global Capability Statement', description: 'Complete overview of technological orchestration.', category: 'Corporate', previewUrl: 'https://images.unsplash.com/photo-1586717791821-3f44a563eb4c?w=800&q=80', templateUrl: '#' }
  ],
  spotlights: [
    { id: 'sp-01', title: 'Neural Symphony', description: 'Exploring the intersection of AI and Brand Identity.', category: 'Innovation', previewUrl: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&q=80', templateUrl: '#' }
  ]
};

export const BRANDS: Brand[] = [
  {
    ...NEW_BRAND_TEMPLATE,
    id: 'tp-master-node',
    name: 'TransPerfect',
    entityType: 'brand',
    category: 'Enterprise',
    industry: 'Global Technology & Language',
    description: 'The world\'s leading provider of language and technology solutions, enabling business growth across all borders through high-fidelity communication nodes.',
    tagline: 'Global Business, Orchestrated.',
    status: 'active',
    backgroundSettings: { style: 'ribbons', primaryColor: '#0033A0', secondaryColor: '#0077C8', animate: true, opacity: 0.6, blur: 0 },
    logos: {
      color: 'https://www.transperfect.com/themes/custom/transperfect/logo.svg',
      white: 'https://www.transperfect.com/themes/custom/transperfect/logo.svg',
      black: 'https://www.transperfect.com/themes/custom/transperfect/logo.svg'
    },
    colors: [
      { name: 'TransPerfect Blue', hex: '#0033A0', usage: 'primary' },
      { name: 'Sky Core', hex: '#0077C8', usage: 'primary' },
      { name: 'Light Slate', hex: '#F1F5F9', usage: 'neutral' },
      { name: 'Deep Navy', hex: '#001A54', usage: 'secondary' }
    ]
  },
  {
    ...NEW_BRAND_TEMPLATE,
    id: 'dataforce-node',
    name: 'DataForce',
    entityType: 'brand',
    category: 'SaaS',
    industry: 'AI & Data Collection',
    description: 'A global AI data solution provider offering high-quality data collection, annotation, and management protocols for machine learning architectures.',
    coverImage: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=1200&q=80',
    tagline: 'Powering the Future of AI.',
    status: 'active',
    colors: [
      { name: 'DataForce Green', hex: '#00D084', usage: 'primary' },
      { name: 'Deep Carbon', hex: '#0F172A', usage: 'secondary' },
      { name: 'AI Teal', hex: '#14B8A6', usage: 'accent' }
    ]
  },
  {
    ...NEW_BRAND_TEMPLATE,
    id: 'trial-interactive-node',
    name: 'Trial Interactive',
    entityType: 'brand',
    category: 'SaaS',
    industry: 'Life Sciences eClinical',
    description: 'Simplifying the clinical development process through a unified global platform for eTMF, study startup, and investigator site management.',
    coverImage: 'https://images.unsplash.com/photo-1576086213369-97a306d36557?w=1200&q=80',
    tagline: 'Life Sciences, Streamlined.',
    status: 'active',
    colors: [
      { name: 'TI Blue', hex: '#2563EB', usage: 'primary' },
      { name: 'Clinic Teal', hex: '#0F766E', usage: 'secondary' },
      { name: 'Pulse Red', hex: '#EF4444', usage: 'accent' }
    ]
  },
  {
    ...NEW_BRAND_TEMPLATE,
    id: 'globallink-node',
    name: 'GlobalLink',
    entityType: 'product',
    category: 'Software',
    industry: 'Translation Management',
    description: 'The world\'s most deployed translation management technology, providing total control over global content workflows.',
    coverImage: 'https://images.unsplash.com/photo-1512428559083-a401c338e45c?w=1200&q=80',
    tagline: 'Global Content, Controlled.',
    status: 'active',
    colors: [
      { name: 'GlobalLink Orange', hex: '#F97316', usage: 'primary' },
      { name: 'Connect Blue', hex: '#0033A0', usage: 'secondary' }
    ]
  },
  {
    ...NEW_BRAND_TEMPLATE,
    id: 'transperfect-legal-node',
    name: 'TransPerfect Legal',
    entityType: 'brand',
    category: 'Enterprise',
    industry: 'Legal Tech & Discovery',
    description: 'The premier partner for legal support services, offering end-to-end e-discovery, forensic technology, and legal staffing nodes.',
    coverImage: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=1200&q=80',
    tagline: 'Legal Certainty, Globally.',
    status: 'active',
    colors: [
      { name: 'Legal Gold', hex: '#D4AF37', usage: 'accent' },
      { name: 'Executive Navy', hex: '#0F172A', usage: 'primary' }
    ]
  },
  {
    ...NEW_BRAND_TEMPLATE,
    id: 'transperfect-connect-node',
    name: 'TransPerfect Connect',
    entityType: 'brand',
    category: 'Enterprise',
    industry: 'Interpretation Services',
    description: 'Leading provider of telephonic, video, and in-person interpretation solutions for global customer engagement.',
    coverImage: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=1200&q=80',
    tagline: 'Connecting Voices Everywhere.',
    status: 'active',
    colors: [
      { name: 'Connect Blue', hex: '#0ea5e9', usage: 'primary' },
      { name: 'Speech Coral', hex: '#fb7185', usage: 'accent' }
    ]
  },
  {
    ...NEW_BRAND_TEMPLATE,
    id: 'medianext-node',
    name: 'MediaNEXT',
    entityType: 'product',
    category: 'Software',
    industry: 'Media & Entertainment',
    description: 'Next-generation AI-powered media localization platform for global content distribution and streaming services.',
    coverImage: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=1200&q=80',
    tagline: 'The Future of Media Localization.',
    status: 'active',
    colors: [
      { name: 'Media Purple', hex: '#8B5CF6', usage: 'primary' },
      { name: 'Next Cyan', hex: '#06B6D4', usage: 'accent' }
    ]
  }
];
