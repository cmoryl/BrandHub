
import { create } from 'zustand';
import { Brand, BrandSection, SystemHealth, DiagnosticResult } from '../types';
import { BrandSchema } from '../schemas';
import { backend } from '../services/backendService';

interface BrandState {
  brands: Brand[];
  selectedBrandId: string | null;
  isSyncing: boolean;
  lastSync: number;
  systemHealth: SystemHealth;
  
  // Diagnostic Persistence
  lastDiagnosticResults: DiagnosticResult[];
  lastDiagnosticLogs: {msg: string, type: 'info' | 'warn' | 'error'}[];
  
  // Actions
  setBrands: (brands: Brand[]) => void;
  setSelectedBrand: (id: string | null) => void;
  updateSystemHealth: (health: Partial<SystemHealth>) => void;
  clearFaults: () => void;
  
  setDiagnosticData: (results: DiagnosticResult[], logs: {msg: string, type: 'info' | 'warn' | 'error'}[]) => void;
  
  loadBrand: (json: any) => { success: boolean; error?: string };
  updateBrand: (brand: Brand) => void;
  removeBrand: (id: string) => void;
  updateSection: (brandId: string, sectionId: string, data: any) => void;
  setSyncing: (status: boolean) => void;
}

const DEFAULT_DIAGNOSTIC_RESULTS: DiagnosticResult[] = [
  { id: '1', name: 'Database Integrity', status: 'pending', log: 'Awaiting initialization...' },
  { id: '2', name: 'Asset Connectivity', status: 'pending', log: 'Ready to scan external links.' },
  { id: '3', name: 'Chromatic Resonance', status: 'pending', log: 'WCAG compliance scan queued.' },
  { id: '4', name: 'AI Neural Handshake', status: 'pending', log: 'Gemini path verification ready.' },
  { id: '5', name: 'Synthetic Stress', status: 'pending', log: 'Buffer concurrency test ready.' },
  { id: '6', name: 'Storage Quota', status: 'pending', log: 'Capacity audit pending.' }
];

export const useBrandStore = create<BrandState>((set, get) => ({
  brands: [],
  selectedBrandId: null,
  isSyncing: false,
  lastSync: Date.now(),
  systemHealth: {
    status: 'nominal',
    lastCheck: Date.now(),
    faultCount: 0,
    message: 'System initialization complete.'
  },

  lastDiagnosticResults: DEFAULT_DIAGNOSTIC_RESULTS,
  lastDiagnosticLogs: [],

  setBrands: (brands) => set({ brands, lastSync: Date.now() }),
  setSelectedBrand: (id) => set({ selectedBrandId: id }),

  updateSystemHealth: (health) => set((state) => ({
    systemHealth: { ...state.systemHealth, ...health }
  })),

  setDiagnosticData: (results, logs) => set({ 
    lastDiagnosticResults: results, 
    lastDiagnosticLogs: logs 
  }),

  clearFaults: () => set({
    systemHealth: {
      status: 'nominal',
      lastCheck: Date.now(),
      faultCount: 0,
      message: 'System status manually cleared to nominal.'
    },
    lastDiagnosticResults: DEFAULT_DIAGNOSTIC_RESULTS,
    lastDiagnosticLogs: []
  }),

  loadBrand: (json) => {
    try {
      const validated = BrandSchema.parse(json);
      const brands = get().brands;
      const index = brands.findIndex(b => b.id === validated.id);
      
      let nextBrands;
      if (index !== -1) {
        nextBrands = brands.map(b => b.id === validated.id ? validated : b);
      } else {
        nextBrands = [...brands, validated];
      }
      
      set({ brands: nextBrands, lastSync: Date.now() });
      return { success: true };
    } catch (err: any) {
      console.error("Data Validation Fault:", err.errors);
      return { success: false, error: "Snapshot integrity failure. Check schema compliance." };
    }
  },

  updateBrand: (updatedBrand) => {
    const brands = get().brands;
    const nextBrands = brands.map(b => b.id === updatedBrand.id ? updatedBrand : b);
    set({ brands: nextBrands, lastSync: Date.now() });
  },

  removeBrand: (id) => {
    const brands = get().brands;
    set({ brands: brands.filter(b => b.id !== id), lastSync: Date.now() });
  },

  updateSection: (brandId, sectionId, sectionData) => {
    const brands = get().brands;
    const nextBrands = brands.map(brand => {
      if (brand.id !== brandId) return brand;
      const nextSections = brand.sections.map(sec => 
        sec.id === sectionId ? { ...sec, data: sectionData } : sec
      );
      return backend.migrateAndRepair({ ...brand, sections: nextSections }, 'sections');
    });
    set({ brands: nextBrands, lastSync: Date.now() });
  },

  setSyncing: (status) => set({ isSyncing: status })
}));
