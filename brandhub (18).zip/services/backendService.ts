
// @ts-nocheck
import { Brand, BrandSection, SectionType, RestorePoint } from '../types';
import { BrandSchema } from '../schemas';
import { BRANDS as DEFAULT_BRANDS, NEW_BRAND_TEMPLATE, DEFAULT_BRAND_SECTIONS } from '../constants';
import { getDirectImageUrl } from '../utils/linkUtils';

const DB_NAME = 'BrandHubVault';
const STORE_NAME = 'brands';
const BACKUP_STORE = 'backups';
const SCHEMA_VERSION = '2.6.0';

class VaultDB {
  private db: IDBDatabase | null = null;
  async init(): Promise<void> {
    if (this.db) return;
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, 3); 
      request.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        if (!db.objectStoreNames.contains(BACKUP_STORE)) db.createObjectStore(BACKUP_STORE, { keyPath: 'id' });
      };
      request.onsuccess = () => { this.db = request.result; resolve(); };
      request.onerror = () => reject(request.error);
    });
  }
  async getAll(): Promise<Brand[]> {
    await this.init();
    return new Promise((res) => {
      try {
        const tx = this.db!.transaction(STORE_NAME, 'readonly');
        const req = tx.objectStore(STORE_NAME).getAll();
        req.onsuccess = () => res(req.result || []);
        req.onerror = () => res([]);
      } catch (e) { res([]); }
    });
  }
  async saveAll(brands: Brand[]): Promise<void> {
    await this.init();
    const tx = this.db!.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.clear();
    brands.forEach(b => {
      const val = BrandSchema.safeParse(b);
      if (val.success) store.add(val.data);
      else console.error("Validation Fault for node:", b.name, val.error);
    });
  }
}

const vault = new VaultDB();

class BackendService {
  /**
   * THE IRON MIRROR PROTOCOL
   * Ensures data fidelity between flat root attributes and structured section data.
   */
  public migrateAndRepair(brand: any, source: 'top-level' | 'sections' = 'top-level'): Brand {
    const blueprint = JSON.parse(JSON.stringify(NEW_BRAND_TEMPLATE));
    
    // RECONCILIATION PHASE: UPSTREAM (Sections -> Root)
    if (source === 'sections' && Array.isArray(brand.sections)) {
      brand.sections.forEach((s: BrandSection) => {
        const d = s.data;
        if (!d) return;
        switch (s.type) {
          case 'identity': 
            brand.missionStatement = d.missionStatement; 
            brand.tagline = d.tagline; 
            brand.archetype = d.archetype; 
            brand.values = d.values; 
            brand.toneOfVoice = d.toneOfVoice;
            break;
          case 'logos': 
            const { guidelines, headerLogoVariant, ...variants } = d;
            const cleanVariants = {};
            Object.entries(variants).forEach(([k, v]) => {
              if (typeof v === 'string') cleanVariants[k] = v;
            });
            // CRITICAL: Deep merge to prevent purging other existing variants
            brand.logos = { ...(brand.logos || {}), ...cleanVariants };
            brand.logoGuidelines = guidelines;
            brand.headerLogoVariant = headerLogoVariant;
            break;
          case 'brandIcon': 
            if (Array.isArray(d)) brand.brandIcons = d;
            else brand.brandIcon = { ...(brand.brandIcon || {}), ...d };
            break;
          case 'colors': brand.colors = d; break;
          case 'gradients': brand.gradients = d; break;
          case 'patterns': brand.patterns = d; break;
          case 'typography': brand.typography = d; break;
          case 'textStyles': brand.textStyles = d; break;
          case 'iconography': 
            brand.icons = d.icons; 
            brand.aiIconSets = d.aiSets; 
            break;
          case 'imagery': 
            brand.imagery = d.images; 
            brand.imageryGuidelines = d.guidelines;
            break;
          case 'social': 
            brand.socials = d.socials; 
            brand.socialBanners = d.banners;
            brand.digitalBanners = d.digital;
            break;
          case 'signatures': 
            brand.signatures = d.signatures; 
            brand.emailBanners = d.banners;
            break;
          case 'qr': brand.qrSettings = d; break;
          case 'ai': 
            brand.brainRegistry = d;
            brand.intelligenceBrain = `ARCHETYPE: ${d.archetype}\nNARRATIVE: ${d.narrative}\nVISUALS: ${d.visualConstraints}\nCULTURE: ${d.culturalNuance}`;
            break;
          case 'caseStudies': brand.caseStudies = d; break;
          case 'brochures': brand.brochures = d; break;
          case 'spotlights': brand.spotlights = d; break;
          case 'assets': brand.assets = d; break;
          case 'templates': brand.templates = d; break;
          case 'cinematic': brand.cinematicAssets = d; break;
          case 'misuse': brand.logoUsageDonts = d; break;
        }
      });
    }

    // MERGE PHASE
    const merged: Brand = {
      ...blueprint,
      ...brand,
      id: brand.id || blueprint.id,
      version: SCHEMA_VERSION,
      updatedAt: brand.updatedAt || Date.now(),
      logos: { ...blueprint.logos, ...(brand.logos || {}) },
      brandIcon: { ...(blueprint.brandIcon || {}), ...(brand.brandIcon || {}) },
      qrSettings: { ...(blueprint.qrSettings || {}), ...(brand.qrSettings || {}) },
      brainRegistry: { ...(blueprint.brainRegistry || {}), ...(brand.brainRegistry || {}) }
    };

    // SYNC PHASE: DOWNSTREAM (Root -> Sections)
    const getSyncedData = (type: SectionType, existingSec?: any) => {
      const base = existingSec?.data || {};
      switch (type) {
        case 'identity': return { ...base, missionStatement: merged.missionStatement, tagline: merged.tagline, archetype: merged.archetype, values: merged.values, toneOfVoice: merged.toneOfVoice };
        case 'logos': return { ...base, ...merged.logos, guidelines: merged.logoGuidelines, headerLogoVariant: merged.headerLogoVariant };
        case 'brandIcon': return merged.brandIcons || [];
        case 'colors': return merged.colors || [];
        case 'gradients': return merged.gradients || [];
        case 'patterns': return merged.patterns || [];
        case 'typography': return merged.typography || [];
        case 'textStyles': return merged.textStyles || [];
        case 'iconography': return { ...base, icons: merged.icons, aiSets: merged.aiIconSets };
        case 'imagery': return { ...base, images: merged.imagery, guidelines: merged.imageryGuidelines };
        case 'social': return { ...base, socials: merged.socials, banners: merged.socialBanners, digital: merged.digitalBanners };
        case 'signatures': return { ...base, signatures: merged.signatures, banners: merged.emailBanners };
        case 'qr': return { ...merged.qrSettings };
        case 'ai': return { ...merged.brainRegistry };
        case 'caseStudies': return merged.caseStudies || [];
        case 'brochures': return merged.brochures || [];
        case 'spotlights': return merged.spotlights || [];
        case 'assets': return merged.assets || [];
        case 'templates': return merged.templates || [];
        case 'cinematic': return merged.cinematicAssets || [];
        case 'misuse': return merged.logoUsageDonts || [];
        default: return base;
      }
    };

    merged.sections = DEFAULT_BRAND_SECTIONS.map(sysSec => {
      const existing = (brand.sections || []).find(s => s.type === sysSec.type);
      return {
        ...sysSec,
        id: existing?.id || sysSec.id,
        isVisible: existing?.isVisible ?? sysSec.isVisible,
        order: existing?.order ?? sysSec.order,
        title: existing?.title ?? sysSec.title, 
        description: existing?.description ?? sysSec.description, 
        data: getSyncedData(sysSec.type, existing)
      };
    }).sort((a, b) => a.order - b.order);

    return merged;
  }

  async fetchBrands(): Promise<Brand[]> {
    const data = await vault.getAll();
    if (!data || data.length === 0) return DEFAULT_BRANDS.map(b => this.migrateAndRepair(b));
    return data.map(b => this.migrateAndRepair(b));
  }
  async syncDatabase(brands: Brand[]): Promise<boolean> {
    await vault.saveAll(brands);
    return true;
  }
  async deleteBrand(id: string): Promise<void> {
    await vault.init();
    const tx = this.db!.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).delete(id);
  }
  async factoryReset(): Promise<Brand[]> {
    await vault.init();
    const tx = this.db!.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).clear();
    return DEFAULT_BRANDS.map(b => this.migrateAndRepair(b));
  }
  async fetchRestorePoints() {
    await vault.init();
    const tx = this.db!.transaction('backups', 'readonly');
    const req = tx.objectStore('backups').getAll();
    return new Promise((res) => { req.onsuccess = () => res(req.result || []); });
  }
  async createRestorePoint(label: string, brands: Brand[]) {
    await vault.init();
    const tx = this.db!.transaction('backups', 'readwrite');
    const pt = { id: `bp-${Date.now()}`, label, timestamp: Date.now(), brandCount: brands.length, data: brands };
    tx.objectStore('backups').add(pt);
    return pt;
  }
  async deleteRestorePoint(id: string) {
    await vault.init();
    const tx = this.db!.transaction('backups', 'readwrite');
    tx.objectStore(BACKUP_STORE).delete(id);
  }
}
export const backend = new BackendService();
