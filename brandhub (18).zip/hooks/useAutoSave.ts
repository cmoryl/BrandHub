
import { useEffect, useRef } from 'react';
import { useBrandStore } from '../store/brandStore';
import { backend } from '../services/backendService';

/**
 * Monitors the brand store and persists changes to storage automatically.
 */
export const useAutoSave = () => {
  const { brands, setSyncing } = useBrandStore();
  // Using ReturnType<typeof setTimeout> for browser environment compatibility
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isInitialMount = useRef(true);

  useEffect(() => {
    // Skip saving on the very first mount/load to avoid overwriting with empty/partial state
    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }

    // Debounce logic: reset timer on every state change
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    
    setSyncing(true);
    
    timerRef.current = setTimeout(async () => {
      try {
        await backend.syncDatabase(brands);
      } catch (err) {
        console.error("Auto-Save Protocol Interrupted:", err);
      } finally {
        setSyncing(false);
      }
    }, 1200); // 1.2s debounce for smoother UX

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [brands, setSyncing]);
};
